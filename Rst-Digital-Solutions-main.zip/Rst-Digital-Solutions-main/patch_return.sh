sed -i '/return (/i\
  if (activeTab === '\''admin'\'') {\
    return <AdminPanel onLogout={() => { auth.signOut(); setActiveTab('\''home'\''); }} />;\
  }\
' src/App.tsx
