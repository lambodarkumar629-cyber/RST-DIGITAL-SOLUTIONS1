const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');
const adminBlock = "  if (activeTab === 'admin') {\n    return <AdminPanel onLogout={() => { auth.signOut(); setActiveTab('home'); }} />;\n  }\n";
code = code.split(adminBlock).join('');
// find the last "return (" which is for the App component
const lastReturnIndex = code.lastIndexOf('  return (');
code = code.substring(0, lastReturnIndex) + adminBlock + code.substring(lastReturnIndex);
fs.writeFileSync('src/App.tsx', code);
