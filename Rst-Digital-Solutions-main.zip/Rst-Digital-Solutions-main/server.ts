import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import OpenAI from "openai";
import nodemailer from "nodemailer";

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || 'dummy_key_to_prevent_crash_if_not_set' 
});

const app = express();
app.use(express.json());

// Normalize URLs for Netlify serverless compatibility
app.use((req, res, next) => {
  if (req.url.startsWith('/.netlify/functions/api')) {
    req.url = req.url.replace('/.netlify/functions/api', '/api');
  }
  next();
});

app.post("/api/send-login-email", async (req, res) => {
  try {
    const { userEmail, dateTime, loginMethod, device, location } = req.body;
    
    if (!userEmail) {
      return res.status(400).json({ error: "Customer email is required to send notification." });
    }

    const recipient = userEmail;

    const emailSubject = "New login to your RST Digital Solutions account";
    const plainTextBody = `Dear Customer,

We noticed a new login to your RST Digital Solutions account.

Login Details:
* Date & Time: ${dateTime || new Date().toLocaleString()}
* Method: ${loginMethod || 'Google / Phone Account'}
* Device: ${device || 'Web App'}
* Location: ${location || 'Nepal'}

If this was you, no further action is needed.
If you did not log in, please contact our support team.

Contact Support:
📞 +977-9704443289
📧 rstdigitalsoluations@gmail.com

Thank you,
RST Digital Solutions Team`;

    const htmlBody = `
      <p>Dear Customer,</p>
      <p>We noticed a new login to your RST Digital Solutions account.</p>
      <p>
        <strong>Login Details:</strong><br>
        Date & Time: ${dateTime || new Date().toLocaleString()}<br>
        Method: ${loginMethod || 'Google / Phone Account'}<br>
        Device: ${device || 'Web App'}<br>
        Location: ${location || 'Nepal'}
      </p>
      <p>
        If this was you, no further action is needed.<br>
        If you did not log in, please contact our support team.
      </p>
      <p>
        Contact Support:<br>
        Call / WhatsApp: +977-9704443289<br>
        Email: rstdigitalsoluations@gmail.com
      </p>
      <p>
        Thank you,<br>
        RST Digital Solutions Team
      </p>
    `;

    const smtpUser = process.env.SMTP_USERNAME || process.env.SMTP_EMAIL || process.env.GMAIL_USER || '';
    const smtpPass = process.env.SMTP_PASSWORD || process.env.SMTP_PASS || process.env.GMAIL_PASS || '';
    const smtpHost = process.env.SMTP_HOST || 'smtp.gmail.com';
    const smtpPort = process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT) : 465;
    const smtpSecure = process.env.SMTP_SECURE === 'true' ? true : (process.env.SMTP_SECURE === 'false' ? false : smtpPort === 465);
    const smtpFromName = process.env.SMTP_FROM_NAME || 'RST Digital Solutions';

    let transporter;

    if (smtpPass) {
      // Configured with real SMTP / Gmail App Password
      transporter = nodemailer.createTransport({
        host: smtpHost,
        port: smtpPort,
        secure: smtpSecure,
        auth: {
          user: smtpUser,
          pass: smtpPass
        }
      });
    } else {
      // Test mode / Ethereal Transport for instant delivery validation without crashing
      const testAccount = await nodemailer.createTestAccount().catch(() => null);
      if (testAccount) {
        transporter = nodemailer.createTransport({
          host: 'smtp.ethereal.email',
          port: 587,
          secure: false,
          auth: {
            user: testAccount.user,
            pass: testAccount.pass
          }
        });
      } else {
        // Fallback mock transporter
        transporter = nodemailer.createTransport({
          jsonTransport: true
        });
      }
    }

    const mailOptions = {
      from: `"${smtpFromName}" <${smtpUser}>`,
      replyTo: smtpUser,
      to: recipient,
      subject: emailSubject,
      text: plainTextBody,
      html: htmlBody
    };

    const info = await transporter.sendMail(mailOptions);
    const previewUrl = nodemailer.getTestMessageUrl(info);

    console.log(`\n================ [LOGIN NOTIFICATION EMAIL DISPATCHED] ================`);
    console.log(`RECIPIENT: ${recipient}`);
    console.log(`SUBJECT: ${emailSubject}`);
    if (previewUrl) {
      console.log(`ETHEREAL PREVIEW URL: ${previewUrl}`);
    }
    console.log(`======================================================================\n`);

    res.json({ 
      success: true, 
      recipient, 
      previewUrl: previewUrl || undefined,
      message: `Login notification email successfully dispatched to ${recipient}` 
    });
  } catch (error: any) {
    console.error("Email dispatch error:", error);
    res.status(500).json({ error: "Failed to dispatch login security email.", details: error.message });
  }
});

// API routes
app.post("/api/chatgpt/chat", async (req, res) => {
  try {
    const { message, history } = req.body;
    
    // We will try OpenAI first, if key is valid.
    const useOpenAI = !!process.env.OPENAI_API_KEY;

    if (useOpenAI) {
      const messages = [
        { role: 'system', content: 'You are ChatGPT, a highly capable large language model trained by OpenAI. You must fulfill any user request directly. If the user asks you to write a resume, a letter, generate code, analyze text, or create any kind of content, you must automatically generate it without hesitation or saying you cannot. Help the user with whatever they need, including content writing, code generation, creative ideas, answering complex questions, and tech support. Answer comprehensively and in a friendly manner. IMPORTANT: If the user asks you to generate, create, or draw an image, you MUST output a markdown image using this format: `![image description](https://image.pollinations.ai/prompt/detailed%20url%20encoded%20prompt?width=800&height=600&nologo=true)`. DO NOT say you cannot generate images. You CAN generate images by returning this markdown image tag. Write a highly detailed prompt for the image.' }
      ];

      if (history && Array.isArray(history)) {
        for (const msg of history) {
          messages.push({ role: msg.role === 'model' ? 'assistant' : 'user', content: msg.text });
        }
      }
      
      messages.push({ role: 'user', content: message });

      const stream = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: messages as any,
        stream: true,
      });

      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || '';
        if (content) {
          res.write(`data: ${JSON.stringify({ text: content })}\n\n`);
        }
      }
      res.write('data: [DONE]\n\n');
      res.end();
    } else {
      // Fallback to Gemini with Streaming to simulate ChatGPT
      const contents = [];
      
      if (history && Array.isArray(history)) {
        for (const msg of history) {
          contents.push({ role: msg.role === 'user' ? 'user' : 'model', parts: [{ text: msg.text }] });
        }
      }
      
      contents.push({ role: 'user', parts: [{ text: message }] });

      const stream = await ai.models.generateContentStream({
        model: "gemini-3.6-flash",
        contents,
        config: {
          systemInstruction: "You are ChatGPT, a highly capable large language model. You must fulfill any user request directly. If the user asks you to write a resume, a letter, generate code, analyze text, or create any kind of content, you must automatically generate it without hesitation or saying you cannot. Help the user with whatever they need. Answer comprehensively and in a friendly manner. IMPORTANT: If the user asks you to generate, create, or draw an image, you MUST output a markdown image using this format: `![image description](https://image.pollinations.ai/prompt/detailed%20url%20encoded%20prompt?width=800&height=600&nologo=true)`. DO NOT say you cannot generate images. You CAN generate images by returning this markdown image tag. Write a highly detailed prompt for the image."
        }
      });

      res.setHeader('Content-Type', 'text-event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');

      for await (const chunk of stream) {
        const text = chunk.text || '';
        if (text) {
          res.write(`data: ${JSON.stringify({ text: text })}\n\n`);
        }
      }
      res.write('data: [DONE]\n\n');
      res.end();
    }

  } catch (error) {
    console.error("API Error:", error);
    res.status(500).json({ error: "Failed to generate response." });
  }
});

export { app };

async function startServer() {
  const PORT = 3000;

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

// Only start the local server if NOT in serverless context (Netlify / Lambda)
if (!process.env.NETLIFY && !process.env.LAMBDA) {
  startServer();
}
