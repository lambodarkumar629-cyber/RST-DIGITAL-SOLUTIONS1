sed -i "s|import { LoginModal } from './components/LoginModal';|import { LoginModal } from './components/LoginModal';\nimport { AdminPanel } from './components/AdminPanel';|" src/App.tsx

sed -i "/const \[orders, setOrders\] = useState/a\  \n  useEffect(() => {\n    if (user && user.email === 'kaparrst@gmail.com' && activeTab !== 'admin') {\n      setActiveTab('admin');\n    }\n  }, [user]);\n" src/App.tsx
