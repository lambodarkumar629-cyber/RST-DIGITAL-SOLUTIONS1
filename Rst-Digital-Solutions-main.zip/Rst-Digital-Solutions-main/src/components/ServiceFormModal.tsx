import React, { useState } from 'react';
import { X, CheckCircle2, ExternalLink, Globe } from 'lucide-react';
import { ServiceCategory } from '../types';

interface ServiceFormModalProps {
  category: ServiceCategory;
  onClose: () => void;
  onSubmitOrder: (order: any) => void;
}

export const ServiceFormModal: React.FC<ServiceFormModalProps> = ({ category, onClose, onSubmitOrder }) => {
  const [selectedSubCategory, setSelectedSubCategory] = useState(category.subCategories[0]?.id || '');
  const [formData, setFormData] = useState<Record<string, string>>({});

  const activeSubCategory = category.subCategories.find(s => s.id === selectedSubCategory) || category.subCategories[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const serviceData = {
      id: `RST-${Math.floor(100000 + Math.random() * 900000)}`,
      categoryId: category.id,
      categoryName: category.title,
      subCategoryName: activeSubCategory?.name || 'General',
      formData,
      estimatedPrice: activeSubCategory?.estimatedPrice || 0,
      status: 'Received',
      createdAt: new Date().toLocaleString(),
    };
    
    onSubmitOrder(serviceData);
    onClose();
  };

  const handleFieldChange = (id: string, value: string) => {
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className={`p-5 ${category.bgGradient} bg-gradient-to-br flex items-start justify-between border-b border-slate-100`}>
          <div>
            <h2 className="text-xl font-black text-slate-900">{category.title}</h2>
            <p className="text-xs text-slate-600 mt-1 font-medium">{category.description}</p>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/50 hover:bg-white text-slate-600 flex items-center justify-center transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5 overflow-y-auto custom-scrollbar flex-1 space-y-6">
          <form id="service-form" onSubmit={handleSubmit} className="space-y-5">
            {/* Service Selection */}
            {category.subCategories.length > 0 && (
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Select Specific Service</label>
                <div className="space-y-2">
                  {category.subCategories.map(sub => (
                    <label 
                      key={sub.id} 
                      className={`flex items-start gap-3 p-3 rounded-xl border-2 cursor-pointer transition ${
                        selectedSubCategory === sub.id ? 'border-blue-500 bg-blue-50' : 'border-slate-100 hover:border-blue-200 bg-white'
                      }`}
                    >
                      <input 
                        type="radio" 
                        name="subcategory" 
                        value={sub.id}
                        checked={selectedSubCategory === sub.id}
                        onChange={(e) => setSelectedSubCategory(e.target.value)}
                        className="mt-1 sr-only"
                      />
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 mt-0.5 ${
                        selectedSubCategory === sub.id ? 'border-blue-500 bg-blue-500' : 'border-slate-300'
                      }`}>
                        {selectedSubCategory === sub.id && <CheckCircle2 className="w-3.5 h-3.5 text-white" />}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <span className="text-sm font-bold text-slate-900">{sub.name}</span>
                          <span className="text-xs font-black text-blue-600">${sub.estimatedPrice}</span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5 leading-snug">{sub.description}</p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* Direct External Link Section if service has external URL */}
            {(activeSubCategory?.externalUrl || category.externalUrl) && (
              <div className="bg-slate-900 text-white rounded-2xl p-4 shadow-md space-y-3 border border-slate-700">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Globe className="w-5 h-5 text-blue-400" />
                    <h4 className="text-sm font-bold text-white">External Service Portal</h4>
                  </div>
                  <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md font-medium border border-slate-700">
                    Third-party service / Opens external website
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Third-party service / Opens external website in a new browser tab.
                </p>
                <a
                  href={activeSubCategory?.externalUrl || category.externalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 hover:bg-blue-500 text-white text-xs font-black rounded-xl shadow-lg transition cursor-pointer"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>AI Video Creator &rarr;</span>
                </a>
              </div>
            )}

            {/* Dynamic Fields */}
            {activeSubCategory?.fields?.map(field => (
              <div key={field.id} className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">
                  {field.label} {field.required && <span className="text-red-500">*</span>}
                </label>
                {field.type === 'textarea' ? (
                  <textarea
                    required={field.required}
                    placeholder={field.placeholder}
                    value={formData[field.id] || ''}
                    onChange={(e) => handleFieldChange(field.id, e.target.value)}
                    className="w-full px-3 py-2.5 text-sm rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none transition min-h-[80px] bg-slate-50 focus:bg-white"
                  />
                ) : field.type === 'select' ? (
                  <select
                    required={field.required}
                    value={formData[field.id] || ''}
                    onChange={(e) => handleFieldChange(field.id, e.target.value)}
                    className="w-full px-3 py-2.5 text-sm rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none transition bg-slate-50 focus:bg-white appearance-none"
                  >
                    <option value="">Select an option...</option>
                    {field.options?.map(opt => (
                      <option key={opt} value={opt}>{opt}</option>
                    ))}
                  </select>
                ) : field.type === 'radio' ? (
                  <div className="space-y-2">
                    {field.options?.map(opt => (
                      <label key={opt} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name={field.id}
                          value={opt}
                          checked={formData[field.id] === opt}
                          onChange={(e) => handleFieldChange(field.id, e.target.value)}
                          required={field.required}
                          className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-slate-300"
                        />
                        <span className="text-sm text-slate-700">{opt}</span>
                      </label>
                    ))}
                  </div>
                ) : (
                  <input
                    type={field.type}
                    required={field.required}
                    placeholder={field.placeholder}
                    value={formData[field.id] || ''}
                    onChange={(e) => handleFieldChange(field.id, e.target.value)}
                    className="w-full px-3 py-2.5 text-sm rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none transition bg-slate-50 focus:bg-white"
                  />
                )}
              </div>
            ))}
          </form>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end gap-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-200 rounded-xl transition"
          >
            Cancel
          </button>
          <button
            type="submit"
            form="service-form"
            className="px-6 py-2.5 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-md transition flex items-center gap-2"
          >
            <span>Place Order</span>
            <span className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center text-xs">
              &rarr;
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
