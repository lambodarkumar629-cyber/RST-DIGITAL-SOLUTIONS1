import React, { useState, useEffect } from 'react';
import { 
  signInWithPopup, 
} from 'firebase/auth';
import { auth, googleProvider } from '../lib/firebase';
import { 
  X, 
  Phone, 
  Apple, 
  ChevronLeft,
  ShieldCheck,
  Zap,
  Lock,
  Edit2,
  CheckCircle2,
  Loader2,
  Mail
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LoginModalProps {
  onClose: () => void;
  onLoginSuccess?: (method: string, email?: string) => void;
}

type AuthStep = 'choice' | 'otp_verify';

export const LoginModal: React.FC<LoginModalProps> = ({ onClose, onLoginSuccess }) => {
  const [step, setStep] = useState<AuthStep>('choice');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [phoneNumber] = useState('+977 9704443289');
  const [otp, setOtp] = useState(['0', '0', '0', '0', '0', '0']);
  const [timer, setTimer] = useState(45);

  useEffect(() => {
    let interval: any;
    if (step === 'otp_verify' && timer > 0) {
      interval = setInterval(() => setTimer(prev => prev - 1), 1000);
    }
    return () => clearInterval(interval);
  }, [step, timer]);

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError('');
    try {
      const result = await signInWithPopup(auth, googleProvider);
      if (result.user.email) {
        localStorage.setItem('user_email', result.user.email);
      }
      localStorage.setItem('last_login_method', 'Google Account');
      onLoginSuccess?.('Google Account', result.user.email || undefined);
      onClose();
    } catch (err: any) {
      if (err.code === 'auth/unauthorized-domain') {
        const currentDomain = window.location.hostname;
        setError(`Domain not authorized. Please add "${currentDomain}" to Firebase Console -> Authentication -> Settings -> Authorized domains.`);
      } else {
        setError(err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    localStorage.setItem('last_login_method', 'Apple ID');
    onLoginSuccess?.('Apple ID');
    onClose();
  };

  const handleVerifyOtp = async () => {
    setLoading(true);
    localStorage.setItem('last_login_method', `Phone Number (${phoneNumber})`);
    onLoginSuccess?.(`Phone Number (${phoneNumber})`);
    onClose();
  };

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const renderChoiceStep = () => (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col h-full bg-white relative"
    >
      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600 rounded-bl-[100%] opacity-10"></div>
      
      {/* Logo Section */}
      <div className="flex flex-col items-center pt-16 pb-6">
        <div className="relative w-28 h-28 mb-4">
          <div className="relative flex items-center justify-center w-full h-full bg-white rounded-full shadow-2xl p-1">
             {/* Logo SVG Mockup to match RST Digital */}
             <svg viewBox="0 0 100 100" className="w-full h-full">
                <circle cx="50" cy="50" r="48" fill="none" stroke="#2563eb" strokeWidth="2" />
                <path d="M30 30 L70 30 L70 70 L30 70 Z" fill="#2563eb" className="opacity-10" />
                <text x="50" y="60" textAnchor="middle" fill="#2563eb" fontSize="24" fontWeight="900" fontFamily="sans-serif">RST</text>
             </svg>
          </div>
        </div>
        <h1 className="text-2xl font-black text-slate-900 tracking-tight">RST DIGITAL</h1>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] mt-1">— SOLUTIONS —</p>
      </div>

      <div className="text-center mb-6 px-4">
        <h2 className="text-3xl font-black text-slate-900 mb-2">Welcome <span className="text-blue-600">Back!</span></h2>
        <p className="text-xs font-bold text-slate-400">Login to continue to your account</p>
      </div>

      {/* Illustration Area */}
      <div className="relative h-48 mb-8 flex items-center justify-center">
        <img 
          src="https://img.freepik.com/free-vector/security-concept-illustration_114360-497.jpg" 
          className="h-full object-contain" 
          alt="Security"
        />
      </div>

      {/* Login Options */}
      <div className="space-y-4 px-8">
        {error && (
          <div className="bg-red-50 text-red-600 p-3 rounded-xl text-xs font-bold text-center border border-red-100">
            {error}
          </div>
        )}
        <div className="relative py-4">
          <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
          <div className="relative flex justify-center text-[10px] uppercase font-black tracking-widest"><span className="bg-white px-4 text-slate-400">Login / Sign In</span></div>
        </div>

        <button 
          onClick={handleGoogleLogin}
          className="w-full h-14 bg-white border border-slate-200 rounded-full flex items-center px-8 gap-4 shadow-sm hover:shadow-md transition-all"
        >
          <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="G" />
          <span className="flex-1 text-center font-black text-slate-700 text-sm">Continue with Google</span>
        </button>

        <button 
          onClick={handleAppleLogin}
          className="w-full h-14 bg-black text-white rounded-full flex items-center px-8 gap-4 shadow-sm hover:bg-slate-900 transition-all cursor-pointer"
        >
          <Apple className="w-5 h-5 fill-current" />
          <span className="flex-1 text-center font-black text-sm">Continue with Apple</span>
        </button>

        <button 
          onClick={() => setStep('otp_verify')}
          className="w-full h-14 bg-gradient-to-r from-blue-600 to-blue-400 text-white rounded-full flex items-center px-8 gap-4 shadow-lg shadow-blue-600/20 hover:scale-[1.01] transition-all"
        >
          <Phone className="w-5 h-5" />
          <span className="flex-1 text-center font-black text-sm">Continue with Phone Number</span>
        </button>
      </div>

      {/* OR Divider */}
      <div className="flex items-center justify-center gap-4 px-12 my-6">
        <div className="flex-1 border-t border-slate-100"></div>
        <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">OR</span>
        <div className="flex-1 border-t border-slate-100"></div>
      </div>

      {/* Features Row */}
      <div className="flex justify-center gap-8 mb-8">
        {[
          { icon: Lock, label: 'Secure Login' },
          { icon: Zap, label: 'Fast & Easy' },
          { icon: ShieldCheck, label: 'Privacy Protected' }
        ].map((f, i) => (
          <div key={i} className="flex flex-col items-center gap-2">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600">
              <f.icon className="w-5 h-5" />
            </div>
            <span className="text-[9px] font-black text-slate-400 uppercase tracking-tight text-center max-w-[60px]">{f.label}</span>
          </div>
        ))}
      </div>

      <div className="mt-auto pb-8 px-8 flex flex-col items-center gap-6">
        <p className="text-xs font-bold text-slate-500">
          Don't have an account? <button className="text-blue-600 font-black">Create Account</button>
        </p>
        <div className="w-full flex justify-between items-center text-[10px] font-black uppercase tracking-widest px-2">
          <button className="text-blue-600">Forgot Password?</button>
          <button className="text-slate-400">Guest Login</button>
        </div>
        <div className="flex items-center gap-2">
          <input type="checkbox" className="w-4 h-4 rounded border-slate-300 text-blue-600" defaultChecked />
          <span className="text-[10px] font-bold text-slate-400">
            I agree to the <span className="text-blue-600">Terms & Conditions</span> and <span className="text-blue-600">Privacy Policy</span>
          </span>
        </div>
      </div>
    </motion.div>
  );

  const renderOtpStep = () => (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col h-full bg-white px-8"
    >
      <div className="pt-8 mb-8">
        <button onClick={() => setStep('choice')} className="p-2 text-slate-900">
          <ChevronLeft className="w-8 h-8" />
        </button>
      </div>

      <div className="text-center mb-10">
        <h2 className="text-2xl font-black text-slate-900 mb-2">Phone <span className="text-blue-600">Verification</span></h2>
        <p className="text-xs font-bold text-slate-500">Enter the OTP sent to your mobile number</p>
      </div>

      <div className="relative h-40 mb-10 flex items-center justify-center">
        <img 
          src="https://img.freepik.com/free-vector/two-factor-authentication-concept-illustration_114360-5488.jpg" 
          className="h-full object-contain" 
          alt="OTP"
        />
      </div>

      <div className="space-y-8">
        <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xl shadow-slate-100 flex flex-col items-center gap-4 relative">
          <div className="absolute top-0 left-0 w-1 h-full bg-blue-600 rounded-l-full"></div>
          <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest w-full">Selected Number</span>
          <div className="w-full flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-2xl">🇳🇵</span>
              <span className="font-black text-slate-900 text-lg">{phoneNumber}</span>
            </div>
            <button className="px-4 py-2 bg-blue-50 text-blue-600 rounded-xl text-[10px] font-black uppercase tracking-widest border border-blue-100">
              Edit
            </button>
          </div>
          <p className="text-[9px] font-bold text-slate-400">We have sent a 6 digit code to your mobile number</p>
        </div>

        <div className="space-y-4">
          <label className="text-[10px] font-black text-blue-600 uppercase tracking-widest ml-1">Enter OTP</label>
          <div className="flex justify-between gap-2">
            {otp.map((digit, idx) => (
              <input
                key={idx}
                id={`otp-${idx}`}
                type="text"
                maxLength={1}
                value={digit}
                onChange={(e) => handleOtpChange(idx, e.target.value)}
                className="w-12 h-14 bg-slate-50 border-2 border-slate-100 rounded-xl text-center font-black text-xl focus:border-blue-500 focus:bg-white transition-all"
              />
            ))}
          </div>
          <div className="flex justify-between items-center px-1">
            <div className="flex items-center gap-2 text-slate-400 font-black text-[10px] uppercase">
               <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
               00:{timer < 10 ? `0${timer}` : timer}
            </div>
            <button className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Resend OTP</button>
          </div>
        </div>

        <div className="space-y-6">
          <button 
            onClick={handleVerifyOtp}
            className="w-full h-14 bg-gradient-to-r from-blue-600 to-blue-400 text-white rounded-full font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 shadow-xl shadow-blue-600/20 cursor-pointer"
          >
             <ShieldCheck className="w-6 h-6" /> Verify OTP
          </button>
          
          <button 
            onClick={() => setStep('choice')}
            className="w-full h-14 bg-white border border-slate-200 text-slate-600 rounded-full font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 shadow-sm"
          >
            <ChevronLeft className="w-4 h-4" /> Change Phone Number
          </button>

          <div className="bg-blue-50/50 p-4 rounded-3xl flex items-center gap-4">
            <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm">
              <Lock className="w-6 h-6 text-blue-600" />
            </div>
            <div className="space-y-0.5">
              <p className="text-[10px] font-black text-blue-600 uppercase tracking-tight">Your security is our priority.</p>
              <p className="text-[9px] font-bold text-slate-400">We never share your information.</p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );

  return (step === 'choice' || step === 'otp_verify') ? (
    <div className="fixed inset-0 z-[200] bg-white overflow-hidden">
      <div className="w-full h-full flex flex-col md:flex-row relative">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 z-50 p-3 bg-slate-100 hover:bg-slate-200 rounded-2xl text-slate-500 transition-all shadow-lg"
        >
          <X className="w-6 h-6" />
        </button>

        <AnimatePresence mode="wait">
          {step === 'choice' ? (
            <motion.div 
              key="choice"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col md:flex-row h-full w-full"
            >
              {/* Left Side: Illustration & Branding (Refined) */}
              <div className="hidden lg:flex flex-[0.8] bg-blue-600 p-16 flex-col justify-between text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 w-[30rem] h-[30rem] bg-white/10 rounded-full -mr-32 -mt-32 blur-[80px]"></div>
                <div className="absolute bottom-0 left-0 w-[30rem] h-[30rem] bg-blue-400/20 rounded-full -ml-32 -mb-32 blur-[100px]"></div>
                
                <div className="relative z-10 space-y-6">
                  <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-xl">
                    <span className="text-xl font-black text-blue-600">RST</span>
                  </div>
                  <div className="space-y-4">
                    <h2 className="text-4xl font-black tracking-tight leading-[1.1]">Digital<br/>Solutions</h2>
                    <p className="text-blue-100 font-bold text-lg opacity-90 max-w-xs">Empowering your digital presence with seamless security.</p>
                  </div>
                </div>

                <div className="relative z-10 flex flex-wrap gap-4">
                  {[
                    { icon: Lock, label: 'Secure' },
                    { icon: Zap, label: 'Fast' },
                    { icon: ShieldCheck, label: 'Verified' }
                  ].map((f, i) => (
                    <div key={i} className="flex items-center gap-3 p-3 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/10">
                      <f.icon className="w-5 h-5" />
                      <span className="text-[10px] font-black uppercase tracking-widest">{f.label}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Side: Form Content */}
              <div className="flex-1 flex flex-col items-center justify-center p-8 md:p-12 h-full overflow-y-auto no-scrollbar">
                <div className="w-full max-w-md">
                  {renderChoiceStep()}
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="otp"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="w-full h-full flex flex-col md:flex-row"
            >
               {/* Illustration Sidebar (Refined) */}
               <div className="hidden lg:flex flex-[0.8] bg-slate-900 p-16 flex-col justify-center text-white relative overflow-hidden">
                 <div className="absolute top-0 left-0 w-full h-full opacity-20 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-600 via-transparent to-transparent"></div>
                 <div className="relative z-10 text-center space-y-8">
                    <div className="w-24 h-24 bg-blue-600 rounded-[2rem] flex items-center justify-center mx-auto shadow-2xl shadow-blue-600/30">
                      <ShieldCheck className="w-12 h-12" />
                    </div>
                    <div className="space-y-4">
                      <h3 className="text-3xl font-black tracking-tight">Identity Check</h3>
                      <p className="text-slate-400 font-bold text-lg max-w-xs mx-auto">Bas ek aakhri step. Hamein confirm karna hai ke ye aap hi hain.</p>
                    </div>
                 </div>
               </div>

               <div className="flex-1 flex flex-col items-center justify-center p-8 md:p-12 h-full overflow-y-auto no-scrollbar">
                 <div className="w-full max-w-md">
                   {renderOtpStep()}
                 </div>
               </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  ) : null;
};

