import React, { useState } from 'react';
import { CartItem } from '../types';
import { ShoppingCart, Trash2, Plus, Minus, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface CartScreenProps {
  cartItems: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

export const CartScreen: React.FC<CartScreenProps> = ({
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart
}) => {
  const [isCheckout, setIsCheckout] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('Cash / Pay on Delivery');
  const [orderComplete, setOrderComplete] = useState(false);

  const subtotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const shipping = subtotal > 0 ? 15 : 0;
  const grandTotal = subtotal + shipping;

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Save cart order directly to main orders list
    try {
      const orderRef = `RST-ORD-${Math.floor(100000 + Math.random() * 900000)}`;
      const itemNames = cartItems.map(i => `${i.title} (x${i.quantity})`).join(', ');
      
      const newProductOrder = {
        id: orderRef,
        customerName: 'Tech Customer',
        email: 'customer@tech.com',
        phone: 'N/A',
        address: address || 'Kathmandu',
        categoryName: 'Product Purchase',
        subCategoryName: itemNames,
        estimatedPrice: grandTotal,
        status: 'Received',
        createdAt: new Date().toISOString().split('T')[0]
      };

      const existingOrders = JSON.parse(localStorage.getItem('techeverywhere_orders') || '[]');
      localStorage.setItem('techeverywhere_orders', JSON.stringify([newProductOrder, ...existingOrders]));
    } catch (err) {
      console.error('Error dispatching cart order to main orders list:', err);
    }

    setOrderComplete(true);
    onClearCart();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6 pb-24 text-slate-900 dark:text-slate-100">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-black flex items-center gap-2">
          <ShoppingCart className="w-6 h-6 text-blue-600" /> Shopping Cart ({cartItems.length})
        </h1>
      </div>

      {orderComplete ? (
        <div className="p-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 mx-auto flex items-center justify-center">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <h2 className="text-xl font-bold">Order Successfully Placed!</h2>
          <p className="text-xs text-slate-500">
            Thank you! Your tech product / service order has been received. Our team will process it shortly.
          </p>
          <button
            onClick={() => setOrderComplete(false)}
            className="px-6 py-2.5 bg-blue-600 text-white rounded-xl text-xs font-bold transition cursor-pointer"
          >
            Continue Browsing
          </button>
        </div>
      ) : cartItems.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
          <ShoppingCart className="w-12 h-12 text-slate-400 mx-auto" />
          <h3 className="text-sm font-bold">Your cart is currently empty</h3>
          <p className="text-xs text-slate-500">Add products or services from the homepage to checkout.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Cart Items List */}
          <div className="lg:col-span-2 space-y-3">
            {cartItems.map((item) => (
              <div
                key={item.id}
                className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-4"
              >
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">{item.title}</h3>
                  <span className="text-xs text-slate-400">{item.category}</span>
                  <div className="text-xs font-extrabold text-blue-600 dark:text-blue-400 mt-1">
                    ${item.price} each
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex items-center border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800">
                    <button
                      onClick={() => onUpdateQuantity(item.id, -1)}
                      className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="px-2 text-xs font-bold">{item.quantity}</span>
                    <button
                      onClick={() => onUpdateQuantity(item.id, 1)}
                      className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <button
                    onClick={() => onRemoveItem(item.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-500 transition cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Checkout / Order Summary */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200/80 dark:border-slate-800 space-y-4 h-fit">
            <h2 className="text-base font-bold">Order Summary</h2>

            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span className="font-semibold text-slate-900 dark:text-slate-100">${subtotal}</span>
              </div>
              <div className="flex justify-between">
                <span>Estimated Shipping / Service Delivery:</span>
                <span className="font-semibold text-slate-900 dark:text-slate-100">${shipping}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-sm font-bold text-slate-900 dark:text-slate-100">
                <span>Total Amount:</span>
                <span className="text-blue-600 dark:text-blue-400">${grandTotal}</span>
              </div>
            </div>

            {!isCheckout ? (
              <button
                onClick={() => setIsCheckout(true)}
                className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-2"
              >
                Proceed to Checkout <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <form onSubmit={handleCheckoutSubmit} className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">Shipping Address</label>
                  <input
                    type="text"
                    required
                    placeholder="Street, City, ZIP"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">Payment Method</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  >
                    <option value="Cash / Pay on Delivery">Cash / Pay on Delivery</option>
                    <option value="Credit / Debit Card">Credit / Debit Card</option>
                    <option value="UPI / Online Transfer">UPI / Online Transfer</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition cursor-pointer mt-2"
                >
                  Confirm & Place Order (${grandTotal})
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
