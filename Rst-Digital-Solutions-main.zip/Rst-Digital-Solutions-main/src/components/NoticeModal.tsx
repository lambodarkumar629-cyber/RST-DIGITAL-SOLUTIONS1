import React from 'react';
import { X, CheckCircle2, Phone, Mail, MessageSquare } from 'lucide-react';

interface NoticeModalProps {
  onClose: () => void;
  onConfirm: () => void;
}

export const NoticeModal: React.FC<NoticeModalProps> = ({ onClose, onConfirm }) => {
  return (
    <div className="fixed inset-0 z-[150] bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 font-sans">
      <div className="bg-white w-full max-w-3xl max-h-[90vh] rounded-[2.5rem] shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-300">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-blue-600 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-lg font-black uppercase tracking-tight">RST Digital Solutions Notice</h2>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-8 sm:p-10 space-y-10 custom-scrollbar">
          {/* Nepali Version */}
          <div className="space-y-4">
            <div className="inline-block px-4 py-1.5 bg-blue-50 text-blue-700 rounded-full text-[10px] font-black uppercase tracking-widest border border-blue-100 mb-2">
              नेपाली संस्करण
            </div>
            <h3 className="text-2xl font-black text-slate-900 leading-tight">
              Welcome to RST Digital Solutions<br />
              <span className="text-blue-600">RST Digital Solutions मा स्वागत छ।</span>
            </h3>
            
            <div className="space-y-4 text-slate-600 font-bold leading-relaxed">
              <p className="text-lg text-slate-900 font-black">हाम्रो सेवाप्रति विश्वास गर्नु भएकोमा हार्दिक धन्यवाद।</p>
              <p>हामी तपाईंलाई उच्च गुणस्तरका, भरपर्दा र व्यावसायिक डिजिटल तथा प्राविधिक सेवाहरू प्रदान गर्न प्रतिबद्ध छौं।</p>
              <p className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100 text-slate-900">
                यदि तपाईं हाम्रो सेवा लिन तयार हुनुहुन्छ भने, कृपया <span className="text-blue-600">Service Request Form</span> सही विवरणसहित भर्नुहोस्। तपाईंको अनुरोध प्राप्त भएपछि हाम्रो सहयोग टोलीले त्यसको समीक्षा गरी सकेसम्म छिटो तपाईंलाई सम्पर्क गर्नेछ।
              </p>
            </div>
          </div>

          <div className="h-px bg-slate-100" />

          {/* English Version */}
          <div className="space-y-4">
            <div className="inline-block px-4 py-1.5 bg-slate-100 text-slate-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-slate-200 mb-2">
              English Version
            </div>
            <h3 className="text-2xl font-black text-slate-900 leading-tight">
              Thank you for choosing <span className="text-blue-600">RST Digital Solutions</span>.
            </h3>
            
            <div className="space-y-4 text-slate-600 font-bold leading-relaxed">
              <p className="text-lg text-slate-900 font-black">We are committed to providing professional, reliable, and high-quality digital and technical services.</p>
              <p className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100 text-slate-900">
                If you are ready to proceed with our services, please complete the Service Request Form with accurate information. Once we receive your request, our support team will review it and contact you as soon as possible.
              </p>
            </div>
          </div>

          {/* Contact Board */}
          <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600 opacity-20 blur-3xl" />
            <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-blue-500" /> Need Assistance?
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center">
                  <Phone className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Call / WhatsApp</p>
                  <p className="text-sm font-black">+977-9704443289</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center">
                  <Mail className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Email Support</p>
                  <p className="text-sm font-black">rstdigitalsoluations@gmail.com</p>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center pt-4">
            <p className="text-sm font-black text-slate-900">Have a wonderful day!</p>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1 italic">Thank you for visiting. Please visit us again.</p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-8 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-4 shrink-0">
          <button 
            onClick={onClose}
            className="px-8 py-4 bg-white border border-slate-200 text-slate-600 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-100 transition shadow-sm"
          >
            Cancel
          </button>
          <button 
            onClick={onConfirm}
            className="px-12 py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-700 transition shadow-xl shadow-blue-600/30 flex items-center gap-2"
          >
            I UNDERSTAND (OK)
          </button>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #e2e8f0;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #cbd5e1;
        }
      `}</style>
    </div>
  );
};
