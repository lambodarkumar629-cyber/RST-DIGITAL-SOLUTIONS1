import React, { useState, useRef, useEffect } from 'react';
import { ArrowUp, Bot, User, Loader2, Sparkles } from 'lucide-react';
import Markdown from 'react-markdown';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
}

export const AIChatSection: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: "Hi! I'm ChatGPT, your AI assistant. How can I help you today? I can write content, generate code, answer questions, or assist you with any tech support."
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input.trim()
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chatgpt/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: userMessage.text,
          history: messages.filter(m => m.id !== 'welcome')
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to get response');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      
      let aiResponseText = '';
      const aiMessageId = (Date.now() + 1).toString();
      
      setMessages(prev => [...prev, {
        id: aiMessageId,
        role: 'model',
        text: ''
      }]);
      
      setIsLoading(false); // Disable spinner since we are streaming now

      if (reader) {
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          
          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split('\n');
          
          for (const line of lines) {
            if (line.startsWith('data: ') && line !== 'data: [DONE]') {
              try {
                const data = JSON.parse(line.slice(6));
                aiResponseText += data.text;
                
                setMessages(prev => prev.map(msg => 
                  msg.id === aiMessageId 
                    ? { ...msg, text: aiResponseText }
                    : msg
                ));
              } catch (e) {
                console.error("Error parsing stream data", e);
              }
            }
          }
        }
      }

    } catch (error) {
      console.error('Chat error:', error);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: "I'm sorry, I encountered an error while trying to process your request. Please try again."
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section className="py-6 bg-white">
      <div className="max-w-4xl mx-auto px-4">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">ChatGPT Assistant</h2>
            <p className="text-slate-500 text-xs">Integrated AI to help you with any task</p>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden flex flex-col h-[600px] shadow-sm">
          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 custom-scrollbar">
            {messages.map((msg) => (
              <div 
                key={msg.id} 
                className={`flex gap-4 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.role === 'model' && (
                  <div className="w-8 h-8 shrink-0 rounded-full bg-emerald-500 text-white flex items-center justify-center mt-1">
                    <Bot className="w-5 h-5" />
                  </div>
                )}
                
                <div className={`max-w-[85%] text-[15px] leading-relaxed ${
                  msg.role === 'user' 
                    ? 'bg-[#f4f4f4] text-slate-900 rounded-3xl px-5 py-2.5' 
                    : 'text-slate-800 py-1'
                }`}>
                  {msg.role === 'model' ? (
                    <div className="prose prose-sm prose-slate max-w-none [&>p]:mb-4 [&>pre]:bg-slate-800 [&>pre]:text-slate-100 [&>pre]:rounded-xl [&>pre]:p-4 [&>pre]:overflow-x-auto [&>code]:bg-slate-100 [&>code]:px-1.5 [&>code]:py-0.5 [&>code]:rounded-md [&>code]:text-[#d13b68] [&_img]:rounded-xl [&_img]:shadow-md [&_img]:max-w-full">
                      <Markdown>{msg.text}</Markdown>
                    </div>
                  ) : (
                    <p className="whitespace-pre-wrap">{msg.text}</p>
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-4 justify-start">
                <div className="w-8 h-8 shrink-0 rounded-full bg-emerald-500 text-white flex items-center justify-center mt-1">
                  <Bot className="w-5 h-5" />
                </div>
                <div className="py-2 flex items-center gap-2">
                  <Loader2 className="w-5 h-5 text-emerald-500 animate-spin" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-4 bg-white">
            <form onSubmit={handleSubmit} className="relative max-w-3xl mx-auto">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Message ChatGPT..."
                disabled={isLoading}
                className="w-full bg-[#f4f4f4] border border-transparent rounded-full pl-6 pr-14 py-3.5 text-[15px] focus:outline-none focus:bg-white focus:border-slate-300 focus:shadow-sm transition disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-black hover:bg-slate-800 disabled:bg-[#e5e5e5] disabled:text-slate-400 text-white rounded-full flex items-center justify-center transition"
              >
                <ArrowUp className="w-5 h-5" />
              </button>
            </form>
            <div className="text-center mt-2">
              <span className="text-[10px] text-slate-400">ChatGPT can make mistakes. Consider verifying important information.</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
