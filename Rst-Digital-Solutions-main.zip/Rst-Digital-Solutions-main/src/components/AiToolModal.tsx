import React, { useState } from 'react';
import { AiTool } from '../types';
import { X, Sparkles, Send, Copy, Check, Bot, Zap } from 'lucide-react';
import { motion } from 'motion/react';

interface AiToolModalProps {
  tool: AiTool;
  onClose: () => void;
  onRequestCustomAiService: (toolName: string, promptText: string) => void;
}

export const AiToolModal: React.FC<AiToolModalProps> = ({
  tool,
  onClose,
  onRequestCustomAiService
}) => {
  const [promptInput, setPromptInput] = useState(tool.samplePrompt);
  const [response, setResponse] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptInput.trim() || isGenerating) return;

    setIsGenerating(true);
    setResponse('');

    setTimeout(() => {
      let result = '';
      if (tool.id === 'ai_chat') {
        result = `Hello! Thank you for reaching out to TechEverywhere. Your laptop repair ticket #89201 is currently in progress. Our hardware specialist is replacing the display panel and will notify you as soon as testing is complete.`;
      } else if (tool.id === 'ai_image') {
        result = `[AI Image Generated Successfully]\nStyle: Photorealistic 8K render\nSubject: ${promptInput}\nDownload Link: High-Resolution PNG ready in studio dashboard.`;
      } else if (tool.id === 'ai_writer') {
        result = `Headline 1: Fast & Reliable Laptop Repair at Your Doorstep!\nHeadline 2: TechEverywhere - Smart Online Services, Anytime Anywhere.\nHeadline 3: Upgrade Your Workspace with Custom RTX 4080 Gaming PCs.`;
      } else if (tool.id === 'ai_voice') {
        result = `[AI Voice Audio Synthesized]\nDuration: 0:14 seconds\nVoice Model: Studio Professional (English - US)\nAudio Waveform ready for streaming.`;
      } else if (tool.id === 'ai_code') {
        result = `// React TypeScript Form Component\nexport const ServiceForm = () => {\n  const handleSubmit = (e: React.FormEvent) => {\n    e.preventDefault();\n    console.log("Form submitted successfully!");\n  };\n  return <form onSubmit={handleSubmit}><button type="submit">Submit Form</button></form>;\n};`;
      } else {
        result = `[AI Video Storyboard & Script Generated]\nScene 1: Close up of technician running hardware diagnostic (0s-5s).\nScene 2: Customer receiving verified repair receipt on mobile (5s-15s).\nScene 3: TechEverywhere logo animation (15s-20s).`;
      }

      setResponse(result);
      setIsGenerating(false);
    }, 900);
  };

  const handleCopy = () => {
    if (!response) return;
    navigator.clipboard.writeText(response);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="w-full max-w-xl bg-slate-900 text-white rounded-3xl border border-slate-800 shadow-2xl overflow-hidden my-6"
      >
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 relative border-b border-slate-800">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 text-purple-300 text-xs font-semibold uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4" /> AI Tool Playground
          </div>
          <h2 className="text-xl font-bold text-white">{tool.title}</h2>
          <p className="text-slate-300 text-xs mt-0.5">{tool.description}</p>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4">
          <form onSubmit={handleGenerate} className="space-y-3">
            <label className="block text-xs font-semibold text-slate-300">
              Enter AI Prompt or Requirements:
            </label>
            <textarea
              rows={3}
              value={promptInput}
              onChange={(e) => setPromptInput(e.target.value)}
              placeholder="Describe what you want AI to generate..."
              className="w-full px-3.5 py-2.5 text-xs rounded-2xl bg-slate-800 border border-slate-700 text-slate-100 focus:outline-none focus:ring-2 focus:ring-purple-500/40"
            />
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-slate-400">Powered by Gemini AI Engine</span>
              <button
                type="submit"
                disabled={isGenerating}
                className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-purple-600/30 transition cursor-pointer flex items-center gap-1.5"
              >
                {isGenerating ? <Zap className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                {isGenerating ? 'Generating...' : 'Run AI Generation'}
              </button>
            </div>
          </form>

          {/* AI Output Result Box */}
          {response && (
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2 relative">
              <div className="flex items-center justify-between text-xs font-bold text-purple-400 border-b border-slate-800/80 pb-2">
                <span className="flex items-center gap-1.5"><Bot className="w-4 h-4" /> AI Output Result</span>
                <button
                  onClick={handleCopy}
                  className="text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy Result'}</span>
                </button>
              </div>
              <p className="text-xs text-slate-200 whitespace-pre-wrap leading-relaxed font-mono pt-1">
                {response}
              </p>
            </div>
          )}

          {/* Hire Expert Action */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-400">Need a custom AI solution tailored for your business?</span>
            <button
              onClick={() => {
                onRequestCustomAiService(tool.title, promptInput);
                onClose();
              }}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-purple-300 text-xs font-bold rounded-xl transition cursor-pointer"
            >
              Order Custom AI Form &rarr;
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
