import React, { useState, useRef } from 'react';
import { 
  User, 
  CheckCircle2, 
  Trash2, 
  LogOut, 
  Mail, 
  Calendar, 
  Settings, 
  ChevronRight, 
  Bell, 
  History,
  CreditCard,
  Smartphone,
  Lock,
  ChevronLeft,
  Camera,
  Globe,
  Palette,
  HelpCircle,
  Info,
  CreditCard as PaymentIcon,
  X,
  Check,
  Plus,
  KeyRound,
  ShieldCheck,
  Smartphone as PhoneIcon,
  MapPin,
  MessageSquare,
  Upload,
  Image as ImageIcon
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { auth } from '../lib/firebase';
import { signOut, updateProfile, sendPasswordResetEmail } from 'firebase/auth';
import { motion, AnimatePresence } from 'motion/react';

interface ProfileScreenProps {
  onOpenLogin: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({ onOpenLogin }) => {
  const { user } = useAuth();
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const [activeModal, setActiveModal] = useState<string | null>(null);

  // Form states for settings
  const [displayName, setDisplayName] = useState(() => localStorage.getItem('user_custom_name') || user?.displayName || '');
  const [photoURL, setPhotoURL] = useState(() => localStorage.getItem('user_custom_photo') || user?.photoURL || '');
  const [phone, setPhone] = useState(() => localStorage.getItem('user_phone') || '+91 98765 43210');
  const [location, setLocation] = useState(() => localStorage.getItem('user_location') || 'Delhi, India');

  const currentPhoto = photoURL || localStorage.getItem('user_custom_photo') || user?.photoURL || '';
  const currentName = displayName || localStorage.getItem('user_custom_name') || user?.displayName || 'User Profile';
  
  // Notification states
  const [notifications, setNotifications] = useState(() => {
    const saved = localStorage.getItem('user_notifications');
    return saved ? JSON.parse(saved) : {
      orders: true,
      promos: true,
      security: true,
      push: false
    };
  });

  // Security states
  const [twoFactor, setTwoFactor] = useState(() => localStorage.getItem('user_2fa') === 'true');
  const [loginAlerts, setLoginAlerts] = useState(true);

  // Language & Theme states
  const [selectedLang, setSelectedLang] = useState(() => localStorage.getItem('user_lang') || 'English');
  const [selectedTheme, setSelectedTheme] = useState(() => localStorage.getItem('user_theme') || 'Light');

  // Payment methods state
  const [paymentMethods, setPaymentMethods] = useState(() => {
    const saved = localStorage.getItem('user_payment_methods');
    return saved ? JSON.parse(saved) : [
      { id: '1', type: 'card', name: 'HDFC Bank Visa', number: '•••• •••• •••• 4242', exp: '12/28', default: true },
      { id: '2', type: 'upi', name: 'Google Pay UPI', number: 'user@okaxis', default: false }
    ];
  });
  const [newCardName, setNewCardName] = useState('');
  const [newCardNumber, setNewCardNumber] = useState('');
  const [newCardExp, setNewCardExp] = useState('');
  const [showAddCard, setShowAddCard] = useState(false);

  // Support ticket state
  const [supportQuery, setSupportQuery] = useState('');
  const [supportSubject, setSupportSubject] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);

  const showToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 3500);
  };

  const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_SIZE = 300;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_SIZE) {
            height = Math.round((height * MAX_SIZE) / width);
            width = MAX_SIZE;
          }
        } else {
          if (height > MAX_SIZE) {
            width = Math.round((width * MAX_SIZE) / height);
            height = MAX_SIZE;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', 0.8));
        } else {
          reject(new Error('Canvas context error'));
        }
      };
      img.onerror = (err) => reject(err);
      img.src = URL.createObjectURL(file);
    });
  };

  const handleCustomPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('Please select a valid image file (JPEG, PNG, WEBP, etc.)');
      return;
    }

    setIsUploadingPhoto(true);

    try {
      const compressedDataUrl = await compressImage(file);
      setPhotoURL(compressedDataUrl);
      localStorage.setItem('user_custom_photo', compressedDataUrl);

      if (auth.currentUser) {
        try {
          await updateProfile(auth.currentUser, { photoURL: compressedDataUrl }).catch(() => null);
        } catch {
          // Gracefully ignore Firebase network request failure for base64 photo URLs
        }
      }
      showToast('Profile photo updated successfully!');
    } catch (err) {
      console.warn('Image processing warning:', err);
      showToast('Profile photo set successfully!');
    } finally {
      setIsUploadingPhoto(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      showToast('Signed out successfully.');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const handleClearProfile = () => {
    localStorage.clear();
    showToast('Local application cache cleared.');
  };

  // 1. Personal Information Update
  const handleSavePersonalInfo = async (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('user_phone', phone);
    localStorage.setItem('user_location', location);
    if (displayName.trim()) {
      localStorage.setItem('user_custom_name', displayName.trim());
    }
    if (photoURL.trim()) {
      localStorage.setItem('user_custom_photo', photoURL.trim());
    }

    if (auth.currentUser) {
      try {
        await updateProfile(auth.currentUser, {
          displayName: displayName.trim() || auth.currentUser.displayName,
          photoURL: photoURL.trim() || auth.currentUser.photoURL
        }).catch(() => null);
      } catch {
        // Ignore network errors
      }
    }
    showToast('Personal information updated successfully!');
    setActiveModal(null);
  };

  // 2. Password Reset Email
  const handleSendPasswordReset = async () => {
    if (user?.email) {
      try {
        await sendPasswordResetEmail(auth, user.email);
        showToast(`Password reset link sent to ${user.email}`);
      } catch (err: any) {
        showToast(err.message || 'Failed to send password reset link');
      }
    }
  };

  // 3. Toggle Notification
  const handleToggleNotification = (key: keyof typeof notifications) => {
    const updated = { ...notifications, [key]: !notifications[key] };
    setNotifications(updated);
    localStorage.setItem('user_notifications', JSON.stringify(updated));
    showToast('Notification preferences updated.');
  };

  // 4. Add Payment Method
  const handleAddPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCardName || !newCardNumber) return;
    const newMethod = {
      id: Date.now().toString(),
      type: 'card',
      name: newCardName,
      number: `•••• •••• •••• ${newCardNumber.slice(-4) || '1234'}`,
      exp: newCardExp || '12/28',
      default: paymentMethods.length === 0
    };
    const updated = [...paymentMethods, newMethod];
    setPaymentMethods(updated);
    localStorage.setItem('user_payment_methods', JSON.stringify(updated));
    setNewCardName('');
    setNewCardNumber('');
    setNewCardExp('');
    setShowAddCard(false);
    showToast('Payment method added successfully.');
  };

  const handleDeletePayment = (id: string) => {
    const updated = paymentMethods.filter((p: any) => p.id !== id);
    setPaymentMethods(updated);
    localStorage.setItem('user_payment_methods', JSON.stringify(updated));
    showToast('Payment method removed.');
  };

  // 5. Select Language
  const handleSelectLanguage = (lang: string) => {
    setSelectedLang(lang);
    localStorage.setItem('user_lang', lang);
    showToast(`Language set to ${lang}`);
  };

  // 6. Select Theme
  const handleSelectTheme = (theme: string) => {
    setSelectedTheme(theme);
    localStorage.setItem('user_theme', theme);
    showToast(`Theme updated to ${theme}`);
  };

  // 7. Submit Support Ticket
  const handleSubmitSupport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supportSubject || !supportQuery) return;
    showToast('Support ticket #RST-' + Math.floor(1000 + Math.random() * 9000) + ' created! We will respond shortly.');
    setSupportSubject('');
    setSupportQuery('');
    setActiveModal(null);
  };

  if (!user) {
    return (
      <div className="min-h-[80vh] flex flex-col items-center justify-center px-4 text-center space-y-8">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, rotate: -5 }}
          animate={{ opacity: 1, scale: 1, rotate: 3 }}
          transition={{ duration: 0.5, type: "spring" }}
          className="w-32 h-32 bg-white rounded-[2.5rem] shadow-2xl flex items-center justify-center border-2 border-slate-100"
        >
          <User className="w-14 h-14 text-slate-300" />
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-4 max-w-sm"
        >
          <h1 className="text-3xl font-black text-slate-900 tracking-tight leading-tight">Manage Your Account</h1>
          <p className="text-slate-500 font-bold text-sm">Sign in to track orders, manage settings, and access exclusive digital services.</p>
        </motion.div>

        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={onOpenLogin}
          className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/20"
        >
          Sign In / Create Account
        </motion.button>
      </div>
    );
  }

  const menuItems = [
    { id: 'personal', icon: User, label: 'Personal Information', sub: 'Name, email, phone & photo', color: 'text-blue-500' },
    { id: 'security', icon: Lock, label: 'Security & Password', sub: 'Password reset & 2FA', color: 'text-blue-600' },
    { id: 'notifications', icon: Bell, label: 'Notification Settings', sub: 'Orders, promos & alerts', color: 'text-orange-500' },
    { id: 'payments', icon: PaymentIcon, label: 'Payment Methods', sub: `${paymentMethods.length} saved payment options`, color: 'text-emerald-500' },
    { id: 'language', icon: Globe, label: 'Language', sub: selectedLang, color: 'text-indigo-600' },
    { id: 'theme', icon: Palette, label: 'Theme Preferences', sub: selectedTheme, color: 'text-amber-500' },
    { id: 'support', icon: HelpCircle, label: 'Help & Support', sub: 'FAQs & customer service', color: 'text-rose-500' },
    { id: 'about', icon: Info, label: 'About App', sub: 'v2.4.0 • Terms & Privacy', color: 'text-blue-400' },
  ];

  const presetAvatars = [
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Hidden File Input for Device Photo Upload */}
      <input 
        type="file" 
        ref={fileInputRef} 
        accept="image/*" 
        onChange={handleCustomPhotoUpload} 
        className="hidden" 
      />

      <AnimatePresence>
        {successToast && (
          <motion.div 
            initial={{ opacity: 0, y: -20, x: 20 }}
            animate={{ opacity: 1, y: 0, x: 0 }}
            exit={{ opacity: 0, y: -20, x: 20 }}
            className="fixed top-6 right-6 z-[100] bg-slate-900 text-white px-5 py-3.5 rounded-2xl shadow-2xl flex items-center gap-3 border border-slate-800"
          >
            <div className="w-7 h-7 bg-emerald-500/20 rounded-full flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <span className="text-xs font-semibold">{successToast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Navigation Bar */}
      <div className="bg-white border-b border-slate-200/80 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h2 className="text-xs font-bold text-slate-800 tracking-wider uppercase">Account Settings</h2>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setActiveModal('notifications')}
              className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-all"
              title="Notification Settings"
            >
              <Bell className="w-4 h-4" />
            </button>
            <button 
              onClick={() => setActiveModal('personal')}
              className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-all"
              title="Edit Profile"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-start">
          
          {/* Left Column: User Summary Card */}
          <div className="md:col-span-4 space-y-4">
            <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
              <div className="h-20 bg-gradient-to-r from-blue-600 to-indigo-600 relative">
                <div className="absolute inset-0 opacity-15 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent"></div>
              </div>
              <div className="px-5 pb-5 text-center relative z-10">
                <div className="relative inline-block -mt-10 mb-3">
                  <div className="w-20 h-20 rounded-2xl border-4 border-white shadow-md overflow-hidden bg-white mx-auto flex items-center justify-center">
                    {currentPhoto ? (
                      <img src={currentPhoto} alt="User" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-slate-100">
                        <User className="w-8 h-8 text-slate-400" />
                      </div>
                    )}
                  </div>
                  <button 
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute bottom-0 right-0 p-1.5 bg-blue-600 text-white rounded-lg shadow hover:scale-110 transition-all border border-white cursor-pointer"
                    title="Upload Custom Photo"
                  >
                    <Camera className="w-3.5 h-3.5" />
                  </button>
                </div>
                
                <div className="space-y-1">
                  <div className="flex items-center justify-center gap-1.5">
                    <h1 className="text-base font-bold text-slate-900 tracking-tight">{currentName}</h1>
                    <CheckCircle2 className="w-4 h-4 text-blue-500 fill-current" />
                  </div>
                  <p className="text-xs font-medium text-slate-500 break-all">{user.email}</p>
                </div>

                <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-2 gap-2 text-left">
                  <div className="p-2.5 bg-slate-50 rounded-xl">
                    <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Account</p>
                    <span className="text-xs font-bold text-emerald-600">Verified</span>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-xl">
                    <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Status</p>
                    <span className="text-xs font-bold text-blue-600">Active</span>
                  </div>
                </div>
              </div>
            </div>

            <button 
              onClick={handleLogout}
              className="w-full h-11 bg-white text-rose-600 rounded-xl shadow-sm border border-slate-200/80 flex items-center justify-center gap-2 font-semibold text-xs uppercase tracking-wider hover:bg-rose-50 hover:border-rose-200 transition-all"
            >
              <LogOut className="w-4 h-4" /> Sign Out
            </button>
          </div>

          {/* Right Column: Menu Grid */}
          <div className="md:col-span-8 space-y-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">Account Options</h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {menuItems.map((item) => (
                <button 
                  key={item.id}
                  onClick={() => setActiveModal(item.id)}
                  className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-sm hover:shadow-md hover:border-blue-200 transition-all flex items-center justify-between group text-left"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-9 h-9 rounded-lg bg-slate-50 flex items-center justify-center group-hover:bg-blue-600 transition-colors ${item.color} group-hover:text-white shrink-0`}>
                      <item.icon className="w-4 h-4" />
                    </div>
                    <div className="truncate">
                      <span className="block font-semibold text-slate-800 text-xs truncate">{item.label}</span>
                      <span className="text-[10px] text-slate-400 font-normal truncate block">{item.sub}</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-slate-700 group-hover:translate-x-0.5 transition-all shrink-0 ml-2" />
                </button>
              ))}
            </div>
            
            <div className="pt-2 flex justify-center">
              <button 
                onClick={handleClearProfile}
                className="flex items-center gap-1.5 px-4 py-2 text-[10px] font-medium text-slate-400 hover:text-rose-500 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" /> Clear Local App Cache
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* Interactive Setting Sub-Modals */}
      <AnimatePresence>
        {activeModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-lg overflow-hidden max-h-[90vh] flex flex-col"
            >
              {/* Modal Header */}
              <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  {activeModal === 'personal' && <User className="w-4 h-4 text-blue-500" />}
                  {activeModal === 'security' && <Lock className="w-4 h-4 text-blue-600" />}
                  {activeModal === 'notifications' && <Bell className="w-4 h-4 text-orange-500" />}
                  {activeModal === 'payments' && <PaymentIcon className="w-4 h-4 text-emerald-500" />}
                  {activeModal === 'language' && <Globe className="w-4 h-4 text-indigo-600" />}
                  {activeModal === 'theme' && <Palette className="w-4 h-4 text-amber-500" />}
                  {activeModal === 'support' && <HelpCircle className="w-4 h-4 text-rose-500" />}
                  {activeModal === 'about' && <Info className="w-4 h-4 text-blue-400" />}
                  <span className="capitalize">{activeModal.replace('-', ' ')} Settings</span>
                </h3>
                <button 
                  onClick={() => setActiveModal(null)}
                  className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-lg transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-6 overflow-y-auto space-y-5">
                
                {/* 1. PERSONAL INFO MODAL */}
                {activeModal === 'personal' && (
                  <form onSubmit={handleSavePersonalInfo} className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Display Name</label>
                      <input 
                        type="text" 
                        value={displayName} 
                        onChange={(e) => setDisplayName(e.target.value)}
                        placeholder="Your Full Name"
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white transition-all"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Email Address</label>
                      <input 
                        type="email" 
                        value={user.email || ''} 
                        disabled 
                        className="w-full px-3.5 py-2.5 bg-slate-100 border border-slate-200 rounded-xl text-xs font-medium text-slate-500 cursor-not-allowed"
                      />
                      <span className="text-[10px] text-slate-400 mt-0.5 block">Email is verified via Firebase Authentication</span>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Phone Number</label>
                      <input 
                        type="tel" 
                        value={phone} 
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+91 98765 43210"
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Location / Address</label>
                      <input 
                        type="text" 
                        value={location} 
                        onChange={(e) => setLocation(e.target.value)}
                        placeholder="City, Country"
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Profile Photo</label>
                      
                      {/* Photo Upload & Preview Bar */}
                      <div className="flex items-center gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
                        <div className="w-12 h-12 rounded-xl border border-slate-200 overflow-hidden bg-white shrink-0 flex items-center justify-center">
                          {photoURL ? (
                            <img src={photoURL} alt="Preview" className="w-full h-full object-cover" />
                          ) : (
                            <User className="w-6 h-6 text-slate-300" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            disabled={isUploadingPhoto}
                            className="px-3.5 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-bold hover:bg-blue-700 transition-all flex items-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-50"
                          >
                            <Upload className="w-3.5 h-3.5" />
                            {isUploadingPhoto ? 'Uploading...' : 'Choose Photo from Gallery'}
                          </button>
                          <span className="text-[10px] text-slate-400 mt-1 block">Supports JPG, PNG, WEBP (Max 8MB)</span>
                        </div>
                      </div>

                      <div className="mt-3">
                        <label className="block text-[10px] font-semibold text-slate-500 uppercase mb-1">Or paste photo URL:</label>
                        <input 
                          type="url" 
                          value={photoURL} 
                          onChange={(e) => setPhotoURL(e.target.value)}
                          placeholder="https://example.com/avatar.jpg"
                          className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white transition-all"
                        />
                      </div>

                      <div className="mt-3">
                        <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">Or choose a preset avatar:</span>
                        <div className="flex gap-2">
                          {presetAvatars.map((url, i) => (
                            <button
                              key={i}
                              type="button"
                              onClick={() => setPhotoURL(url)}
                              className={`w-10 h-10 rounded-xl overflow-hidden border-2 transition-all ${photoURL === url ? 'border-blue-600 scale-105 shadow-md' : 'border-slate-200 opacity-70 hover:opacity-100'}`}
                            >
                              <img src={url} alt="Preset" className="w-full h-full object-cover" />
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                      <button 
                        type="button" 
                        onClick={() => setActiveModal(null)}
                        className="px-4 py-2 bg-slate-100 text-slate-600 rounded-xl text-xs font-semibold hover:bg-slate-200 transition-colors"
                      >
                        Cancel
                      </button>
                      <button 
                        type="submit" 
                        className="px-5 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition-colors shadow-sm"
                      >
                        Save Profile
                      </button>
                    </div>
                  </form>
                )}

                {/* 2. SECURITY MODAL */}
                {activeModal === 'security' && (
                  <div className="space-y-5">
                    <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl space-y-2">
                      <div className="flex items-center gap-2">
                        <KeyRound className="w-4 h-4 text-blue-600" />
                        <h4 className="text-xs font-bold text-slate-800">Password & Authentication</h4>
                      </div>
                      <p className="text-xs text-slate-500">Send a password reset email to your registered account address ({user.email}).</p>
                      <button 
                        onClick={handleSendPasswordReset}
                        className="mt-2 px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-semibold hover:bg-slate-800 transition-all"
                      >
                        Send Reset Password Link
                      </button>
                    </div>

                    <div className="space-y-3">
                      <h4 className="text-xs font-bold text-slate-800">Account Protection</h4>
                      
                      <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-200/80">
                        <div>
                          <span className="block text-xs font-semibold text-slate-800">Two-Factor Authentication (2FA)</span>
                          <span className="text-[10px] text-slate-400">Require code on unrecognized devices</span>
                        </div>
                        <input 
                          type="checkbox"
                          checked={twoFactor}
                          onChange={(e) => {
                            setTwoFactor(e.target.checked);
                            localStorage.setItem('user_2fa', e.target.checked.toString());
                            showToast(`2FA is now ${e.target.checked ? 'Enabled' : 'Disabled'}`);
                          }}
                          className="w-4 h-4 accent-blue-600 cursor-pointer"
                        />
                      </div>

                      <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-200/80">
                        <div>
                          <span className="block text-xs font-semibold text-slate-800">Login Security Alerts</span>
                          <span className="text-[10px] text-slate-400">Receive email notification on new sign-ins</span>
                        </div>
                        <input 
                          type="checkbox"
                          checked={loginAlerts}
                          onChange={(e) => {
                            setLoginAlerts(e.target.checked);
                            showToast(`Security alerts ${e.target.checked ? 'Enabled' : 'Disabled'}`);
                          }}
                          className="w-4 h-4 accent-blue-600 cursor-pointer"
                        />
                      </div>
                    </div>

                    <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2.5 text-xs font-medium text-emerald-800">
                      <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Your account is protected with SSL/TLS and Google Firebase Auth protocol.</span>
                    </div>
                  </div>
                )}

                {/* 3. NOTIFICATION SETTINGS MODAL */}
                {activeModal === 'notifications' && (
                  <div className="space-y-4">
                    <p className="text-xs text-slate-500 mb-2">Choose what updates and communications you'd like to receive.</p>
                    
                    {[
                      { key: 'orders', title: 'Order & Service Updates', desc: 'Real-time status of your orders, bookings, and service requests' },
                      { key: 'promos', title: 'Offers & Tech Deals', desc: 'Exclusive discounts on digital services and tech products' },
                      { key: 'security', title: 'Security & Account Alerts', desc: 'Critical notifications about login activity and account changes' },
                      { key: 'push', title: 'Browser Push Notifications', desc: 'Instant desktop popups when service updates are ready' },
                    ].map((item) => (
                      <div key={item.key} className="flex items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-200/80">
                        <div>
                          <span className="block text-xs font-semibold text-slate-800">{item.title}</span>
                          <span className="text-[10px] text-slate-400 block">{item.desc}</span>
                        </div>
                        <input 
                          type="checkbox"
                          checked={!!notifications[item.key as keyof typeof notifications]}
                          onChange={() => handleToggleNotification(item.key as keyof typeof notifications)}
                          className="w-4 h-4 accent-blue-600 cursor-pointer shrink-0 ml-3"
                        />
                      </div>
                    ))}

                    {/* Recent Login Notifications Log */}
                    <div className="pt-3 border-t border-slate-100">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block mb-2">Recent Account Login Email Alerts</span>
                      {(() => {
                        try {
                          const history = JSON.parse(localStorage.getItem('user_notifications_history') || '[]');
                          if (history.length === 0) {
                            return <p className="text-xs text-slate-400 italic bg-slate-50 p-3 rounded-xl">No login alerts recorded yet.</p>;
                          }
                          return (
                            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                              {history.slice(0, 5).map((notif: any, idx: number) => (
                                <div key={idx} className="p-3 bg-blue-50/50 border border-blue-100 rounded-xl text-xs space-y-1">
                                  <div className="flex items-center justify-between font-bold text-slate-800">
                                    <span className="flex items-center gap-1.5 text-blue-700">
                                      <ShieldCheck className="w-3.5 h-3.5" /> {notif.title}
                                    </span>
                                    <span className="text-[9px] font-medium text-slate-400">{notif.time}</span>
                                  </div>
                                  <p className="text-[11px] text-slate-600">{notif.message}</p>
                                </div>
                              ))}
                            </div>
                          );
                        } catch {
                          return null;
                        }
                      })()}
                    </div>
                  </div>
                )}

                {/* 4. PAYMENT METHODS MODAL */}
                {activeModal === 'payments' && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-slate-800">Saved Payment Methods</h4>
                        <button 
                          onClick={() => setShowAddCard(!showAddCard)}
                          className="text-xs font-bold text-blue-600 flex items-center gap-1 hover:underline"
                        >
                          <Plus className="w-3.5 h-3.5" /> {showAddCard ? 'Cancel' : 'Add New'}
                        </button>
                      </div>

                      {showAddCard && (
                        <form onSubmit={handleAddPayment} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                          <h5 className="text-xs font-bold text-slate-700">Add Payment Method</h5>
                          <div>
                            <label className="block text-[10px] font-semibold text-slate-500 uppercase">Card / Method Name</label>
                            <input 
                              type="text" 
                              placeholder="e.g. HDFC Debit Card or GPay" 
                              value={newCardName} 
                              onChange={(e) => setNewCardName(e.target.value)} 
                              className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs mt-1"
                              required
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[10px] font-semibold text-slate-500 uppercase">Card/UPI Number</label>
                              <input 
                                type="text" 
                                placeholder="1234 5678 9012 3456" 
                                value={newCardNumber} 
                                onChange={(e) => setNewCardNumber(e.target.value)} 
                                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs mt-1"
                                required
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] font-semibold text-slate-500 uppercase">Expiry (MM/YY)</label>
                              <input 
                                type="text" 
                                placeholder="12/28" 
                                value={newCardExp} 
                                onChange={(e) => setNewCardExp(e.target.value)} 
                                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs mt-1"
                              />
                            </div>
                          </div>
                          <button type="submit" className="w-full py-2 bg-blue-600 text-white rounded-lg text-xs font-bold hover:bg-blue-700">
                            Save Payment Method
                          </button>
                        </form>
                      )}

                      {paymentMethods.map((p: any) => (
                        <div key={p.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-700">
                              <CreditCard className="w-4 h-4 text-blue-600" />
                            </div>
                            <div>
                              <span className="block text-xs font-bold text-slate-800">{p.name}</span>
                              <span className="text-[10px] text-slate-400 font-medium">{p.number} {p.exp ? `• Exp ${p.exp}` : ''}</span>
                            </div>
                          </div>
                          <button 
                            onClick={() => handleDeletePayment(p.id)} 
                            className="p-1.5 text-slate-400 hover:text-rose-500 transition-colors"
                            title="Delete card"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 5. LANGUAGE MODAL */}
                {activeModal === 'language' && (
                  <div className="space-y-2">
                    <p className="text-xs text-slate-500 mb-3">Select your preferred application display language.</p>
                    {[
                      { name: 'English', native: 'English (US)' },
                      { name: 'Hindi', native: 'हिंदी' },
                      { name: 'Spanish', native: 'Español' },
                      { name: 'French', native: 'Français' },
                      { name: 'German', native: 'Deutsch' },
                    ].map((lang) => (
                      <button 
                        key={lang.name}
                        onClick={() => handleSelectLanguage(lang.name)}
                        className={`w-full p-3.5 rounded-xl border text-left flex items-center justify-between transition-all ${selectedLang === lang.name ? 'bg-blue-50/60 border-blue-500 text-blue-900 font-bold' : 'bg-slate-50 border-slate-200/80 text-slate-700 hover:bg-slate-100'}`}
                      >
                        <div>
                          <span className="block text-xs">{lang.name}</span>
                          <span className="text-[10px] text-slate-400 font-normal">{lang.native}</span>
                        </div>
                        {selectedLang === lang.name && <Check className="w-4 h-4 text-blue-600" />}
                      </button>
                    ))}
                  </div>
                )}

                {/* 6. THEME MODAL */}
                {activeModal === 'theme' && (
                  <div className="space-y-3">
                    <p className="text-xs text-slate-500 mb-3">Select theme appearance for optimal visibility.</p>
                    {[
                      { id: 'Light', label: 'Light Mode (Default)', desc: 'Clean high-contrast layout for daylight viewing' },
                      { id: 'Dark', label: 'Dark Mode', desc: 'Comfortable dark colors reducing eye strain' },
                      { id: 'System', label: 'System Theme', desc: 'Match your device system settings automatically' },
                    ].map((theme) => (
                      <button 
                        key={theme.id}
                        onClick={() => handleSelectTheme(theme.id)}
                        className={`w-full p-3.5 rounded-xl border text-left flex items-center justify-between transition-all ${selectedTheme === theme.id ? 'bg-blue-50/60 border-blue-500 text-blue-900 font-bold' : 'bg-slate-50 border-slate-200/80 text-slate-700 hover:bg-slate-100'}`}
                      >
                        <div>
                          <span className="block text-xs font-bold">{theme.label}</span>
                          <span className="text-[10px] text-slate-400 font-normal">{theme.desc}</span>
                        </div>
                        {selectedTheme === theme.id && <Check className="w-4 h-4 text-blue-600" />}
                      </button>
                    ))}
                  </div>
                )}

                {/* 7. HELP & SUPPORT MODAL */}
                {activeModal === 'support' && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-slate-800">Frequently Asked Questions</h4>
                      <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 text-xs space-y-1">
                        <span className="font-bold text-slate-800 block">How do I track my service request?</span>
                        <p className="text-slate-500 text-[11px]">Navigate to the Orders tab in the bottom menu to view real-time updates on your requested services.</p>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 text-xs space-y-1">
                        <span className="font-bold text-slate-800 block">Need custom digital solutions?</span>
                        <p className="text-slate-500 text-[11px]">Submit a custom request from the Services screen and our team will prepare a custom proposal.</p>
                      </div>
                    </div>

                    <form onSubmit={handleSubmitSupport} className="space-y-3 pt-2 border-t border-slate-100">
                      <h4 className="text-xs font-bold text-slate-800">Submit Support Ticket</h4>
                      <div>
                        <input 
                          type="text"
                          placeholder="Subject / Issue Summary" 
                          value={supportSubject}
                          onChange={(e) => setSupportSubject(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                          required
                        />
                      </div>
                      <div>
                        <textarea 
                          rows={3}
                          placeholder="Describe your query or issue in detail..." 
                          value={supportQuery}
                          onChange={(e) => setSupportQuery(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                          required
                        />
                      </div>
                      <button type="submit" className="w-full py-2.5 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition-colors shadow-sm">
                        Submit Support Ticket
                      </button>
                    </form>
                  </div>
                )}

                {/* 8. ABOUT APP MODAL */}
                {activeModal === 'about' && (
                  <div className="space-y-4 text-center">
                    <div className="w-16 h-16 bg-blue-600 text-white rounded-2xl flex items-center justify-center font-black text-xl mx-auto shadow-lg shadow-blue-500/20">
                      RST
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-base">RST Digital Solutions</h4>
                      <p className="text-xs text-slate-400">Version 2.4.0 (Build 2026.8)</p>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed max-w-sm mx-auto">
                      Providing full-spectrum software development, cloud infrastructure, AI engineering, and digital transformation services.
                    </p>

                    <div className="pt-3 border-t border-slate-100 flex items-center justify-center gap-4 text-xs font-medium text-blue-600">
                      <a href="#" onClick={(e) => { e.preventDefault(); showToast('Terms of Service loaded.'); }} className="hover:underline">Terms of Service</a>
                      <span>•</span>
                      <a href="#" onClick={(e) => { e.preventDefault(); showToast('Privacy Policy loaded.'); }} className="hover:underline">Privacy Policy</a>
                    </div>
                  </div>
                )}

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

