import React, { useState, useEffect } from 'react';
import * as LucideIcons from 'lucide-react';
import { collection, getDocs, onSnapshot, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { ServiceCategory, AiTool, TechProduct } from '../types';
import { categories } from '../data/servicesData';
import { 
  Search, Bell, Menu, Mic, Briefcase, Bot, 
  Wrench, Code, Megaphone, FileText, Sparkles, Shield, 
  ShoppingCart, MessageSquare, Image as ImageIcon, PenTool, PhoneCall,
  GraduationCap, Grid, CirclePlay, Globe,
  Truck, Tag, Lock, Award, Headphones, Users, ChevronRight, Plus,
  Download, ShoppingBag, Package, Video, Smartphone, CreditCard,
  Home, ClipboardList, User, ShieldCheck, UserPlus, UserCheck, X, CheckCircle2, Mail, Phone
} from 'lucide-react';

import heroLaptopAiImg from '../assets/images/rst_hero_laptop_ai_1785995748828.jpg';

interface HomeScreenProps {
  onOpenCategoryForm: (category: ServiceCategory) => void;
  onOpenAiTool: (tool: AiTool) => void;
  onOpenProduct: (product: TechProduct) => void;
  onNavigateTab: (tab: string) => void;
  cartCount: number;
  ordersCount: number;
}

// 5 Top Tech Products as shown in reference screenshot
const topTechProducts: TechProduct[] = [
  {
    id: 'hp_pavilion',
    name: 'HP Pavilion 15 Laptop',
    category: 'laptop',
    price: 55990,
    rating: 4.8,
    specs: ['Intel Core i5', '16GB RAM', '512GB SSD', '15.6" FHD'],
    imageUrl: 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=500&auto=format&fit=crop&q=80',
    stock: 15
  },
  {
    id: 'dell_inspiron',
    name: 'Dell Inspiron 3530 Laptop',
    category: 'laptop',
    price: 51990,
    rating: 4.7,
    specs: ['Intel Core i5', '8GB RAM', '512GB SSD', '15.6" Display'],
    imageUrl: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=500&auto=format&fit=crop&q=80',
    stock: 8
  },
  {
    id: 'gaming_pc',
    name: 'Gaming PC Setup RTX 4060',
    category: 'desktop',
    price: 85990,
    rating: 4.9,
    specs: ['Ryzen 7', '32GB DDR5', '1TB NVMe SSD', 'RTX 4060 8GB'],
    imageUrl: 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?w=500&auto=format&fit=crop&q=80',
    stock: 5
  },
  {
    id: 'lenovo_thinkcentre',
    name: 'Lenovo ThinkCentre Desktop',
    category: 'desktop',
    price: 48990,
    rating: 4.6,
    specs: ['Intel Core i5', '16GB RAM', '512GB SSD', 'Windows 11 Pro'],
    imageUrl: 'https://images.unsplash.com/photo-1593640408182-31c70c8268f5?w=500&auto=format&fit=crop&q=80',
    stock: 12
  },
  {
    id: 'asus_rog',
    name: 'ASUS ROG Strix Laptop',
    category: 'laptop',
    price: 125990,
    rating: 4.9,
    specs: ['Core i7 13th Gen', '16GB RAM', '1TB SSD', 'RTX 4070'],
    imageUrl: 'https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=500&auto=format&fit=crop&q=80',
    stock: 3
  }
];

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onOpenCategoryForm,
  onOpenAiTool,
  onOpenProduct,
  onNavigateTab,
  cartCount,
  ordersCount
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [allProducts, setAllProducts] = useState<TechProduct[]>(topTechProducts);

  // Follow App / Email Collection States
  const [isFollowModalOpen, setIsFollowModalOpen] = useState(false);
  const [isFollowing, setIsFollowing] = useState(() => {
    try {
      return localStorage.getItem('is_following') === 'true';
    } catch {
      return false;
    }
  });
  const [followEmail, setFollowEmail] = useState(() => {
    try {
      return localStorage.getItem('user_follow_email') || '';
    } catch {
      return '';
    }
  });
  const [followName, setFollowName] = useState('');
  const [followPhone, setFollowPhone] = useState('');
  const [followSuccessMsg, setFollowSuccessMsg] = useState('');
  const [isSubmittingFollow, setIsSubmittingFollow] = useState(false);

  const handleFollowSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!followEmail.trim()) return;

    setIsSubmittingFollow(true);
    const newId = 'sub_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const subData = {
      id: newId,
      email: followEmail.trim().toLowerCase(),
      name: followName.trim() || 'App User',
      phone: followPhone.trim() || '',
      subscribedAt: new Date().toISOString()
    };

    // Save to localStorage
    try {
      const customSubs = JSON.parse(localStorage.getItem('custom_subscribers') || '[]');
      localStorage.setItem('custom_subscribers', JSON.stringify([subData, ...customSubs.filter((s: any) => s.email !== subData.email)]));
      localStorage.setItem('is_following', 'true');
      localStorage.setItem('user_follow_email', subData.email);
    } catch (err) {
      console.warn("LocalStorage save subscriber error:", err);
    }

    // Save to Firestore subscribers collection
    try {
      await setDoc(doc(db, 'subscribers', newId), {
        ...subData,
        createdAt: serverTimestamp()
      });
    } catch (err) {
      console.warn("Firestore save subscriber error:", err);
    }

    setIsSubmittingFollow(false);
    setIsFollowing(true);
    setFollowSuccessMsg(`🎉 Thank you for following us! Email (${subData.email}) registered.`);
    
    setTimeout(() => {
      setIsFollowModalOpen(false);
      setFollowSuccessMsg('');
    }, 2200);
  };

  useEffect(() => {
    const getCustomLocal = (): TechProduct[] => {
      try {
        return JSON.parse(localStorage.getItem('custom_tech_products') || '[]');
      } catch {
        return [];
      }
    };

    // Load initial custom local products immediately so added products are visible instantly
    const initialCustom = getCustomLocal();
    if (initialCustom.length > 0) {
      setAllProducts(prev => {
        const map = new Map<string, TechProduct>();
        initialCustom.forEach(p => map.set(p.id, p));
        prev.forEach(p => { if (!map.has(p.id)) map.set(p.id, p); });
        return Array.from(map.values());
      });
    }

    const unsub = onSnapshot(collection(db, 'products'), (querySnapshot) => {
      try {
        const firestoreProducts = querySnapshot.empty 
          ? [] 
          : querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as TechProduct[];

        const customLocal = getCustomLocal();
        const map = new Map<string, TechProduct>();

        // Custom local products first
        customLocal.forEach(p => map.set(p.id, p));
        // Firestore products
        firestoreProducts.forEach(p => map.set(p.id, p));
        // Static default products
        topTechProducts.forEach(p => {
          if (!map.has(p.id)) {
            map.set(p.id, p);
          }
        });

        setAllProducts(Array.from(map.values()));
      } catch (err) {
        console.warn("Error processing products snapshot on HomeScreen", err);
      }
    }, (err) => {
      console.warn("Error listening to products on HomeScreen", err);
    });

    return () => unsub();
  }, []);

  // Filter Categories
  const filteredCategories = categories.filter(cat => 
    cat.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cat.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cat.subCategories.some(sub => sub.name.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Filter Products
  const filteredProducts = allProducts.filter(prod => {
    const name = prod.name ? prod.name.toLowerCase() : '';
    const category = prod.category ? prod.category.toLowerCase() : '';
    const query = searchQuery.toLowerCase();
    return name.includes(query) || category.includes(query);
  });

  const hasResults = filteredCategories.length > 0 || filteredProducts.length > 0;

  return (
    <div className="bg-[#F2F4F8] text-slate-900 min-h-screen pb-24 font-sans selection:bg-blue-600 selection:text-white">
      
      {/* SIDEBAR DRAWER */}
      {isSidebarOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex">
          <div className="w-80 bg-slate-900 text-white h-full shadow-2xl flex flex-col justify-between p-6 border-r border-slate-800 animate-in slide-in-from-left duration-200">
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div>
                  <h2 className="text-base font-black tracking-tight">
                    <span className="text-blue-500">RST</span> DIGITAL
                  </h2>
                  <p className="text-[10px] text-slate-400">Navigation Menu</p>
                </div>
                <button 
                  onClick={() => setIsSidebarOpen(false)}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-2">
                <button
                  onClick={() => { setIsSidebarOpen(false); onNavigateTab('home'); }}
                  className="w-full flex items-center gap-3 p-3 rounded-2xl bg-slate-800 text-white text-xs font-bold transition cursor-pointer"
                >
                  <Home className="w-4 h-4 text-blue-400" /> Home Dashboard
                </button>
                <button
                  onClick={() => { setIsSidebarOpen(false); onNavigateTab('orders'); }}
                  className="w-full flex items-center gap-3 p-3 rounded-2xl hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-bold transition cursor-pointer"
                >
                  <Wrench className="w-4 h-4 text-indigo-400" /> Service Orders
                </button>
                <button
                  onClick={() => { setIsSidebarOpen(false); onNavigateTab('request'); }}
                  className="w-full flex items-center gap-3 p-3 rounded-2xl hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-bold transition cursor-pointer"
                >
                  <ClipboardList className="w-4 h-4 text-orange-400" /> Service Request Form
                </button>
                <button
                  onClick={() => { setIsSidebarOpen(false); onNavigateTab('cart'); }}
                  className="w-full flex items-center gap-3 p-3 rounded-2xl hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-bold transition cursor-pointer"
                >
                  <ShoppingCart className="w-4 h-4 text-emerald-400" /> Cart & Checkout
                </button>
                <button
                  onClick={() => { setIsSidebarOpen(false); onNavigateTab('profile'); }}
                  className="w-full flex items-center gap-3 p-3 rounded-2xl hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-bold transition cursor-pointer"
                >
                  <User className="w-4 h-4 text-purple-400" /> Customer Profile
                </button>
                <button
                  onClick={() => { setIsSidebarOpen(false); setIsFollowModalOpen(true); }}
                  className="w-full flex items-center gap-3 p-3 rounded-2xl bg-blue-600/20 border border-blue-500/30 text-blue-300 hover:bg-blue-600 hover:text-white text-xs font-bold transition cursor-pointer"
                >
                  {isFollowing ? <UserCheck className="w-4 h-4 text-emerald-400" /> : <UserPlus className="w-4 h-4 text-blue-400" />}
                  <span>{isFollowing ? 'Following RST Digital' : 'Follow Us & Get Deals'}</span>
                </button>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 text-center">
              <p className="text-[11px] text-slate-400 font-medium">RST Digital Solutions © 2026</p>
              <p className="text-[9px] text-slate-500 mt-0.5">All Rights Reserved</p>
            </div>
          </div>
          <div className="flex-1" onClick={() => setIsSidebarOpen(false)}></div>
        </div>
      )}

      {/* Main Top Header Bar */}
      <header className="px-4 pt-2 pb-2 sticky top-0 z-40 bg-[#F2F4F8]/95 backdrop-blur-md">
        <div className="max-w-xl mx-auto space-y-2.5">
          {/* Logo & Icons Row */}
          <div className="relative flex items-center justify-between min-h-[50px]">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-1 text-slate-800 hover:text-blue-600 rounded-lg cursor-pointer z-10"
              title="Open Navigation Menu"
            >
              <Menu className="w-6 h-6" />
            </button>

            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="text-center pointer-events-auto">
                <h1 className="text-lg font-black tracking-tight leading-none text-slate-900">
                  <span className="text-[#2563EB]">RST</span> DIGITAL
                  <span className="block text-xs font-black tracking-wider text-slate-900">SOLUTIONS</span>
                </h1>
                <p className="text-[9px] text-slate-500 font-medium tracking-tight mt-0.5">
                  Smart Digital Services, Anytime Anywhere
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 z-10">
              <button
                onClick={() => setIsFollowModalOpen(true)}
                className={`px-2.5 py-1 text-[11px] font-black rounded-full flex items-center gap-1 transition shadow-xs cursor-pointer ${
                  isFollowing 
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                    : 'bg-blue-600 hover:bg-blue-700 text-white'
                }`}
                title={isFollowing ? 'You are following RST Digital' : 'Follow RST Digital Solutions'}
              >
                {isFollowing ? <UserCheck className="w-3.5 h-3.5 text-emerald-600" /> : <UserPlus className="w-3.5 h-3.5" />}
                <span className="hidden sm:inline">{isFollowing ? 'Following' : 'Follow'}</span>
              </button>

              <button className="p-1 text-slate-800 hover:text-blue-600 rounded-lg cursor-pointer">
                <Search className="w-5 h-5" />
              </button>

              <div className="relative">
                <button 
                  onClick={() => onNavigateTab('orders')}
                  className="p-1 text-slate-800 hover:text-blue-600 rounded-lg cursor-pointer"
                >
                  <Bell className="w-5 h-5" />
                  <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center border-2 border-[#F2F4F8]">
                    3
                  </span>
                </button>
              </div>
            </div>
          </div>

          {/* Search Bar + AI Assistant Button */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search services, AI tools, products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-8 py-2 text-xs rounded-xl bg-white border border-slate-200 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30 shadow-xs"
              />
              <Mic className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 cursor-pointer" />
            </div>
          </div>

          {/* Professional Scrolling Notice Banner */}
          <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white text-xs font-semibold py-1.5 overflow-hidden shadow-sm rounded-xl">
            <div className="flex items-center">
              <div className="bg-amber-800/90 px-2.5 py-1 flex items-center gap-1 font-bold uppercase tracking-wider shrink-0 z-10 shadow-inner rounded-l-xl">
                <Megaphone className="w-3.5 h-3.5 animate-bounce text-yellow-200" />
                <span>Notice:</span>
              </div>
              <div className="overflow-hidden whitespace-nowrap flex-1">
                <div className="animate-marquee inline-flex items-center gap-12 px-4">
                  <span>
                    🇳🇵 हाम्रा सम्पूर्ण ग्राहक तथा सेवाग्राहीहरूमा हार्दिक अनुरोध: हामी हाम्रा नि:शुल्क सेवाहरू (Free Services) पूर्ण रूपमा नि:शुल्क नै उपलब्ध गराउँछौँ। यदि कसैले यी नि:शुल्क सेवाहरूको लागि पैसा माग गरेमा, तुरुन्तै WhatsApp: +977-9704443289 मा सम्पर्क गर्नुहोस्। सशुल्क सेवाको हकमा तोकिएको शुल्क मात्र लाग्नेछ र अनिवार्य आधिकारिक रसिद (Receipt) प्रदान गरिन्छ। बिना रसिद भुक्तानी नगर्नुहोला। धन्यवाद!
                  </span>
                  <span className="text-yellow-200 font-bold">•</span>
                  <span>
                    🇬🇧 Dear Valued Customers: We strictly provide our Free Services completely free of charge. If anyone demands money for free services, report immediately via WhatsApp: +977-9704443289. We charge only for designated Paid Services and always issue an official Receipt. Do not pay without a valid receipt. Thank you!
                  </span>
                  <span className="text-yellow-200 font-bold">•</span>
                  <span>
                    🇳🇵 हाम्रा सम्पूर्ण ग्राहक तथा सेवाग्राहीहरूमा हार्दिक अनुरोध: हामी हाम्रा नि:शुल्क सेवाहरू (Free Services) पूर्ण रूपमा नि:शुल्क नै उपलब्ध गराउँछौँ। यदि कसैले यी नि:शुल्क सेवाहरूको लागि पैसा माग गरेमा, तुरुन्तै WhatsApp: +977-9704443289 मा सम्पर्क गर्नुहोस्। सशुल्क सेवाको हकमा तोकिएको शुल्क मात्र लाग्नेछ र अनिवार्य आधिकारिक रसिद (Receipt) प्रदान गरिन्छ। बिना रसिद भुक्तानी नगर्नुहोला। धन्यवाद!
                  </span>
                  <span className="text-yellow-200 font-bold">•</span>
                  <span>
                    🇬🇧 Dear Valued Customers: We strictly provide our Free Services completely free of charge. If anyone demands money for free services, report immediately via WhatsApp: +977-9704443289. We charge only for designated Paid Services and always issue an official Receipt. Do not pay without a valid receipt. Thank you!
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Screen Container */}
      <div className="max-w-xl mx-auto px-4 space-y-4 pt-1">
        
        {/* Empty State for Search */}
        {searchQuery && !hasResults && (
          <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 shadow-sm animate-in fade-in zoom-in duration-300">
            <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto mb-4 text-slate-300">
              <Search className="w-8 h-8" />
            </div>
            <h3 className="text-sm font-black text-slate-900">No results found for "{searchQuery}"</h3>
            <p className="text-[10px] text-slate-500 mt-1">Try searching for something else or browse our categories.</p>
            <button 
              onClick={() => setSearchQuery('')}
              className="mt-4 px-4 py-2 bg-blue-600 text-white text-[10px] font-bold rounded-xl shadow-md hover:bg-blue-700 transition cursor-pointer"
            >
              Clear Search
            </button>
          </div>
        )}

        {/* Hero Card Banner */}
        {(!searchQuery || hasResults) && (
          <div className="bg-gradient-to-r from-[#070F28] via-[#0E1C44] to-[#070F28] rounded-3xl p-5 border border-slate-800 text-white shadow-xl relative overflow-hidden">
          <div className="grid grid-cols-12 gap-2 items-center">
            {/* Left Hero Text */}
            <div className="col-span-7 space-y-2">
              <h2 className="text-lg sm:text-xl font-black text-white leading-tight">
                <span className="text-[#38BDF8]">AI Solutions</span>,<br />
                Tech Products &<br />
                Repair – All in One Place
              </h2>
              <p className="text-[10px] text-slate-300 leading-snug">
                One platform for all your AI-powered solutions, tech products, and repair services.
              </p>
            </div>

            {/* Right Hero Image (Laptop + Mobile) */}
            <div className="col-span-5 relative flex justify-center items-center">
              <img 
                src={heroLaptopAiImg} 
                alt="AI Laptop & Mobile Phone" 
                className="w-full h-auto max-h-36 object-cover rounded-xl shadow-2xl border border-blue-500/20"
              />
            </div>
          </div>

          {/* Carousel Dots Indicator */}
          <div className="flex justify-center items-center gap-1.5 mt-3">
            <span className="w-3 h-1.5 rounded-full bg-[#38BDF8]" />
            <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
            <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
            <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
          </div>
        </div>
        )}

        {/* 4 Value Props Dark Navy Bar */}
        {(!searchQuery || hasResults) && (
          <div className="bg-[#08122B] text-white rounded-2xl p-2.5 grid grid-cols-4 gap-1 border border-slate-800 text-[10px] shadow-sm">
          <div className="flex items-center gap-1.5">
            <div className="w-6 h-6 rounded-lg bg-blue-600/30 text-blue-400 flex items-center justify-center shrink-0">
              <Briefcase className="w-3.5 h-3.5" />
            </div>
            <span className="font-bold text-slate-200 truncate">100+<br />Services</span>
          </div>

          <div className="flex items-center gap-1.5">
            <div className="w-6 h-6 rounded-lg bg-purple-600/30 text-purple-400 flex items-center justify-center shrink-0">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            <span className="font-bold text-slate-200 truncate">AI Powered<br />Solutions</span>
          </div>

          <div className="flex items-center gap-1.5">
            <div className="w-6 h-6 rounded-lg bg-emerald-600/30 text-emerald-400 flex items-center justify-center shrink-0">
              <Headphones className="w-3.5 h-3.5" />
            </div>
            <span className="font-bold text-slate-200 truncate">Expert<br />Support</span>
          </div>

          <div className="flex items-center gap-1.5">
            <div className="w-6 h-6 rounded-lg bg-amber-600/30 text-amber-400 flex items-center justify-center shrink-0">
              <Shield className="w-3.5 h-3.5" />
            </div>
            <span className="font-bold text-slate-200 truncate">Secure &<br />Trusted</span>
          </div>
        </div>
        )}

        {/* Follow RST Digital Banner */}
        {(!searchQuery || hasResults) && (
          <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white rounded-2xl p-3.5 border border-blue-700/50 shadow-md flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center border border-blue-400/30 text-blue-300 shrink-0">
                <UserPlus className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs font-black text-white">Follow RST Digital Solutions</h3>
                <p className="text-[10px] text-blue-200">Get instant SMS updates, tech product alerts & exclusive discount codes!</p>
              </div>
            </div>
            <button
              onClick={() => setIsFollowModalOpen(true)}
              className={`px-3 py-1.5 text-xs font-black rounded-xl shadow-sm transition cursor-pointer whitespace-nowrap shrink-0 ${
                isFollowing 
                  ? 'bg-emerald-500 text-white' 
                  : 'bg-blue-500 hover:bg-blue-600 text-white'
              }`}
            >
              {isFollowing ? '✓ Following' : '+ Follow Us'}
            </button>
          </div>
        )}

        {/* All Services White Card Grid Container */}
        {filteredCategories.length > 0 && (
          <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-black text-slate-900">
                {searchQuery ? `Search Results: Services (${filteredCategories.length})` : 'Our Services'}
              </h2>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {filteredCategories.map((item) => {
                const IconComp = (LucideIcons as any)[item.iconName] || LucideIcons.Grid;
                
                return (
                <button
                  key={item.id}
                  onClick={() => onOpenCategoryForm(item)}
                  className="flex flex-col items-center text-center space-y-2 cursor-pointer group bg-slate-50 rounded-2xl p-3 border border-slate-100 hover:border-blue-200 transition"
                >
                  <div className={`w-12 h-12 rounded-2xl ${item.iconBg} flex items-center justify-center transition transform group-hover:scale-105 shadow-xs`}>
                    <IconComp className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] font-bold text-slate-800 leading-tight group-hover:text-blue-600">
                    {item.title}
                  </span>
                </button>
              )})}
            </div>
          </div>
        )}

        {/* Top Tech Products Section */}
        {filteredProducts.length > 0 && (
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-slate-900">
                {searchQuery ? `Search Results: Products (${filteredProducts.length})` : 'Top Tech Products'}
              </h3>
              {!searchQuery && (
                <button 
                  onClick={() => onOpenProduct(allProducts[0])}
                  className="text-xs text-[#2563EB] hover:underline font-bold cursor-pointer"
                >
                  View All
                </button>
              )}
            </div>

            <div className="flex gap-2.5 overflow-x-auto pb-2 scrollbar-none">
              {filteredProducts.map((prod) => (
                <div
                  key={prod.id}
                  onClick={() => onOpenProduct(prod)}
                  className="min-w-[130px] max-w-[130px] bg-white rounded-2xl p-2.5 border border-slate-200/80 shadow-xs flex flex-col justify-between cursor-pointer hover:border-blue-500 transition"
                >
                  <div className="space-y-2">
                    <div className="w-full h-20 bg-slate-50 rounded-xl overflow-hidden flex items-center justify-center">
                      <img 
                        src={prod.imageUrl} 
                        alt={prod.name} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <h4 className="text-[10px] font-bold text-slate-800 line-clamp-2 leading-snug">
                      {prod.name}
                    </h4>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <span className="text-xs font-black text-slate-900">
                      &#x20B9;{prod.price.toLocaleString()}
                    </span>
                    <button className="w-6 h-6 rounded-lg bg-[#2563EB] text-white flex items-center justify-center hover:bg-blue-700 transition">
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 6 Value Props Trust Navy Bar */}
        {(!searchQuery || hasResults) && (
          <div className="bg-[#08122B] text-white rounded-2xl p-2.5 grid grid-cols-6 gap-1 border border-slate-800 text-[8px] text-center shadow-sm">
          <div className="flex flex-col items-center space-y-1">
            <Truck className="w-3.5 h-3.5 text-pink-400" />
            <span className="font-bold text-slate-200 leading-tight">Fast<br />Delivery</span>
          </div>

          <div className="flex flex-col items-center space-y-1">
            <Tag className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-bold text-slate-200 leading-tight">Best<br />Price</span>
          </div>

          <div className="flex flex-col items-center space-y-1">
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-bold text-slate-200 leading-tight">Secure<br />Payments</span>
          </div>

          <div className="flex flex-col items-center space-y-1">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-bold text-slate-200 leading-tight">100%<br />Satisfaction</span>
          </div>

          <div className="flex flex-col items-center space-y-1">
            <Headphones className="w-3.5 h-3.5 text-sky-400" />
            <span className="font-bold text-slate-200 leading-tight">24/7<br />Support</span>
          </div>

          <div className="flex flex-col items-center space-y-1">
            <Users className="w-3.5 h-3.5 text-indigo-400" />
            <span className="font-bold text-slate-200 leading-tight">Expert<br />Team</span>
          </div>
        </div>
        )}

        {/* How It Works Section */}
        {(!searchQuery || hasResults) && (
          <div className="space-y-2 mt-8">
            <h3 className="text-sm font-black text-slate-900 text-center">How It Works</h3>

            <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 flex items-center justify-between text-center gap-1">
              {/* Step 1 */}
              <div className="flex flex-col items-center space-y-1 flex-1">
                <div className="w-7 h-7 rounded-full bg-[#2563EB] text-white font-black text-xs flex items-center justify-center">
                  1
                </div>
                <span className="text-[10px] font-extrabold text-slate-900">Choose Service</span>
                <span className="text-[8px] text-slate-400 leading-tight max-w-[70px]">Select the service you need</span>
              </div>

              <ChevronRight className="w-4 h-4 text-blue-500 shrink-0 -mt-3" />

              {/* Step 2 */}
              <div className="flex flex-col items-center space-y-1 flex-1">
                <div className="w-7 h-7 rounded-full bg-[#9333EA] text-white font-black text-xs flex items-center justify-center">
                  2
                </div>
                <span className="text-[10px] font-extrabold text-slate-900">Place Order</span>
                <span className="text-[8px] text-slate-400 leading-tight max-w-[70px]">Fill details & place order</span>
              </div>

              <ChevronRight className="w-4 h-4 text-blue-500 shrink-0 -mt-3" />

              {/* Step 3 */}
              <div className="flex flex-col items-center space-y-1 flex-1">
                <div className="w-7 h-7 rounded-full bg-[#16A34A] text-white font-black text-xs flex items-center justify-center">
                  3
                </div>
                <span className="text-[10px] font-extrabold text-slate-900">We Process</span>
                <span className="text-[8px] text-slate-400 leading-tight max-w-[70px]">Our expert team will work</span>
              </div>

              <ChevronRight className="w-4 h-4 text-blue-500 shrink-0 -mt-3" />

              {/* Step 4 */}
              <div className="flex flex-col items-center space-y-1 flex-1">
                <div className="w-7 h-7 rounded-full bg-[#EA580C] text-white font-black text-xs flex items-center justify-center">
                  4
                </div>
                <span className="text-[10px] font-extrabold text-slate-900">Get Delivered</span>
                <span className="text-[8px] text-slate-400 leading-tight max-w-[70px]">Receive your service on time</span>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* Follow App / Email Collection Modal */}
      {isFollowModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl border border-slate-100 relative animate-in zoom-in-95 duration-200 text-slate-800">
            <button 
              onClick={() => { setIsFollowModalOpen(false); setFollowSuccessMsg(''); }}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-700 rounded-full bg-slate-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center space-y-2 mb-5">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mx-auto shadow-sm">
                <UserPlus className="w-6 h-6" />
              </div>
              <h3 className="text-base font-black text-slate-900">Follow RST Digital Solutions</h3>
              <p className="text-xs text-slate-500">
                Enter your email address to receive instant tech updates, new product alerts, and exclusive bulk SMS discount codes!
              </p>
            </div>

            {followSuccessMsg ? (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-2xl text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
                <p className="text-xs font-bold">{followSuccessMsg}</p>
                <button
                  onClick={() => { setIsFollowModalOpen(false); setFollowSuccessMsg(''); }}
                  className="mt-2 w-full py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl hover:bg-emerald-700 cursor-pointer"
                >
                  Close
                </button>
              </div>
            ) : (
              <form onSubmit={handleFollowSubmit} className="space-y-3.5">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center gap-1">
                    <Mail className="w-3.5 h-3.5 text-blue-500" /> Email Address <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="yourname@example.com"
                    value={followEmail}
                    onChange={(e) => setFollowEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/30 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center gap-1">
                    <User className="w-3.5 h-3.5 text-purple-500" /> Full Name (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Ram Shrestha"
                    value={followName}
                    onChange={(e) => setFollowName(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/30 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-emerald-500" /> Mobile Number (Optional for Bulk SMS)
                  </label>
                  <input
                    type="tel"
                    placeholder="+977-9800000000"
                    value={followPhone}
                    onChange={(e) => setFollowPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/30 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmittingFollow}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer flex items-center justify-center gap-2 mt-2"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{isSubmittingFollow ? 'Registering...' : 'Follow Now & Get Offers'}</span>
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
