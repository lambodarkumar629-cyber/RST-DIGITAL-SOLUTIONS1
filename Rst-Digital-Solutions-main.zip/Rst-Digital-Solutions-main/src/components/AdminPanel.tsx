import React, { useState, useEffect } from 'react';
import { collection, getDocs, doc, updateDoc, deleteDoc, addDoc, serverTimestamp, setDoc, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { LayoutDashboard, ShoppingBag, Users, LogOut, Trash2, Edit2, ShieldAlert, Package, Layers, Settings, Menu, X, Plus, Check, Image as ImageIcon, Upload, UserPlus, UserCheck, Mail, Copy, Download, Send, Search, MessageSquare, Phone } from 'lucide-react';
import { techProducts, categories } from '../data/servicesData';
import { TechProduct, ServiceCategory } from '../types';

export const AdminPanel: React.FC<{ onLogout: () => void }> = ({ onLogout }) => {
  const [activeMenu, setActiveMenu] = useState('orders');
  const [orders, setOrders] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [subscribers, setSubscribers] = useState<any[]>([]);
  const [subscriberSearch, setSubscriberSearch] = useState('');
  const [smsCampaignText, setSmsCampaignText] = useState('');
  const [loading, setLoading] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Local state for products and categories (initialized with static data, then merged with Firestore)
  const [localProducts, setLocalProducts] = useState<TechProduct[]>(techProducts);
  const [localCategories, setLocalCategories] = useState<ServiceCategory[]>(categories);

  // Modal States
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<TechProduct | null>(null);
  const [productForm, setProductForm] = useState({
    name: '',
    category: 'laptop',
    customCategory: '',
    price: '',
    stock: '10',
    imageUrl: '',
    rating: '4.8',
    specs: ''
  });

  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<ServiceCategory | null>(null);
  const [categoryForm, setCategoryForm] = useState({
    title: '',
    description: '',
    iconName: 'Wrench',
    subCategories: ''
  });

  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<any | null>(null);
  const [userForm, setUserForm] = useState({
    displayName: '',
    email: '',
    role: 'User'
  });

  useEffect(() => {
    fetchOrders();
    fetchUsers();

    const getCustomLocal = (): TechProduct[] => {
      try {
        return JSON.parse(localStorage.getItem('custom_tech_products') || '[]');
      } catch {
        return [];
      }
    };

    const initialCustom = getCustomLocal();
    if (initialCustom.length > 0) {
      setLocalProducts(prev => {
        const map = new Map<string, TechProduct>();
        initialCustom.forEach(p => map.set(p.id, p));
        prev.forEach(p => { if (!map.has(p.id)) map.set(p.id, p); });
        return Array.from(map.values());
      });
    }

    const unsubProducts = onSnapshot(collection(db, 'products'), (querySnapshot) => {
      try {
        const firestoreProducts = querySnapshot.empty 
          ? [] 
          : querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as TechProduct[];
        
        const customLocal = getCustomLocal();
        const map = new Map<string, TechProduct>();

        // Custom local products first
        customLocal.forEach(p => map.set(p.id, p));
        // Firestore products
        firestoreProducts.forEach(p => map.set(p.id, p));
        // Default products
        techProducts.forEach(p => {
          if (!map.has(p.id)) {
            map.set(p.id, p);
          }
        });

        setLocalProducts(Array.from(map.values()));
      } catch (err) {
        console.warn("Error mapping products snapshot in AdminPanel", err);
      }
    }, (err) => {
      console.warn("Error listening to products in AdminPanel", err);
    });

    fetchCategories();

    const getCustomSubscribersLocal = (): any[] => {
      try {
        return JSON.parse(localStorage.getItem('custom_subscribers') || '[]');
      } catch {
        return [];
      }
    };

    const initialSubs = getCustomSubscribersLocal();
    if (initialSubs.length > 0) {
      setSubscribers(initialSubs);
    }

    const unsubSubscribers = onSnapshot(collection(db, 'subscribers'), (querySnapshot) => {
      try {
        const firestoreSubs = querySnapshot.empty
          ? []
          : querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

        const customLocal = getCustomSubscribersLocal();
        const map = new Map<string, any>();

        customLocal.forEach((s: any) => map.set(s.id || s.email, s));
        firestoreSubs.forEach((s: any) => map.set(s.id || s.email, s));

        const combined = Array.from(map.values());
        combined.sort((a, b) => {
          const dateA = a.subscribedAt || a.createdAt ? new Date(a.subscribedAt || a.createdAt).getTime() : 0;
          const dateB = b.subscribedAt || b.createdAt ? new Date(b.subscribedAt || b.createdAt).getTime() : 0;
          return dateB - dateA;
        });

        setSubscribers(combined);
      } catch (err) {
        console.warn("Error listening to subscribers snapshot", err);
      }
    }, (err) => {
      console.warn("Error listening to subscribers in AdminPanel", err);
    });

    return () => {
      unsubProducts();
      unsubSubscribers();
    };
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleCopyAllEmails = () => {
    const emails = subscribers.map(s => s.email).filter(Boolean).join(', ');
    if (!emails) {
      showToast("No email IDs collected yet");
      return;
    }
    navigator.clipboard.writeText(emails);
    showToast(`Copied ${subscribers.length} customer Email IDs!`);
  };

  const handleCopySingleEmail = (email: string) => {
    if (!email) return;
    navigator.clipboard.writeText(email);
    showToast(`Email ${email} copied!`);
  };

  const handleCopyPhoneNumbers = () => {
    const phones = subscribers.map(s => s.phone).filter(p => p && p.trim() !== '').join(', ');
    if (!phones) {
      showToast("No phone numbers available for Bulk SMS");
      return;
    }
    navigator.clipboard.writeText(phones);
    showToast(`Copied customer phone numbers for Bulk SMS!`);
  };

  const handleExportSubscribersCSV = () => {
    if (subscribers.length === 0) {
      showToast("No subscribers to export");
      return;
    }
    const headers = ["Subscriber ID", "Email Address", "Customer Name", "Phone Number", "Subscribed At"];
    const rows = subscribers.map(s => [
      s.id || '',
      s.email || '',
      s.name || 'App User',
      s.phone || '',
      s.subscribedAt || s.createdAt || ''
    ]);
    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(","), ...rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `rst_app_followers_emails_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Subscribers list exported as CSV!");
  };

  const handleDeleteSubscriber = async (subId: string) => {
    if (!window.confirm("Are you sure you want to remove this follower record?")) return;
    try {
      await deleteDoc(doc(db, 'subscribers', subId));
    } catch (err) {
      console.warn("Firestore delete subscriber error:", err);
    }
    try {
      const customLocal = JSON.parse(localStorage.getItem('custom_subscribers') || '[]');
      localStorage.setItem('custom_subscribers', JSON.stringify(customLocal.filter((s: any) => (s.id || s.email) !== subId)));
    } catch {}
    setSubscribers(prev => prev.filter(s => (s.id || s.email) !== subId));
    showToast("Subscriber removed");
  };

  const fetchOrders = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, 'orders'));
      const ordersData = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      ordersData.sort((a: any, b: any) => {
        const timeA = a.createdAt?.toMillis ? a.createdAt.toMillis() : 0;
        const timeB = b.createdAt?.toMillis ? b.createdAt.toMillis() : 0;
        return timeB - timeA;
      });
      setOrders(ordersData);
    } catch (error) {
      console.error("Error fetching admin orders", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, 'users'));
      const usersData = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setUsers(usersData);
    } catch (error) {
      console.error("Error fetching admin users", error);
    }
  };

  const fetchProducts = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, 'products'));
      if (!querySnapshot.empty) {
        const firestoreProducts = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as TechProduct[];
        // Merge Firestore products with static techProducts, avoiding duplicates
        const combined = [...firestoreProducts];
        techProducts.forEach(tp => {
          if (!combined.some(p => p.id === tp.id)) {
            combined.push(tp);
          }
        });
        setLocalProducts(combined);
      }
    } catch (error) {
      console.warn("Error fetching products from Firestore", error);
    }
  };

  const fetchCategories = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, 'categories'));
      if (!querySnapshot.empty) {
        const firestoreCats = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as ServiceCategory[];
        const combined = [...firestoreCats];
        categories.forEach(sc => {
          if (!combined.some(c => c.id === sc.id)) {
            combined.push(sc);
          }
        });
        setLocalCategories(combined);
      }
    } catch (error) {
      console.warn("Error fetching categories from Firestore", error);
    }
  };

  // ORDER ACTIONS
  const updateOrderStatus = async (id: string, newStatus: string) => {
    try {
      await updateDoc(doc(db, 'orders', id), { status: newStatus });
      fetchOrders();
      showToast('Order status updated!');
    } catch (error) {
      console.error("Error updating order", error);
    }
  };

  const deleteOrder = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this order?")) return;
    try {
      await deleteDoc(doc(db, 'orders', id));
      fetchOrders();
      showToast('Order deleted');
    } catch (error) {
      console.error("Error deleting order", error);
    }
  };

  // USER ACTIONS
  const deleteUser = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this user?")) return;
    try {
      await deleteDoc(doc(db, 'users', id));
      fetchUsers();
      showToast('User deleted');
    } catch (error) {
      console.error("Error deleting user", error);
    }
  };

  const openEditUserModal = (userObj: any) => {
    setEditingUser(userObj);
    setUserForm({
      displayName: userObj.displayName || '',
      email: userObj.email || '',
      role: userObj.email === 'kaparrst@gmail.com' ? 'Admin' : 'User'
    });
    setIsUserModalOpen(true);
  };

  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    try {
      await updateDoc(doc(db, 'users', editingUser.id), {
        displayName: userForm.displayName,
        email: userForm.email
      });
      fetchUsers();
      setIsUserModalOpen(false);
      showToast('User profile updated successfully!');
    } catch (error) {
      console.error("Error updating user", error);
      // Fallback update local state
      setUsers(prev => prev.map(u => u.id === editingUser.id ? { ...u, displayName: userForm.displayName, email: userForm.email } : u));
      setIsUserModalOpen(false);
      showToast('User profile updated locally');
    }
  };

  // PRODUCT ACTIONS (ADD, EDIT, DELETE)
  const openAddProductModal = () => {
    setEditingProduct(null);
    setProductForm({
      name: '',
      category: 'laptop',
      customCategory: '',
      price: '',
      stock: '10',
      imageUrl: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=500&auto=format&fit=crop&q=80',
      rating: '4.8',
      specs: 'Intel Core i5, 16GB RAM, 512GB SSD'
    });
    setIsProductModalOpen(true);
  };

  const openEditProductModal = (product: TechProduct) => {
    setEditingProduct(product);
    const standardCategories = ['laptop', 'desktop', 'mobile', 'accessory', 'audio'];
    const isStandard = standardCategories.includes(product.category.toLowerCase());
    setProductForm({
      name: product.name,
      category: isStandard ? product.category.toLowerCase() : 'custom',
      customCategory: isStandard ? '' : product.category,
      price: product.price.toString(),
      stock: product.stock.toString(),
      imageUrl: product.imageUrl,
      rating: product.rating.toString(),
      specs: Array.isArray(product.specs) ? product.specs.join(', ') : ''
    });
    setIsProductModalOpen(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productForm.name.trim() || !productForm.price) {
      alert("Please provide a product name and price.");
      return;
    }

    const priceNum = parseFloat(productForm.price) || 0;
    const stockNum = parseInt(productForm.stock, 10) || 0;
    const ratingNum = parseFloat(productForm.rating) || 4.5;
    const specsArray = productForm.specs
      ? productForm.specs.split(',').map(s => s.trim()).filter(Boolean)
      : ['High Quality Spec'];

    const imageUrlClean = productForm.imageUrl.trim() || 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=500&auto=format&fit=crop&q=80';

    const finalCategory = productForm.category === 'custom'
      ? (productForm.customCategory.trim() || 'Custom')
      : productForm.category.trim();

    const payload = {
      name: productForm.name.trim(),
      category: finalCategory || 'laptop',
      price: priceNum,
      stock: stockNum,
      rating: ratingNum,
      imageUrl: imageUrlClean,
      specs: specsArray
    };

    const getCustomLocal = (): TechProduct[] => {
      try {
        return JSON.parse(localStorage.getItem('custom_tech_products') || '[]');
      } catch {
        return [];
      }
    };

    const saveCustomLocal = (prods: TechProduct[]) => {
      try {
        localStorage.setItem('custom_tech_products', JSON.stringify(prods));
      } catch (e) {
        console.warn('LocalStorage save custom products error:', e);
      }
    };

    if (editingProduct) {
      // Edit existing product
      const updatedProd: TechProduct = { id: editingProduct.id, ...payload };
      const customLocal = getCustomLocal();
      const updatedCustom = customLocal.map(p => p.id === editingProduct.id ? updatedProd : p);
      saveCustomLocal(updatedCustom);

      setLocalProducts(prev => prev.map(p => p.id === editingProduct.id ? updatedProd : p));
      showToast(`Product "${payload.name}" updated successfully!`);

      try {
        await setDoc(doc(db, 'products', editingProduct.id), {
          ...payload,
          id: editingProduct.id,
          updatedAt: serverTimestamp()
        }, { merge: true });
      } catch (err) {
        console.warn("Firestore edit product warning:", err);
      }
    } else {
      // Add new product
      const newId = 'prod_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      const newProdItem: TechProduct = {
        id: newId,
        ...payload
      };

      const customLocal = getCustomLocal();
      saveCustomLocal([newProdItem, ...customLocal.filter(p => p.id !== newId)]);

      setLocalProducts(prev => [newProdItem, ...prev.filter(p => p.id !== newId)]);
      showToast(`Product "${payload.name}" added successfully!`);

      try {
        await setDoc(doc(db, 'products', newId), {
          ...payload,
          id: newId,
          createdAt: serverTimestamp()
        });
      } catch (err) {
        console.warn("Firestore add product warning:", err);
      }
    }

    setIsProductModalOpen(false);
  };

  const handleDeleteProduct = async (productId: string) => {
    if (!window.confirm("Are you sure you want to delete this product?")) return;
    try {
      await deleteDoc(doc(db, 'products', productId));
    } catch (err) {
      console.warn("Firestore delete product warning:", err);
    }
    
    try {
      const customLocal: TechProduct[] = JSON.parse(localStorage.getItem('custom_tech_products') || '[]');
      localStorage.setItem('custom_tech_products', JSON.stringify(customLocal.filter(p => p.id !== productId)));
    } catch (e) {
      console.warn('LocalStorage error on delete:', e);
    }

    setLocalProducts(prev => prev.filter(p => p.id !== productId));
    showToast("Product removed");
  };

  // CATEGORY ACTIONS (ADD, EDIT, DELETE)
  const openAddCategoryModal = () => {
    setEditingCategory(null);
    setCategoryForm({
      title: '',
      description: '',
      iconName: 'Wrench',
      subCategories: 'Repair & Diagnostics, Software Installation'
    });
    setIsCategoryModalOpen(true);
  };

  const openEditCategoryModal = (cat: ServiceCategory) => {
    setEditingCategory(cat);
    setCategoryForm({
      title: cat.title,
      description: cat.description,
      iconName: cat.iconName || 'Wrench',
      subCategories: cat.subCategories ? cat.subCategories.map(s => s.name).join(', ') : ''
    });
    setIsCategoryModalOpen(true);
  };

  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!categoryForm.title.trim()) {
      alert("Please enter a category title.");
      return;
    }

    const subCats = categoryForm.subCategories
      ? categoryForm.subCategories.split(',').map((name, idx) => ({
          id: `sub_${idx}_${Date.now()}`,
          name: name.trim(),
          description: `Professional ${name.trim()} services`,
          estimatedPrice: 999,
          deliveryTime: 'Same Day',
          fields: []
        })).filter(s => s.name)
      : [];

    const payload = {
      title: categoryForm.title.trim(),
      description: categoryForm.description.trim() || 'Custom service category',
      iconName: categoryForm.iconName || 'Wrench',
      iconBg: 'bg-blue-100 text-blue-600',
      bgGradient: 'from-blue-500 to-indigo-600',
      subCategories: subCats
    };

    if (editingCategory) {
      try {
        await setDoc(doc(db, 'categories', editingCategory.id), {
          ...payload,
          updatedAt: serverTimestamp()
        }, { merge: true });
      } catch (err) {
        console.warn("Firestore category edit error:", err);
      }

      setLocalCategories(prev => prev.map(c => c.id === editingCategory.id ? { ...c, ...payload } : c));
      showToast(`Category "${payload.title}" updated!`);
    } else {
      let newId = 'cat_' + Date.now();
      try {
        const docRef = await addDoc(collection(db, 'categories'), {
          ...payload,
          createdAt: serverTimestamp()
        });
        newId = docRef.id;
      } catch (err) {
        console.warn("Firestore category add error:", err);
      }

      const newCategory: ServiceCategory = {
        id: newId,
        ...payload
      };

      setLocalCategories(prev => [newCategory, ...prev]);
      showToast(`Category "${payload.title}" added!`);
    }

    setIsCategoryModalOpen(false);
  };

  const handleDeleteCategory = async (categoryId: string) => {
    if (!window.confirm("Are you sure you want to delete this category?")) return;
    try {
      await deleteDoc(doc(db, 'categories', categoryId));
    } catch (err) {
      console.warn("Firestore category delete error:", err);
    }
    setLocalCategories(prev => prev.filter(c => c.id !== categoryId));
    showToast("Category removed");
  };

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'orders', label: 'Manage Orders', icon: ShoppingBag },
    { id: 'users', label: 'Manage Users', icon: Users },
    { id: 'followers', label: 'App Followers / SMS', icon: UserPlus },
    { id: 'products', label: 'Tech Products', icon: Package },
    { id: 'services', label: 'Services & Tools', icon: Layers },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="flex flex-col md:flex-row h-screen bg-slate-50 w-full fixed inset-0 z-50 overflow-hidden text-slate-800 font-sans">
      
      {/* Notification Toast */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-slate-900 text-white text-xs font-bold px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-top duration-300">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between bg-slate-900 text-white p-4 shadow-md z-20 w-full">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-6 h-6 text-blue-500" />
          <h1 className="text-lg font-black tracking-wider uppercase">Admin</h1>
        </div>
        <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="p-2 bg-slate-800 rounded-lg">
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Sidebar Desktop + Mobile Overlay */}
      <div className={`${mobileMenuOpen ? 'flex' : 'hidden'} md:flex flex-col absolute md:relative inset-0 md:inset-auto z-30 w-full md:w-64 bg-slate-900 text-white shadow-2xl`}>
        <div className="hidden md:flex p-6 border-b border-slate-800 items-center gap-3">
          <ShieldAlert className="w-8 h-8 text-blue-500" />
          <div>
            <h1 className="text-lg font-black tracking-wider text-white uppercase">Admin Panel</h1>
            <p className="text-[10px] text-slate-400 font-medium">Secure Access</p>
          </div>
        </div>
        
        <nav className="flex-1 py-4 overflow-y-auto">
          {menuItems.map(item => {
            const Icon = item.icon;
            return (
              <button 
                key={item.id}
                onClick={() => { setActiveMenu(item.id); setMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-6 py-4 text-sm font-bold transition cursor-pointer ${activeMenu === item.id ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
              >
                <Icon className="w-5 h-5" />
                {item.label}
              </button>
            )
          })}
        </nav>
        
        <div className="p-4 border-t border-slate-800 pb-10 md:pb-4">
          <button 
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-slate-800 hover:bg-rose-600 text-slate-300 hover:text-white rounded-xl text-sm font-bold transition cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            Exit Admin
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden w-full relative z-0 bg-slate-50">
        <header className="hidden md:flex bg-white border-b border-slate-200 px-8 py-5 items-center justify-between shadow-xs">
          <h2 className="text-xl font-black text-slate-800">
            {menuItems.find(m => m.id === activeMenu)?.label}
          </h2>
          <div className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-1.5 rounded-full">
            Admin Logged In
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-8 w-full">
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : activeMenu === 'orders' ? (
            <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden w-full">
              <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                 <h3 className="font-bold text-lg">All Orders ({orders.length})</h3>
              </div>
              <div className="overflow-x-auto w-full">
                <table className="w-full text-left border-collapse min-w-[600px]">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-xs uppercase tracking-wider font-bold text-slate-500">
                      <th className="p-4 pl-6">Order Info</th>
                      <th className="p-4">Customer</th>
                      <th className="p-4">Status</th>
                      <th className="p-4">Date</th>
                      <th className="p-4 text-right pr-6">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {orders.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="p-8 text-center text-slate-400 font-medium text-sm">
                          No orders found.
                        </td>
                      </tr>
                    ) : (
                      orders.map((order) => (
                        <tr key={order.id} className="hover:bg-slate-50 transition">
                          <td className="p-4 pl-6">
                            <div className="font-bold text-sm text-slate-800">
                              {order.type === 'service' ? order.data?.categoryName : order.data?.productName}
                            </div>
                            <div className="text-xs text-slate-500 mt-0.5">
                              {order.type === 'service' ? 'Service Request' : 'Product Order'}
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="font-medium text-sm text-slate-700">{order.data?.customerName || 'N/A'}</div>
                            <div className="text-xs text-slate-500">{order.data?.email || 'N/A'}</div>
                          </td>
                          <td className="p-4">
                            <select 
                              value={order.status} 
                              onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                              className="text-xs font-bold rounded-lg border-slate-200 bg-white shadow-xs focus:ring-blue-500 focus:border-blue-500 px-2 py-1 cursor-pointer"
                            >
                              <option value="Received">Received</option>
                              <option value="In Progress">In Progress</option>
                              <option value="Completed">Completed</option>
                              <option value="Cancelled">Cancelled</option>
                            </select>
                          </td>
                          <td className="p-4 text-xs font-medium text-slate-600">
                            {order.createdAt?.toMillis ? new Date(order.createdAt.toMillis()).toLocaleDateString() : 'Just now'}
                          </td>
                          <td className="p-4 text-right pr-6">
                            <button 
                              onClick={() => deleteOrder(order.id)}
                              className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                              title="Delete Order"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          ) : activeMenu === 'users' ? (
             <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden w-full">
              <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                 <h3 className="font-bold text-lg">Registered Users ({users.length})</h3>
              </div>
              <div className="overflow-x-auto w-full">
                <table className="w-full text-left border-collapse min-w-[600px]">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-xs uppercase tracking-wider font-bold text-slate-500">
                      <th className="p-4 pl-6">Name</th>
                      <th className="p-4">Email</th>
                      <th className="p-4">Role</th>
                      <th className="p-4">Joined</th>
                      <th className="p-4 text-right pr-6">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {users.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="p-8 text-center text-slate-400 font-medium text-sm">
                          No users found.
                        </td>
                      </tr>
                    ) : (
                      users.map((u) => (
                        <tr key={u.id} className="hover:bg-slate-50 transition">
                          <td className="p-4 pl-6">
                            <div className="font-bold text-sm text-slate-800">
                              {u.displayName || 'Unknown'}
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="text-sm text-slate-600">{u.email || 'N/A'}</div>
                          </td>
                          <td className="p-4">
                            <span className="px-2 py-1 bg-blue-100 text-blue-600 rounded-full text-[10px] font-black uppercase">
                              {u.email === 'kaparrst@gmail.com' ? 'Admin' : 'User'}
                            </span>
                          </td>
                          <td className="p-4 text-xs font-medium text-slate-600">
                            {u.createdAt?.toMillis ? new Date(u.createdAt.toMillis()).toLocaleDateString() : 'N/A'}
                          </td>
                          <td className="p-4 text-right pr-6 flex justify-end gap-2">
                            <button 
                              onClick={() => openEditUserModal(u)}
                              className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition cursor-pointer"
                              title="Edit User"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => deleteUser(u.id)}
                              className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                              title="Delete User"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          ) : activeMenu === 'followers' ? (
            <div className="space-y-6 w-full">
              {/* Header Banner & Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center font-bold">
                    <UserPlus className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total App Followers</p>
                    <h3 className="text-2xl font-black text-slate-900">{subscribers.length}</h3>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
                  <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center font-bold">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Email IDs Collected</p>
                    <h3 className="text-2xl font-black text-slate-900">{subscribers.filter(s => s.email).length}</h3>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
                  <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center font-bold">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Phone Contacts for SMS</p>
                    <h3 className="text-2xl font-black text-slate-900">{subscribers.filter(s => s.phone && s.phone.trim()).length}</h3>
                  </div>
                </div>
              </div>

              {/* Bulk SMS & Email Campaign Composer Box */}
              <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-5 shadow-lg space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-blue-400" />
                    <h3 className="font-extrabold text-sm text-white">Bulk SMS & Marketing Message Helper</h3>
                  </div>
                  <span className="text-[10px] bg-blue-500/20 text-blue-300 border border-blue-400/30 px-2.5 py-0.5 rounded-full font-bold">
                    RST Admin Tool
                  </span>
                </div>

                <p className="text-xs text-slate-300">
                  Compose an offer or notification below. Use the copy buttons to get formatted recipient emails or phone numbers for bulk sending via SMS gateway or email broadcast!
                </p>

                <textarea
                  rows={2}
                  placeholder="e.g. 🔥 RST Digital Special Offer: Get 15% discount on all laptop repairs & tech accessories this week! Visit RST Digital Solutions App now."
                  value={smsCampaignText}
                  onChange={(e) => setSmsCampaignText(e.target.value)}
                  className="w-full p-3 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />

                <div className="flex flex-wrap items-center gap-2.5 pt-1">
                  <button
                    onClick={handleCopyAllEmails}
                    className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer shadow-sm"
                  >
                    <Copy className="w-3.5 h-3.5" /> Copy All {subscribers.length} Email IDs
                  </button>

                  <button
                    onClick={handleCopyPhoneNumbers}
                    className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer shadow-sm"
                  >
                    <Phone className="w-3.5 h-3.5" /> Copy All Phone Numbers for Bulk SMS
                  </button>

                  <button
                    onClick={handleExportSubscribersCSV}
                    className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" /> Export CSV File
                  </button>
                </div>
              </div>

              {/* Followers Data Table Container */}
              <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden w-full">
                <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div>
                    <h3 className="font-bold text-base text-slate-900">App Followers & Email List ({subscribers.length})</h3>
                    <p className="text-xs text-slate-500">Collected automatically from "Follow Us" in user app</p>
                  </div>

                  <div className="relative w-full sm:w-64">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Search email, name, phone..."
                      value={subscriberSearch}
                      onChange={(e) => setSubscriberSearch(e.target.value)}
                      className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                    />
                  </div>
                </div>

                <div className="overflow-x-auto w-full">
                  <table className="w-full text-left border-collapse min-w-[650px]">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-xs uppercase tracking-wider font-bold text-slate-500">
                        <th className="p-4 pl-6">Customer Email ID</th>
                        <th className="p-4">Name</th>
                        <th className="p-4">Mobile / SMS Contact</th>
                        <th className="p-4">Follow Date</th>
                        <th className="p-4 text-right pr-6">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {subscribers.filter(s => {
                        if (!subscriberSearch.trim()) return true;
                        const q = subscriberSearch.toLowerCase();
                        return (s.email || '').toLowerCase().includes(q) ||
                               (s.name || '').toLowerCase().includes(q) ||
                               (s.phone || '').toLowerCase().includes(q);
                      }).length === 0 ? (
                        <tr>
                          <td colSpan={5} className="p-8 text-center text-slate-400 font-medium text-sm">
                            {subscriberSearch ? 'No followers match your search query.' : 'No app followers registered yet. Customers can click "Follow Us" in the user app.'}
                          </td>
                        </tr>
                      ) : (
                        subscribers.filter(s => {
                          if (!subscriberSearch.trim()) return true;
                          const q = subscriberSearch.toLowerCase();
                          return (s.email || '').toLowerCase().includes(q) ||
                                 (s.name || '').toLowerCase().includes(q) ||
                                 (s.phone || '').toLowerCase().includes(q);
                        }).map((sub, idx) => (
                          <tr key={sub.id || idx} className="hover:bg-slate-50/80 transition">
                            <td className="p-4 pl-6">
                              <div className="flex items-center gap-2">
                                <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-black text-xs shrink-0">
                                  <Mail className="w-4 h-4" />
                                </div>
                                <div>
                                  <span className="font-bold text-xs text-slate-900 block">{sub.email}</span>
                                  <span className="text-[10px] text-emerald-600 font-bold">✓ Active App Follower</span>
                                </div>
                              </div>
                            </td>

                            <td className="p-4 text-xs font-medium text-slate-700">
                              {sub.name || 'App User'}
                            </td>

                            <td className="p-4 text-xs font-mono font-medium text-slate-700">
                              {sub.phone ? (
                                <span className="bg-slate-100 px-2 py-1 rounded-md text-slate-800">{sub.phone}</span>
                              ) : (
                                <span className="text-slate-400 italic">Not provided</span>
                              )}
                            </td>

                            <td className="p-4 text-xs font-medium text-slate-500">
                              {sub.subscribedAt || sub.createdAt ? new Date(sub.subscribedAt || sub.createdAt).toLocaleDateString() : 'Recently'}
                            </td>

                            <td className="p-4 text-right pr-6">
                              <div className="flex items-center justify-end gap-1">
                                <button
                                  onClick={() => handleCopySingleEmail(sub.email)}
                                  className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition cursor-pointer"
                                  title="Copy Email ID"
                                >
                                  <Copy className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => handleDeleteSubscriber(sub.id || sub.email)}
                                  className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                                  title="Delete Follower Record"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : activeMenu === 'products' ? (
            <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden w-full">
              <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                 <div>
                   <h3 className="font-bold text-lg">Product Catalog</h3>
                   <p className="text-xs text-slate-500">Manage laptops, desktops, and tech accessories</p>
                 </div>
                 <button 
                   onClick={openAddProductModal}
                   className="flex items-center gap-1.5 bg-blue-600 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-blue-700 transition cursor-pointer shadow-sm"
                 >
                   <Plus className="w-4 h-4" /> Add Product
                 </button>
              </div>
              <div className="overflow-x-auto w-full">
                <table className="w-full text-left border-collapse min-w-[600px]">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-xs uppercase tracking-wider font-bold text-slate-500">
                      <th className="p-4 pl-6">Product</th>
                      <th className="p-4">Category</th>
                      <th className="p-4">Price</th>
                      <th className="p-4">Stock</th>
                      <th className="p-4 text-right pr-6">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {localProducts.map(p => (
                      <tr key={p.id} className="hover:bg-slate-50 transition">
                        <td className="p-4 pl-6">
                          <div className="flex items-center gap-3">
                            <img src={p.imageUrl} alt={p.name} className="w-12 h-12 rounded-xl object-cover bg-slate-100 border border-slate-200 shrink-0" />
                            <div>
                              <div className="font-bold text-sm text-slate-800">{p.name}</div>
                              <div className="text-[10px] text-slate-400 font-medium line-clamp-1">{Array.isArray(p.specs) ? p.specs.join(' • ') : p.specs}</div>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <span className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-full text-[10px] font-black uppercase tracking-wider">{p.category}</span>
                        </td>
                        <td className="p-4 font-black text-sm text-blue-600">₹{p.price.toLocaleString()}</td>
                        <td className="p-4">
                          <div className="font-bold text-xs text-slate-700">{p.stock} units</div>
                        </td>
                        <td className="p-4 text-right pr-6 flex justify-end gap-2 items-center">
                            <button 
                              onClick={() => openEditProductModal(p)}
                              className="p-2 text-blue-600 hover:bg-blue-50 rounded-xl transition cursor-pointer"
                              title="Edit Product"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => handleDeleteProduct(p.id)}
                              className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition cursor-pointer"
                              title="Delete Product"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : activeMenu === 'services' ? (
            <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden w-full">
              <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                 <div>
                   <h3 className="font-bold text-lg">Service Categories</h3>
                   <p className="text-xs text-slate-500">Configure repair, installation & AI services</p>
                 </div>
                 <button 
                   onClick={openAddCategoryModal}
                   className="flex items-center gap-1.5 bg-blue-600 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-blue-700 transition cursor-pointer shadow-sm"
                 >
                   <Plus className="w-4 h-4" /> Add Category
                 </button>
              </div>
              <div className="overflow-x-auto w-full">
                <table className="w-full text-left border-collapse min-w-[600px]">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-xs uppercase tracking-wider font-bold text-slate-500">
                      <th className="p-4 pl-6">Category</th>
                      <th className="p-4">Description</th>
                      <th className="p-4">Sub-services</th>
                      <th className="p-4 text-right pr-6">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {localCategories.map(s => (
                      <tr key={s.id} className="hover:bg-slate-50 transition">
                        <td className="p-4 pl-6">
                          <div className="font-bold text-sm text-slate-800">{s.title}</div>
                        </td>
                        <td className="p-4">
                          <div className="text-xs text-slate-600 max-w-xs">{s.description}</div>
                        </td>
                        <td className="p-4">
                          <span className="px-2.5 py-1 bg-blue-100 text-blue-600 rounded-full text-[10px] font-black uppercase">
                            {s.subCategories ? s.subCategories.length : 0} items
                          </span>
                        </td>
                        <td className="p-4 text-right pr-6 flex justify-end gap-2 items-center">
                            <button 
                              onClick={() => openEditCategoryModal(s)}
                              className="p-2 text-blue-600 hover:bg-blue-50 rounded-xl transition cursor-pointer"
                              title="Edit Category"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => handleDeleteCategory(s.id)}
                              className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition cursor-pointer"
                              title="Delete Category"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : activeMenu === 'dashboard' ? (
             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               <div className="bg-white p-6 rounded-2xl shadow-xs border border-slate-200 flex flex-col items-center text-center">
                 <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mb-4">
                   <ShoppingBag className="w-8 h-8" />
                 </div>
                 <h4 className="text-slate-500 font-bold text-sm">Total Orders</h4>
                 <p className="text-4xl font-black text-slate-800 mt-2">{orders.length}</p>
               </div>
               <div className="bg-white p-6 rounded-2xl shadow-xs border border-slate-200 flex flex-col items-center text-center">
                 <div className="w-16 h-16 bg-green-50 text-green-600 rounded-full flex items-center justify-center mb-4">
                   <Users className="w-8 h-8" />
                 </div>
                 <h4 className="text-slate-500 font-bold text-sm">Registered Users</h4>
                 <p className="text-4xl font-black text-slate-800 mt-2">{users.length}</p>
               </div>
               <div className="bg-white p-6 rounded-2xl shadow-xs border border-slate-200 flex flex-col items-center text-center">
                 <div className="w-16 h-16 bg-purple-50 text-purple-600 rounded-full flex items-center justify-center mb-4">
                   <Package className="w-8 h-8" />
                 </div>
                 <h4 className="text-slate-500 font-bold text-sm">Products Catalog</h4>
                 <p className="text-4xl font-black text-slate-800 mt-2">{localProducts.length}</p>
               </div>
             </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center p-8 bg-white rounded-2xl shadow-xs border border-slate-200">
              <div className="w-20 h-20 bg-slate-50 rounded-3xl flex items-center justify-center mb-6 shadow-inner">
                 <Settings className="w-10 h-10 text-slate-300" />
              </div>
              <h3 className="text-2xl font-black text-slate-800 mb-2">Settings Configuration</h3>
              <p className="text-sm text-slate-500 max-w-md font-medium leading-relaxed">
                App configuration and settings control panel will be available here. You have total control over app settings.
              </p>
            </div>
          )}
        </main>
      </div>

      {/* ADD / EDIT PRODUCT MODAL */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-3xl p-6 shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
              <h3 className="text-lg font-black text-slate-900">
                {editingProduct ? 'Edit Product' : 'Add New Product'}
              </h3>
              <button 
                onClick={() => setIsProductModalOpen(false)}
                className="p-1.5 hover:bg-slate-100 rounded-xl transition text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Product Name *</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. HP Pavilion 15 Laptop" 
                  value={productForm.name}
                  onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-hidden font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Category *</label>
                  <select 
                    value={productForm.category}
                    onChange={(e) => setProductForm({ ...productForm, category: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-hidden font-bold cursor-pointer bg-white"
                  >
                    <option value="laptop">Laptop</option>
                    <option value="desktop">Desktop</option>
                    <option value="mobile">Mobile / Tablet</option>
                    <option value="accessory">Accessory</option>
                    <option value="audio">Audio / Sound</option>
                    <option value="custom">+ Write Custom Category...</option>
                  </select>

                  {productForm.category === 'custom' && (
                    <input 
                      type="text"
                      required
                      placeholder="Type custom category name..."
                      value={productForm.customCategory}
                      onChange={(e) => setProductForm({ ...productForm, customCategory: e.target.value })}
                      className="w-full mt-2 px-3.5 py-2 text-xs rounded-xl border border-blue-400 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-hidden font-medium bg-blue-50/40"
                    />
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Price (₹) *</label>
                  <input 
                    type="number" 
                    required
                    placeholder="e.g. 55990" 
                    value={productForm.price}
                    onChange={(e) => setProductForm({ ...productForm, price: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-hidden font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Stock Units</label>
                  <input 
                    type="number" 
                    placeholder="e.g. 15" 
                    value={productForm.stock}
                    onChange={(e) => setProductForm({ ...productForm, stock: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-hidden font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Rating</label>
                  <input 
                    type="number" 
                    step="0.1"
                    max="5"
                    placeholder="e.g. 4.8" 
                    value={productForm.rating}
                    onChange={(e) => setProductForm({ ...productForm, rating: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-hidden font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Image URL / Upload Image</label>
                <div className="flex gap-2 items-center">
                  <input 
                    type="text" 
                    placeholder="https://images.unsplash.com/... or upload file" 
                    value={productForm.imageUrl}
                    onChange={(e) => setProductForm({ ...productForm, imageUrl: e.target.value })}
                    className="flex-1 px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-hidden font-medium"
                  />
                  <label className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer border border-slate-200 shrink-0">
                    <Upload className="w-4 h-4 text-slate-600" />
                    <span>Upload</span>
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (event) => {
                            const img = new Image();
                            img.onload = () => {
                              const canvas = document.createElement('canvas');
                              const maxDim = 500;
                              let width = img.width;
                              let height = img.height;
                              if (width > height) {
                                if (width > maxDim) {
                                  height = Math.round((height * maxDim) / width);
                                  width = maxDim;
                                }
                              } else {
                                if (height > maxDim) {
                                  width = Math.round((width * maxDim) / height);
                                  height = maxDim;
                                }
                              }
                              canvas.width = width;
                              canvas.height = height;
                              const ctx = canvas.getContext('2d');
                              if (ctx) {
                                ctx.drawImage(img, 0, 0, width, height);
                                const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
                                setProductForm(prev => ({ ...prev, imageUrl: dataUrl }));
                              } else if (event.target?.result) {
                                setProductForm(prev => ({ ...prev, imageUrl: event.target?.result as string }));
                              }
                            };
                            if (event.target?.result) {
                              img.src = event.target.result as string;
                            }
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                  {productForm.imageUrl && (
                    <img src={productForm.imageUrl} alt="preview" className="w-9 h-9 rounded-lg object-cover border border-slate-200 shrink-0" />
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Specifications (Comma separated)</label>
                <textarea 
                  rows={2}
                  placeholder="e.g. Intel Core i5, 16GB RAM, 512GB SSD, 15.6 FHD" 
                  value={productForm.specs}
                  onChange={(e) => setProductForm({ ...productForm, specs: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-hidden font-medium"
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button 
                  type="button" 
                  onClick={() => setIsProductModalOpen(false)}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="flex-[2] py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-600/30 transition cursor-pointer"
                >
                  {editingProduct ? 'Save Product Changes' : 'Add Product to Catalog'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD / EDIT CATEGORY MODAL */}
      {isCategoryModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-3xl p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
              <h3 className="text-lg font-black text-slate-900">
                {editingCategory ? 'Edit Service Category' : 'Add Service Category'}
              </h3>
              <button 
                onClick={() => setIsCategoryModalOpen(false)}
                className="p-1.5 hover:bg-slate-100 rounded-xl transition text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCategory} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Category Title *</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. Cloud & Server Management" 
                  value={categoryForm.title}
                  onChange={(e) => setCategoryForm({ ...categoryForm, title: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-hidden font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Description</label>
                <textarea 
                  rows={2}
                  placeholder="e.g. Server deployment, cloud setup, and network infrastructure." 
                  value={categoryForm.description}
                  onChange={(e) => setCategoryForm({ ...categoryForm, description: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-hidden font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Sub-Services (Comma separated)</label>
                <input 
                  type="text" 
                  placeholder="e.g. Linux Hosting, AWS Setup, SSL Certification" 
                  value={categoryForm.subCategories}
                  onChange={(e) => setCategoryForm({ ...categoryForm, subCategories: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-hidden font-medium"
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button 
                  type="button" 
                  onClick={() => setIsCategoryModalOpen(false)}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="flex-[2] py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-600/30 transition cursor-pointer"
                >
                  {editingCategory ? 'Save Category Changes' : 'Create Category'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT USER MODAL */}
      {isUserModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
              <h3 className="text-lg font-black text-slate-900">Edit User Details</h3>
              <button 
                onClick={() => setIsUserModalOpen(false)}
                className="p-1.5 hover:bg-slate-100 rounded-xl transition text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveUser} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Display Name</label>
                <input 
                  type="text" 
                  required
                  value={userForm.displayName}
                  onChange={(e) => setUserForm({ ...userForm, displayName: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-hidden font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Email Address</label>
                <input 
                  type="email" 
                  required
                  value={userForm.email}
                  onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-hidden font-medium"
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button 
                  type="button" 
                  onClick={() => setIsUserModalOpen(false)}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="flex-[2] py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-600/30 transition cursor-pointer"
                >
                  Save User
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
