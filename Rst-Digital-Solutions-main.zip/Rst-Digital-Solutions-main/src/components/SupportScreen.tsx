import React, { useState } from 'react';
import { Headphones, Send, MessageSquare, PhoneCall, Mail, CheckCircle2, ShieldCheck } from 'lucide-react';

export const SupportScreen: React.FC = () => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [category, setCategory] = useState('Online Services Support');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !message) return;
    setIsSubmitted(true);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6 pb-24 text-slate-900 dark:text-slate-100">
      <div>
        <h1 className="text-2xl font-black flex items-center gap-2">
          <Headphones className="w-6 h-6 text-blue-600" /> Customer Support & Helpline
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Have questions about your service form, PC build, or AI tools? We're available 24/7.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Direct Contact Info */}
        <div className="space-y-3">
          <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-bold text-blue-600 dark:text-blue-400">
              <PhoneCall className="w-4 h-4" /> 24/7 Phone Support
            </div>
            <div className="text-sm font-black">+1 (800) 832-4389</div>
            <p className="text-[11px] text-slate-400">Instant connection with tech technicians.</p>
          </div>

          <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-bold text-indigo-600 dark:text-indigo-400">
              <Mail className="w-4 h-4" /> Email Support
            </div>
            <div className="text-sm font-black">support@techeverywhere.com</div>
            <p className="text-[11px] text-slate-400">Replies within 1 hour guaranteed.</p>
          </div>

          <div className="p-4 bg-gradient-to-tr from-blue-900 to-indigo-900 text-white rounded-2xl space-y-2 border border-blue-500/30">
            <ShieldCheck className="w-6 h-6 text-emerald-400" />
            <h3 className="text-xs font-bold">Doorstep Pickup Available</h3>
            <p className="text-[11px] text-slate-200">
              Need on-site laptop repair? Our certified technician visits your home or office.
            </p>
          </div>
        </div>

        {/* Support Ticket Form */}
        <div className="md:col-span-2 bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200/80 dark:border-slate-800 space-y-4">
          <h2 className="text-base font-bold">Submit a Support Ticket / Form</h2>

          {isSubmitted ? (
            <div className="p-8 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-bold">Support Request Received!</h3>
              <p className="text-xs text-slate-500">
                A customer support agent will call you back at <span className="font-bold">{phone}</span> shortly.
              </p>
              <button
                onClick={() => setIsSubmitted(false)}
                className="px-4 py-2 bg-blue-600 text-white text-xs font-bold rounded-xl transition cursor-pointer"
              >
                Submit Another Inquiry
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Your Name</label>
                  <input
                    type="text"
                    required
                    placeholder="John Doe"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    required
                    placeholder="+1 (555) 000-0000"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Service Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                >
                  <option value="Online Services Support">Online Services Support</option>
                  <option value="AI Tools & Assistance">AI Tools & Assistance</option>
                  <option value="Computer / Laptop Sales Inquiry">Computer / Laptop Sales Inquiry</option>
                  <option value="Hardware Repair & On-Site Support">Hardware Repair & On-Site Support</option>
                  <option value="Billing & Orders">Billing & Orders</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">How can we help you?</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Describe your issue or question in detail..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" /> Submit Inquiry
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
