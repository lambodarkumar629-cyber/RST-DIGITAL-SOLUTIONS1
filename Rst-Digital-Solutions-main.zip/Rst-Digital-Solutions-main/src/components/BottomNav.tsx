import React from 'react';
import { Home, Wrench, ClipboardList, ShoppingCart, User, ShieldCheck } from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  cartCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
  cartCount
}) => {
  const tabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'orders', label: 'Services', icon: Wrench },
    { id: 'request', label: 'Request Form', icon: ClipboardList, isCenter: true },
    { id: 'cart', label: 'Cart', icon: ShoppingCart, badge: cartCount || 0 },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-slate-200/80 py-1.5 px-4 shadow-[0_-4px_20px_rgba(0,0,0,0.06)]">
      <div className="max-w-xl mx-auto flex items-end justify-around relative">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          if (tab.isCenter) {
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className="flex flex-col items-center justify-center -mt-5 cursor-pointer relative group"
              >
                <div className="w-13 h-13 rounded-full bg-blue-600 text-white shadow-lg flex items-center justify-center relative transition transform group-hover:scale-105 border-2 border-white">
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <span className={`text-[10px] font-bold mt-0.5 ${isActive ? 'text-blue-600' : 'text-slate-600'}`}>
                  {tab.label}
                </span>
              </button>
            );
          }

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center justify-center space-y-0.5 py-1 px-3 rounded-xl transition cursor-pointer ${
                isActive
                  ? 'text-blue-600 font-bold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'text-blue-600' : 'text-slate-500'}`} />
                {tab.badge ? (
                  <span className="absolute -top-1 -right-2 bg-rose-500 text-white text-[9px] font-extrabold w-3.5 h-3.5 rounded-full flex items-center justify-center">
                    {tab.badge}
                  </span>
                ) : null}
              </div>
              <span className="text-[10px] font-medium tracking-tight">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
