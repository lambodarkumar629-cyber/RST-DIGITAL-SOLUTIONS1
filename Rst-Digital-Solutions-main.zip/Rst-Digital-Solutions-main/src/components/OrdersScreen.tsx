import React, { useState } from 'react';
import { ServiceOrder } from '../types';
import { Clock, CheckCircle2, AlertCircle, FileText, Search, Filter, Phone, MapPin, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';

interface OrdersScreenProps {
  orders: ServiceOrder[];
  onBackToHome: () => void;
  onDeleteOrder: (id: string) => void;
}

export const OrdersScreen: React.FC<OrdersScreenProps> = ({ orders, onBackToHome, onDeleteOrder }) => {
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredOrders = orders.filter(o => {
    const matchesStatus = filterStatus === 'all' || o.status === filterStatus;
    const matchesSearch = o.categoryName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          o.subCategoryName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          o.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          o.id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6 pb-24 text-slate-900 dark:text-slate-100">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black flex items-center gap-2">
            <FileText className="w-6 h-6 text-blue-600" /> My Service Requests & Orders
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Track status, update details, or view receipts for all submitted category forms.
          </p>
        </div>
        <button
          onClick={onBackToHome}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition cursor-pointer self-start sm:self-auto"
        >
          + Request New Service
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 flex flex-wrap gap-3 items-center justify-between shadow-xs">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search by ID, Category, or Name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 text-xs">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="Received">Received</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
          </select>
        </div>
      </div>

      {/* Orders List */}
      <div className="space-y-4">
        {filteredOrders.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
              <FileText className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold">No Service Requests Found</h3>
            <p className="text-xs text-slate-500">Fill out any service category form from the homepage to get started.</p>
          </div>
        ) : (
          filteredOrders.map((order) => (
            <motion.div
              layout
              key={order.id}
              className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-mono text-xs font-bold rounded-lg">
                    {order.id}
                  </span>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    {order.categoryName} &bull; <span className="text-indigo-600 dark:text-indigo-400">{order.subCategoryName}</span>
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-2.5 py-1 text-[11px] font-bold rounded-full flex items-center gap-1 ${
                    order.status === 'Completed'
                      ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                      : order.status === 'In Progress'
                      ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                      : 'bg-blue-100 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                  }`}>
                    {order.status === 'Completed' ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                    {order.status}
                  </span>
                </div>
              </div>

              {/* Detail Breakdown */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="space-y-1 text-slate-600 dark:text-slate-300">
                  <div><span className="font-semibold text-slate-800 dark:text-slate-200">Customer:</span> {order.customerName}</div>
                  <div className="flex items-center gap-1"><Phone className="w-3 h-3 text-slate-400" /> {order.phone}</div>
                  {order.address && (
                    <div className="flex items-center gap-1"><MapPin className="w-3 h-3 text-slate-400" /> {order.address}</div>
                  )}
                </div>

                <div className="space-y-1 text-slate-600 dark:text-slate-300">
                  <div><span className="font-semibold text-slate-800 dark:text-slate-200">Turnaround:</span> {order.urgency}</div>
                  <div><span className="font-semibold text-slate-800 dark:text-slate-200">Submitted:</span> {order.createdAt}</div>
                </div>
              </div>

              {/* Form custom values summary */}
              {Object.keys(order.formData).length > 0 && (
                <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl text-xs space-y-1">
                  <span className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Form Details Submitted:</span>
                  {Object.entries(order.formData).map(([k, v]) => (
                    <div key={k} className="flex justify-between text-[11px] text-slate-600 dark:text-slate-400">
                      <span className="capitalize">{k.replace(/([A-Z])/g, ' $1')}:</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{v}</span>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-slate-400">Total Price Quote:</span>
                  <span className="text-base font-extrabold text-blue-600 dark:text-blue-400">${order.estimatedPrice}</span>
                </div>
                <button
                  onClick={() => onDeleteOrder(order.id)}
                  className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/50 dark:hover:bg-rose-900/60 dark:text-rose-300 rounded-xl font-bold flex items-center gap-1 transition cursor-pointer"
                  title="Delete Order"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Delete
                </button>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};
