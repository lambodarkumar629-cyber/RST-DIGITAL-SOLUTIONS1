import React, { useState, useRef } from 'react';
import { 
  User, Phone, Mail, MapPin, Settings, FileText, AlertCircle,
  Monitor, Calendar, UploadCloud, Shield, Send, CheckCircle2,
  Headphones, HardDrive, ArrowLeft, CreditCard, Lock,
  Globe, Palette, ShoppingBag, MoreHorizontal, Wifi, Printer,
  ShieldAlert, Database, Laptop, Sparkles, Clock, Check,
  Download, RefreshCw, FileUp, Cpu
} from 'lucide-react';

import rstPosterImg from '../assets/images/rst_form_poster_1786013428128.jpg';

interface CustomerRequestFormProps {
  onBack?: () => void;
  onSubmitSuccess?: () => void;
  onSubmitOrder?: (order: any) => void;
  preSelectedData?: any;
  onClearPreSelected?: () => void;
}

import { categories } from '../data/servicesData';
import * as LucideIcons from 'lucide-react';

export const CustomerRequestForm: React.FC<CustomerRequestFormProps> = ({ 
  onBack, 
  onSubmitSuccess, 
  onSubmitOrder,
  preSelectedData,
  onClearPreSelected 
}) => {
  const [viewMode, setViewMode] = useState<'form' | 'poster'>('form');

  const availableServices = categories.map(cat => ({
    name: cat.title,
    icon: (LucideIcons as any)[cat.iconName] || LucideIcons.Grid
  }));

  const [formData, setFormData] = useState(() => {
    const saved = localStorage.getItem('customer_profile_data');
    let initialProfile = {
      fullName: '',
      country: 'Nepal',
      mobileCode: '+977',
      mobile: '',
      state: 'Bagmati Province',
      email: '',
      city: 'Kathmandu',
      address: ''
    };
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        initialProfile = {
          fullName: parsed.fullName || '',
          country: parsed.country || 'Nepal',
          mobileCode: parsed.phoneCode || parsed.mobileCode || '+977',
          mobile: parsed.phone || parsed.mobile || '',
          state: parsed.state || 'Bagmati Province',
          email: parsed.email || '',
          city: parsed.city || 'Kathmandu',
          address: parsed.address || ''
        };
      } catch (e) {
        // ignore
      }
    }

    // Pre-fill logic for services
    const initialServices = preSelectedData?.categoryName ? [preSelectedData.categoryName] : ['Computer Repair', 'Windows Installation'];
    const initialProblem = preSelectedData?.formData ? Object.entries(preSelectedData.formData).map(([k, v]) => `${k}: ${v}`).join(' | ') : '';

    return {
      ...initialProfile,
      contactMethod: 'WhatsApp',
      services: initialServices,
      otherService: preSelectedData?.subCategoryName || '',
      problem: initialProblem,
      urgency: 'Normal',
      deviceType: preSelectedData?.categoryName || 'Laptop',
      brand: '',
      model: '',
      os: 'Windows 11',
      serial: '',
      supportType: 'Video Call Support',
      uploadedFileName: '',
      date: new Date().toISOString().split('T')[0],
      time: '10:00',
      paymentMethod: 'eSewa',
      paymentId: '',
      agree: true
    };
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [referenceId, setReferenceId] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleServiceToggle = (serviceName: string) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(serviceName)
        ? prev.services.filter(s => s !== serviceName)
        : [...prev.services, serviceName]
    }));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({ ...prev, uploadedFileName: e.target.files![0].name }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const ref = `RST-${Math.floor(100000 + Math.random() * 900000)}`;
    
    // 1. Save customer profile details locally
    const profileToSave = {
      fullName: formData.fullName,
      email: formData.email,
      phoneCode: formData.mobileCode,
      phone: formData.mobile,
      country: formData.country,
      state: formData.state,
      city: formData.city,
      address: formData.address,
    };
    localStorage.setItem('customer_profile_data', JSON.stringify(profileToSave));

    setReferenceId(ref);
    setIsSubmitted(true);
    if (onSubmitSuccess) onSubmitSuccess();
  };

  // Download filled form as image canvas
  const handleDownloadImageWithText = () => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = rstPosterImg;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.drawImage(img, 0, 0);

      ctx.font = 'bold 22px Arial, sans-serif';
      ctx.fillStyle = '#0f172a';

      const drawText = (text: string, xRatio: number, yRatio: number) => {
        if (!text) return;
        ctx.fillText(text, img.width * xRatio, img.height * yRatio);
      };

      drawText(formData.fullName, 0.10, 0.225);
      drawText(`${formData.mobileCode} ${formData.mobile}`, 0.10, 0.280);
      drawText(formData.email, 0.10, 0.335);
      drawText(formData.address, 0.10, 0.390);
      drawText(formData.country, 0.49, 0.225);
      drawText(formData.state, 0.49, 0.280);
      drawText(formData.city, 0.49, 0.335);

      ctx.font = '18px Arial, sans-serif';
      if (formData.problem) {
        ctx.fillText(formData.problem.substring(0, 60), img.width * 0.52, img.height * 0.450);
      }
      drawText(formData.otherService, 0.08, 0.705);
      drawText(formData.brand, 0.73, 0.620);
      drawText(formData.model, 0.52, 0.675);
      drawText(formData.serial, 0.52, 0.730);
      drawText(formData.date, 0.69, 0.815);
      drawText(formData.time, 0.69, 0.870);
      drawText(formData.paymentId, 0.20, 0.805);

      const link = document.createElement('a');
      link.download = `RST_Service_Request_${formData.fullName || 'Form'}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    };
  };

  return (
    <div className="w-full min-h-screen bg-[#edf2f8] text-slate-800 font-sans pb-28">
      
      {/* STICKY TOP NAVIGATION BAR */}
      <header className="sticky top-0 z-40 bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 text-white shadow-xl px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {onBack && (
            <button 
              onClick={onBack}
              className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-xl transition flex items-center gap-1.5 text-xs font-bold"
            >
              <ArrowLeft className="w-4 h-4" /> Back
            </button>
          )}
          <div>
            <h1 className="text-base sm:text-lg font-black tracking-tight flex items-center gap-2">
              <span>RST DIGITAL SOLUTIONS</span>
              <span className="bg-orange-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                Official Form
              </span>
            </h1>
            <p className="text-[11px] text-blue-200 hidden sm:block">Customer Service Request Form</p>
          </div>
        </div>

        {/* View Toggle & Download */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setViewMode(viewMode === 'form' ? 'poster' : 'form')}
            className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5"
          >
            {viewMode === 'form' ? '🖼️ View Poster' : '📝 Editable Form'}
          </button>
          <button
            onClick={handleDownloadImageWithText}
            className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" /> Save
          </button>
        </div>
      </header>

      {/* SUBMIT CONFIRMATION MODAL */}
      {isSubmitted && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white text-slate-900 max-w-md w-full rounded-3xl p-6 sm:p-8 text-center space-y-4 shadow-2xl border-2 border-emerald-500 animate-in fade-in zoom-in duration-200">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h2 className="text-2xl font-black text-slate-900">Request Submitted Successfully!</h2>
            <p className="text-sm text-slate-600">
              Thank you <strong className="text-blue-600">{formData.fullName || 'Valued Customer'}</strong>! RST Digital Solutions will contact you on <strong className="text-blue-600">{formData.mobileCode} {formData.mobile}</strong> via {formData.contactMethod}.
            </p>
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-600 space-y-1.5 text-left">
              <div className="flex justify-between">
                <span>Reference ID:</span>
                <span className="font-mono font-bold text-slate-900">{referenceId}</span>
              </div>
              <div className="flex justify-between">
                <span>Selected Services:</span>
                <span className="font-bold text-blue-700">{formData.services.join(', ') || 'Custom Support'}</span>
              </div>
              <div className="flex justify-between">
                <span>Support Mode:</span>
                <span className="font-bold text-slate-800">{formData.supportType}</span>
              </div>
              <div className="flex justify-between">
                <span>Status:</span>
                <span className="text-emerald-600 font-bold">24/7 Support Agent Assigned</span>
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <button
                onClick={handleDownloadImageWithText}
                className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
              >
                <Download className="w-4 h-4" /> Save Form Copy
              </button>
              <button
                onClick={() => setIsSubmitted(false)}
                className="flex-1 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-md"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* POSTER VIEW MODE WITH LIVE INTERACTIVE OVERLAYS */}
      {viewMode === 'poster' ? (
        <div className="max-w-[1000px] mx-auto p-2 sm:p-4 flex flex-col items-center">
          <div className="w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-300 relative">
            {/* Poster background image */}
            <img 
              src={rstPosterImg} 
              alt="RST Digital Solutions Request Form Poster" 
              className="w-full h-auto block select-none"
            />

            {/* INTERACTIVE FORM OVERLAY mapped directly over the poster fields */}
            <form onSubmit={handleSubmit} className="absolute inset-0 w-full h-full text-[10px] sm:text-xs md:text-sm">
              
              {/* SECTION 1: CUSTOMER INFORMATION OVERLAYS */}
              {/* Full Name */}
              <input
                type="text"
                required
                value={formData.fullName}
                onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                placeholder="Enter your full name"
                className="absolute left-[12%] top-[21.8%] w-[34%] h-[2.8%] px-2 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 focus:border-blue-600 rounded outline-none font-medium text-[11px] sm:text-xs md:text-sm shadow-sm"
              />

              {/* Country */}
              <select
                value={formData.country}
                onChange={(e) => setFormData({...formData, country: e.target.value})}
                className="absolute left-[51.5%] top-[21.8%] w-[34%] h-[2.8%] px-1 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 focus:border-blue-600 rounded outline-none font-medium text-[11px] sm:text-xs md:text-sm cursor-pointer shadow-sm"
              >
                <option>Nepal</option>
                <option>India</option>
                <option>United States</option>
                <option>United Arab Emirates</option>
                <option>Australia</option>
                <option>United Kingdom</option>
              </select>

              {/* Mobile Code */}
              <select
                value={formData.mobileCode}
                onChange={(e) => setFormData({...formData, mobileCode: e.target.value})}
                className="absolute left-[12%] top-[26.8%] w-[10%] h-[2.8%] px-1 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 focus:border-blue-600 rounded outline-none font-bold text-[10px] sm:text-xs shadow-sm"
              >
                <option>+977</option>
                <option>+91</option>
                <option>+1</option>
                <option>+971</option>
              </select>

              {/* Mobile Number */}
              <input
                type="tel"
                required
                value={formData.mobile}
                onChange={(e) => setFormData({...formData, mobile: e.target.value})}
                placeholder="9812345678"
                className="absolute left-[22.5%] top-[26.8%] w-[23.5%] h-[2.8%] px-2 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 focus:border-blue-600 rounded outline-none font-medium text-[11px] sm:text-xs md:text-sm shadow-sm"
              />

              {/* State */}
              <select
                value={formData.state}
                onChange={(e) => setFormData({...formData, state: e.target.value})}
                className="absolute left-[51.5%] top-[26.8%] w-[34%] h-[2.8%] px-1 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 focus:border-blue-600 rounded outline-none font-medium text-[11px] sm:text-xs md:text-sm cursor-pointer shadow-sm"
              >
                <option>Bagmati Province</option>
                <option>Koshi Province</option>
                <option>Madhesh Province</option>
                <option>Gandaki Province</option>
                <option>Lumbini Province</option>
                <option>Karnali Province</option>
                <option>Sudurpashchim Province</option>
              </select>

              {/* Email Address */}
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                placeholder="example@gmail.com"
                className="absolute left-[12%] top-[31.8%] w-[34%] h-[2.8%] px-2 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 focus:border-blue-600 rounded outline-none font-medium text-[11px] sm:text-xs md:text-sm shadow-sm"
              />

              {/* City */}
              <select
                value={formData.city}
                onChange={(e) => setFormData({...formData, city: e.target.value})}
                className="absolute left-[51.5%] top-[31.8%] w-[34%] h-[2.8%] px-1 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 focus:border-blue-600 rounded outline-none font-medium text-[11px] sm:text-xs md:text-sm cursor-pointer shadow-sm"
              >
                <option>Kathmandu</option>
                <option>Lalitpur</option>
                <option>Bhaktapur</option>
                <option>Pokhara</option>
                <option>Chitwan</option>
                <option>Butwal</option>
                <option>Biratnagar</option>
                <option>Dharan</option>
              </select>

              {/* Address */}
              <input
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({...formData, address: e.target.value})}
                placeholder="Enter your full address"
                className="absolute left-[12%] top-[36.8%] w-[34%] h-[2.8%] px-2 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 focus:border-blue-600 rounded outline-none font-medium text-[11px] sm:text-xs md:text-sm shadow-sm"
              />

              {/* Contact Method Radios */}
              <div className="absolute left-[51.5%] top-[36.8%] w-[34%] h-[2.8%] flex items-center justify-around bg-white/90 rounded border border-blue-300 px-1 text-[10px] sm:text-xs font-bold text-slate-800">
                {['WhatsApp', 'Phone Call', 'Email'].map((method) => (
                  <label key={method} className="flex items-center gap-1 cursor-pointer">
                    <input
                      type="radio"
                      name="contactMethodPoster"
                      value={method}
                      checked={formData.contactMethod === method}
                      onChange={(e) => setFormData({...formData, contactMethod: e.target.value})}
                      className="accent-blue-600"
                    />
                    <span>{method}</span>
                  </label>
                ))}
              </div>


              {/* SECTION 2: SERVICES CHECKBOXES */}
              {/* AI Resume Builder */}
              <input
                type="checkbox"
                checked={formData.services.includes('AI Resume Builder')}
                onChange={() => handleServiceToggle('AI Resume Builder')}
                className="absolute left-[6.2%] top-[43.8%] w-[4%] h-[2%] accent-blue-600 cursor-pointer"
              />
              {/* CV / Cover Letter */}
              <input
                type="checkbox"
                checked={formData.services.includes('CV / Cover Letter')}
                onChange={() => handleServiceToggle('CV / Cover Letter')}
                className="absolute left-[28.5%] top-[43.8%] w-[4%] h-[2%] accent-blue-600 cursor-pointer"
              />

              {/* Computer Repair */}
              <input
                type="checkbox"
                checked={formData.services.includes('Computer Repair')}
                onChange={() => handleServiceToggle('Computer Repair')}
                className="absolute left-[6.2%] top-[46.3%] w-[4%] h-[2%] accent-blue-600 cursor-pointer"
              />
              {/* Laptop Repair */}
              <input
                type="checkbox"
                checked={formData.services.includes('Laptop Repair')}
                onChange={() => handleServiceToggle('Laptop Repair')}
                className="absolute left-[28.5%] top-[46.3%] w-[4%] h-[2%] accent-blue-600 cursor-pointer"
              />

              {/* Windows Installation */}
              <input
                type="checkbox"
                checked={formData.services.includes('Windows Installation')}
                onChange={() => handleServiceToggle('Windows Installation')}
                className="absolute left-[6.2%] top-[48.8%] w-[4%] h-[2%] accent-blue-600 cursor-pointer"
              />
              {/* Software Installation */}
              <input
                type="checkbox"
                checked={formData.services.includes('Software Installation')}
                onChange={() => handleServiceToggle('Software Installation')}
                className="absolute left-[28.5%] top-[48.8%] w-[4%] h-[2%] accent-blue-600 cursor-pointer"
              />

              {/* Virus Removal */}
              <input
                type="checkbox"
                checked={formData.services.includes('Virus Removal')}
                onChange={() => handleServiceToggle('Virus Removal')}
                className="absolute left-[6.2%] top-[51.3%] w-[4%] h-[2%] accent-blue-600 cursor-pointer"
              />
              {/* Data Recovery */}
              <input
                type="checkbox"
                checked={formData.services.includes('Data Recovery')}
                onChange={() => handleServiceToggle('Data Recovery')}
                className="absolute left-[28.5%] top-[51.3%] w-[4%] h-[2%] accent-blue-600 cursor-pointer"
              />

              {/* Printer Setup */}
              <input
                type="checkbox"
                checked={formData.services.includes('Printer Setup')}
                onChange={() => handleServiceToggle('Printer Setup')}
                className="absolute left-[6.2%] top-[53.8%] w-[4%] h-[2%] accent-blue-600 cursor-pointer"
              />
              {/* Network Setup */}
              <input
                type="checkbox"
                checked={formData.services.includes('Network Setup')}
                onChange={() => handleServiceToggle('Network Setup')}
                className="absolute left-[28.5%] top-[53.8%] w-[4%] h-[2%] accent-blue-600 cursor-pointer"
              />

              {/* Website Development */}
              <input
                type="checkbox"
                checked={formData.services.includes('Website Development')}
                onChange={() => handleServiceToggle('Website Development')}
                className="absolute left-[6.2%] top-[56.3%] w-[4%] h-[2%] accent-blue-600 cursor-pointer"
              />
              {/* Graphic Design */}
              <input
                type="checkbox"
                checked={formData.services.includes('Graphic Design')}
                onChange={() => handleServiceToggle('Graphic Design')}
                className="absolute left-[28.5%] top-[56.3%] w-[4%] h-[2%] accent-blue-600 cursor-pointer"
              />

              {/* Buy Computer/Laptop */}
              <input
                type="checkbox"
                checked={formData.services.includes('Buy Computer/Laptop')}
                onChange={() => handleServiceToggle('Buy Computer/Laptop')}
                className="absolute left-[6.2%] top-[58.8%] w-[4%] h-[2%] accent-blue-600 cursor-pointer"
              />
              {/* Other Service */}
              <input
                type="checkbox"
                checked={formData.services.includes('Other Service')}
                onChange={() => handleServiceToggle('Other Service')}
                className="absolute left-[28.5%] top-[58.8%] w-[4%] h-[2%] accent-blue-600 cursor-pointer"
              />

              {/* Other Specify Input */}
              <input
                type="text"
                value={formData.otherService}
                onChange={(e) => setFormData({...formData, otherService: e.target.value})}
                placeholder="Please type your requirement"
                className="absolute left-[6.2%] top-[62.8%] w-[39.5%] h-[2.8%] px-2 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 focus:border-blue-600 rounded outline-none font-medium text-[11px] sm:text-xs shadow-sm"
              />


              {/* SECTION 3: DESCRIBE YOUR PROBLEM */}
              <textarea
                value={formData.problem}
                onChange={(e) => setFormData({...formData, problem: e.target.value})}
                placeholder="Please describe your problem or requirement in detail..."
                className="absolute left-[51%] top-[42.2%] w-[43%] h-[7.8%] p-2 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 focus:border-blue-600 rounded-lg outline-none font-medium text-[11px] sm:text-xs resize-none shadow-sm"
                required
              />

              {/* Urgency Radios */}
              <div className="absolute left-[51%] top-[51.8%] w-[43%] h-[2.5%] flex items-center justify-between text-[10px] sm:text-xs font-bold text-slate-800 px-1">
                {['Low', 'Normal', 'High', 'Urgent'].map((urg) => (
                  <label key={urg} className="flex items-center gap-1 cursor-pointer">
                    <input
                      type="radio"
                      name="urgencyPoster"
                      value={urg}
                      checked={formData.urgency === urg}
                      onChange={(e) => setFormData({...formData, urgency: e.target.value})}
                      className="accent-blue-600"
                    />
                    <span>{urg}</span>
                  </label>
                ))}
              </div>


              {/* SECTION 4: DEVICE DETAILS */}
              {/* Device Type */}
              <select
                value={formData.deviceType}
                onChange={(e) => setFormData({...formData, deviceType: e.target.value})}
                className="absolute left-[51%] top-[57.5%] w-[20%] h-[2.5%] px-1 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 rounded outline-none font-medium text-[10px] sm:text-xs"
              >
                <option>Laptop</option>
                <option>Desktop PC</option>
                <option>MacBook / iMac</option>
                <option>Printer</option>
                <option>Mobile / Tablet</option>
                <option>Router / Switch</option>
              </select>

              {/* Brand */}
              <input
                type="text"
                value={formData.brand}
                onChange={(e) => setFormData({...formData, brand: e.target.value})}
                placeholder="Enter brand name"
                className="absolute left-[73%] top-[57.5%] w-[21%] h-[2.5%] px-2 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 rounded outline-none font-medium text-[10px] sm:text-xs"
              />

              {/* Model */}
              <input
                type="text"
                value={formData.model}
                onChange={(e) => setFormData({...formData, model: e.target.value})}
                placeholder="Enter model"
                className="absolute left-[51%] top-[62.8%] w-[20%] h-[2.5%] px-2 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 rounded outline-none font-medium text-[10px] sm:text-xs"
              />

              {/* OS */}
              <select
                value={formData.os}
                onChange={(e) => setFormData({...formData, os: e.target.value})}
                className="absolute left-[73%] top-[62.8%] w-[21%] h-[2.5%] px-1 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 rounded outline-none font-medium text-[10px] sm:text-xs"
              >
                <option>Windows 11</option>
                <option>Windows 10</option>
                <option>macOS</option>
                <option>Linux / Ubuntu</option>
                <option>Android / iOS</option>
              </select>

              {/* Serial Number */}
              <input
                type="text"
                value={formData.serial}
                onChange={(e) => setFormData({...formData, serial: e.target.value})}
                placeholder="Enter serial number (optional)"
                className="absolute left-[51%] top-[67.8%] w-[26%] h-[2.5%] px-2 bg-white/90 focus:bg-white text-slate-800 border border-blue-400 rounded outline-none font-mono text-[10px] sm:text-xs"
              />


              {/* SECTION 5: PREFERRED SUPPORT */}
              <div className="absolute left-[6%] top-[71.0%] w-[28%] h-[8%] flex flex-col justify-between text-[10px] sm:text-xs font-bold text-slate-800">
                {[
                  'Live Chat Support',
                  'Video Call Support',
                  'Remote Desktop Support',
                  'On-Site Visit (Home/Office)'
                ].map((sup) => (
                  <label key={sup} className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="supportPoster"
                      value={sup}
                      checked={formData.supportType === sup}
                      onChange={(e) => setFormData({...formData, supportType: e.target.value})}
                      className="accent-orange-500"
                    />
                    <span className="truncate">{sup}</span>
                  </label>
                ))}
              </div>


              {/* SECTION 6: UPLOAD FILES */}
              <div
                onClick={() => fileInputRef.current?.click()}
                className="absolute left-[36%] top-[70.5%] w-[26%] h-[8.5%] bg-teal-50/80 hover:bg-white border-2 border-dashed border-teal-500 rounded-xl flex flex-col items-center justify-center cursor-pointer p-1 text-center"
              >
                <p className="text-[10px] sm:text-xs font-extrabold text-slate-800 truncate w-full px-1">
                  {formData.uploadedFileName || 'Drag & Drop Files Here'}
                </p>
                <p className="text-[9px] text-teal-600 font-bold">or click to upload</p>
              </div>


              {/* SECTION 7: PREFERRED DATE & TIME */}
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({...formData, date: e.target.value})}
                className="absolute left-[68%] top-[72.0%] w-[25%] h-[2.5%] px-1 bg-white/90 focus:bg-white text-slate-800 border border-purple-400 rounded outline-none font-medium text-[10px] sm:text-xs"
              />
              <input
                type="time"
                value={formData.time}
                onChange={(e) => setFormData({...formData, time: e.target.value})}
                className="absolute left-[68%] top-[77.2%] w-[25%] h-[2.5%] px-1 bg-white/90 focus:bg-white text-slate-800 border border-purple-400 rounded outline-none font-medium text-[10px] sm:text-xs"
              />


              {/* SECTION 8: PAYMENT METHOD */}
              {/* eSewa */}
              <div className="absolute left-[7%] top-[82.5%] w-[42%] h-[2.5%] flex items-center gap-2">
                <label className="flex items-center gap-1 font-extrabold text-[11px] text-emerald-800 cursor-pointer">
                  <input
                    type="radio"
                    name="paymentPoster"
                    value="eSewa"
                    checked={formData.paymentMethod === 'eSewa'}
                    onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})}
                    className="accent-emerald-600"
                  />
                  <span>eSewa</span>
                </label>
                <input
                  type="text"
                  value={formData.paymentId}
                  onChange={(e) => setFormData({...formData, paymentId: e.target.value})}
                  placeholder="9812345678"
                  className="flex-1 px-2 h-full bg-white/90 border border-emerald-400 rounded text-[11px] font-mono outline-none"
                />
              </div>

              {/* Khalti */}
              <div className="absolute left-[7%] top-[85.8%] w-[42%] h-[2.5%] flex items-center gap-2">
                <label className="flex items-center gap-1 font-extrabold text-[11px] text-purple-800 cursor-pointer">
                  <input
                    type="radio"
                    name="paymentPoster"
                    value="Khalti"
                    checked={formData.paymentMethod === 'Khalti'}
                    onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})}
                    className="accent-purple-600"
                  />
                  <span>Khalti</span>
                </label>
                <input
                  type="text"
                  value={formData.paymentId}
                  onChange={(e) => setFormData({...formData, paymentId: e.target.value})}
                  placeholder="Enter Khalti ID"
                  className="flex-1 px-2 h-full bg-white/90 border border-purple-400 rounded text-[11px] font-mono outline-none"
                />
              </div>

              {/* Debit / Credit Card */}
              <label className="absolute left-[53%] top-[82.5%] font-bold text-[11px] text-slate-800 flex items-center gap-1 cursor-pointer">
                <input
                  type="radio"
                  name="paymentPoster"
                  value="Debit / Credit Card"
                  checked={formData.paymentMethod === 'Debit / Credit Card'}
                  onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})}
                  className="accent-blue-600"
                />
                <span>Debit / Credit Card</span>
              </label>

              {/* Cash on Service */}
              <label className="absolute left-[53%] top-[85.8%] font-bold text-[11px] text-slate-800 flex items-center gap-1 cursor-pointer">
                <input
                  type="radio"
                  name="paymentPoster"
                  value="Cash on Service"
                  checked={formData.paymentMethod === 'Cash on Service'}
                  onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})}
                  className="accent-amber-600"
                />
                <span>Cash on Service</span>
              </label>

              {/* Bank Transfer */}
              <label className="absolute left-[7%] top-[89.0%] font-bold text-[11px] text-slate-800 flex items-center gap-1 cursor-pointer">
                <input
                  type="radio"
                  name="paymentPoster"
                  value="Bank Transfer"
                  checked={formData.paymentMethod === 'Bank Transfer'}
                  onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})}
                  className="accent-blue-600"
                />
                <span>Bank Transfer</span>
              </label>


              {/* SECTION 9: TERMS & SUBMIT */}
              <label className="absolute left-[7%] top-[92.2%] w-[86%] flex items-center gap-2 cursor-pointer font-bold text-[10px] sm:text-xs text-slate-900 bg-white/80 p-1 rounded backdrop-blur-xs">
                <input
                  type="checkbox"
                  required
                  checked={formData.agree}
                  onChange={(e) => setFormData({...formData, agree: e.target.checked})}
                  className="w-4 h-4 accent-blue-600 cursor-pointer"
                />
                <span>I agree to the terms & conditions and authorize processing of my request.</span>
              </label>

              {/* SUBMIT BUTTON */}
              <button
                type="submit"
                className="absolute left-[29%] top-[95.2%] w-[42%] h-[3.2%] bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-600 hover:from-blue-600 hover:to-indigo-500 text-white font-black text-xs sm:text-sm rounded-xl shadow-xl transition transform active:scale-95 cursor-pointer flex items-center justify-center gap-2 border border-white/40"
              >
                <Send className="w-4 h-4" /> Submit Request
              </button>

            </form>
          </div>
        </div>
      ) : (

        /* MAIN EDITABLE FORM CONTAINER (EXACT POSTER DESIGN REPLICATED NATIVELY) */
        <div className="max-w-[1050px] mx-auto p-2 sm:p-6 space-y-5">
          
          <form onSubmit={handleSubmit} className="bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            
            {/* HERO BRAND HEADER */}
            <div className="bg-gradient-to-r from-blue-900 via-blue-700 to-sky-500 p-6 sm:p-8 text-white relative overflow-hidden">
              {/* Top Bar */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
                
                {/* Logo & Slogan */}
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 bg-white rounded-2xl p-2 shadow-lg flex items-center justify-center border-2 border-orange-500">
                    <div className="text-center leading-none">
                      <span className="text-xl font-black text-blue-900 tracking-tighter">RST</span>
                      <div className="text-[7px] font-bold text-orange-500">DIGITAL</div>
                    </div>
                  </div>
                  <div>
                    <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2">
                      RST <span className="text-orange-400">DIGITAL</span> SOLUTIONS
                    </h2>
                    <p className="text-blue-100 text-xs sm:text-sm font-semibold">
                      We Provide All Online & Technical Services
                    </p>
                  </div>
                </div>

                {/* Service Tag */}
                <div className="bg-blue-600/90 border border-blue-400/50 px-4 py-2 rounded-full text-xs font-bold flex items-center gap-2 shadow-lg">
                  <Headphones className="w-4 h-4 text-orange-400" />
                  <span>Customer Service Request Form</span>
                </div>
              </div>

              {/* Top 5 Service Badges */}
              <div className="grid grid-cols-5 gap-2 pt-2 border-t border-blue-400/30">
                {[
                  { title: 'AI Services', icon: Sparkles, color: 'bg-purple-500' },
                  { title: 'Computer Repair', icon: Monitor, color: 'bg-sky-500' },
                  { title: 'Software Install', icon: Settings, color: 'bg-emerald-500' },
                  { title: 'Buy & Sell', icon: ShoppingBag, color: 'bg-orange-500' },
                  { title: 'Technical Support', icon: Headphones, color: 'bg-indigo-500' }
                ].map((item, i) => {
                  const Icon = item.icon;
                  return (
                    <div key={i} className="flex flex-col items-center text-center space-y-1">
                      <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-xl ${item.color} text-white flex items-center justify-center shadow-md`}>
                        <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
                      </div>
                      <span className="text-[9px] sm:text-[11px] font-bold leading-tight text-blue-50">{item.title}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* FORM BODY CONTAINING ALL 9 SECTIONS */}
            <div className="p-4 sm:p-8 space-y-6 bg-slate-50/50">

              {/* -------------------------------------------------------------------------- */}
              {/* SECTION 1: CUSTOMER INFORMATION */}
              {/* -------------------------------------------------------------------------- */}
              <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
                <div className="bg-blue-600 text-white px-4 py-2 rounded-xl font-extrabold text-sm sm:text-base flex items-center gap-2 shadow-sm">
                  <span className="w-6 h-6 rounded-full bg-white text-blue-600 text-xs flex items-center justify-center font-black">1</span>
                  <span>Customer Information</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  
                  {/* Left Column */}
                  <div className="space-y-3.5">
                    
                    {/* Full Name */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Full Name <span className="text-rose-500">*</span>
                      </label>
                      <div className="relative">
                        <User className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                        <input
                          type="text"
                          required
                          value={formData.fullName}
                          onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                          placeholder="Enter your full name"
                          className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100 outline-none transition bg-white"
                        />
                      </div>
                    </div>

                    {/* Mobile Number */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Mobile Number <span className="text-rose-500">*</span>
                      </label>
                      <div className="flex gap-2">
                        <select
                          value={formData.mobileCode}
                          onChange={(e) => setFormData({...formData, mobileCode: e.target.value})}
                          className="w-24 px-2 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 bg-slate-50 font-bold outline-none"
                        >
                          <option>+977 (NP)</option>
                          <option>+91 (IN)</option>
                          <option>+1 (US)</option>
                          <option>+971 (UAE)</option>
                        </select>
                        <div className="relative flex-1">
                          <Phone className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                          <input
                            type="tel"
                            required
                            value={formData.mobile}
                            onChange={(e) => setFormData({...formData, mobile: e.target.value})}
                            placeholder="9812345678"
                            className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100 outline-none transition bg-white"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Email Address */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Email Address <span className="text-rose-500">*</span>
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                        <input
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({...formData, email: e.target.value})}
                          placeholder="example@gmail.com"
                          className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100 outline-none transition bg-white"
                        />
                      </div>
                    </div>

                    {/* Address */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Address</label>
                      <div className="relative">
                        <MapPin className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                        <input
                          type="text"
                          value={formData.address}
                          onChange={(e) => setFormData({...formData, address: e.target.value})}
                          placeholder="Enter your full address"
                          className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100 outline-none transition bg-white"
                        />
                      </div>
                    </div>

                  </div>

                  {/* Right Column */}
                  <div className="space-y-3.5">
                    
                    {/* Country */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Country <span className="text-rose-500">*</span>
                      </label>
                      <select
                        value={formData.country}
                        onChange={(e) => setFormData({...formData, country: e.target.value})}
                        className="w-full px-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 bg-white focus:border-blue-600 outline-none cursor-pointer"
                      >
                        <option>Nepal</option>
                        <option>India</option>
                        <option>United States</option>
                        <option>United Arab Emirates</option>
                        <option>Australia</option>
                        <option>United Kingdom</option>
                      </select>
                    </div>

                    {/* State / Province */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">State / Province</label>
                      <select
                        value={formData.state}
                        onChange={(e) => setFormData({...formData, state: e.target.value})}
                        className="w-full px-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 bg-white focus:border-blue-600 outline-none cursor-pointer"
                      >
                        <option>Bagmati Province</option>
                        <option>Koshi Province</option>
                        <option>Madhesh Province</option>
                        <option>Gandaki Province</option>
                        <option>Lumbini Province</option>
                        <option>Karnali Province</option>
                        <option>Sudurpashchim Province</option>
                      </select>
                    </div>

                    {/* City */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        City <span className="text-rose-500">*</span>
                      </label>
                      <select
                        value={formData.city}
                        onChange={(e) => setFormData({...formData, city: e.target.value})}
                        className="w-full px-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 bg-white focus:border-blue-600 outline-none cursor-pointer"
                      >
                        <option>Kathmandu</option>
                        <option>Lalitpur</option>
                        <option>Bhaktapur</option>
                        <option>Pokhara</option>
                        <option>Chitwan</option>
                        <option>Butwal</option>
                        <option>Biratnagar</option>
                        <option>Dharan</option>
                      </select>
                    </div>

                    {/* Preferred Contact Method */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Preferred Contact Method</label>
                      <div className="flex items-center gap-4 py-2 px-3 bg-slate-50 rounded-xl border border-slate-200">
                        {['WhatsApp', 'Phone Call', 'Email'].map((method) => (
                          <label key={method} className="flex items-center gap-1.5 text-xs font-bold text-slate-700 cursor-pointer">
                            <input
                              type="radio"
                              name="contactMethod"
                              value={method}
                              checked={formData.contactMethod === method}
                              onChange={(e) => setFormData({...formData, contactMethod: e.target.value})}
                              className="text-blue-600 focus:ring-blue-500"
                            />
                            <span>{method}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                  </div>

                </div>
              </div>


              {/* -------------------------------------------------------------------------- */}
              {/* SECTION 2 & 3: SERVICE SELECTION & PROBLEM DESCRIPTION */}
              {/* -------------------------------------------------------------------------- */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* SECTION 2: SELECT SERVICE YOU NEED */}
                <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4 flex flex-col justify-between">
                  <div>
                    <div className="bg-indigo-600 text-white px-4 py-2 rounded-xl font-extrabold text-sm sm:text-base flex items-center gap-2 shadow-sm mb-3">
                      <span className="w-6 h-6 rounded-full bg-white text-indigo-600 text-xs flex items-center justify-center font-black">2</span>
                      <span>Select Service You Need</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      {availableServices.map((item) => {
                        const Icon = item.icon;
                        const isSelected = formData.services.includes(item.name);
                        return (
                          <button
                            key={item.name}
                            type="button"
                            onClick={() => handleServiceToggle(item.name)}
                            className={`flex items-center gap-2 p-2.5 rounded-xl border text-left transition cursor-pointer ${
                              isSelected
                                ? 'bg-blue-50 border-blue-600 text-blue-900 font-bold shadow-sm ring-1 ring-blue-500'
                                : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300 hover:bg-slate-50'
                            }`}
                          >
                            <input 
                              type="checkbox" 
                              checked={isSelected}
                              readOnly 
                              className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500 pointer-events-none"
                            />
                            <div className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs ${isSelected ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-500'}`}>
                              <Icon className="w-3.5 h-3.5" />
                            </div>
                            <span className="text-xs truncate">{item.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Other Specify */}
                  <div className="pt-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">Other (Please Specify)</label>
                    <input
                      type="text"
                      value={formData.otherService}
                      onChange={(e) => setFormData({...formData, otherService: e.target.value})}
                      placeholder="Please type your requirement..."
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:border-blue-600 outline-none"
                    />
                  </div>
                </div>

                {/* SECTION 3: DESCRIBE YOUR PROBLEM / REQUIREMENT */}
                <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4 flex flex-col justify-between">
                  <div>
                    <div className="bg-emerald-600 text-white px-4 py-2 rounded-xl font-extrabold text-sm sm:text-base flex items-center gap-2 shadow-sm mb-3">
                      <span className="w-6 h-6 rounded-full bg-white text-emerald-600 text-xs flex items-center justify-center font-black">3</span>
                      <span>Describe Your Problem / Requirement</span>
                    </div>

                    <textarea
                      rows={7}
                      value={formData.problem}
                      onChange={(e) => setFormData({...formData, problem: e.target.value})}
                      placeholder="Please describe your problem or requirement in detail..."
                      className="w-full p-3 text-xs sm:text-sm rounded-xl border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100 outline-none transition bg-white resize-none"
                      required
                    />
                  </div>

                  {/* Urgency Selection */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-2">How urgent is your request?</label>
                    <div className="grid grid-cols-4 gap-2">
                      {[
                        { label: 'Low', color: 'text-emerald-600 bg-emerald-50 border-emerald-200' },
                        { label: 'Normal', color: 'text-blue-600 bg-blue-50 border-blue-200' },
                        { label: 'High', color: 'text-orange-600 bg-orange-50 border-orange-200' },
                        { label: 'Urgent', color: 'text-rose-600 bg-rose-50 border-rose-200' }
                      ].map((urg) => (
                        <label 
                          key={urg.label} 
                          className={`flex items-center justify-center gap-1.5 p-2 rounded-xl border cursor-pointer font-bold text-xs transition ${
                            formData.urgency === urg.label ? `${urg.color} ring-2 ring-current` : 'bg-slate-50 border-slate-200 text-slate-600'
                          }`}
                        >
                          <input
                            type="radio"
                            name="urgency"
                            value={urg.label}
                            checked={formData.urgency === urg.label}
                            onChange={(e) => setFormData({...formData, urgency: e.target.value})}
                            className="sr-only"
                          />
                          <span>{urg.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>

              </div>


              {/* -------------------------------------------------------------------------- */}
              {/* SECTION 4: DEVICE DETAILS */}
              {/* -------------------------------------------------------------------------- */}
              <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
                <div className="bg-sky-600 text-white px-4 py-2 rounded-xl font-extrabold text-sm sm:text-base flex items-center gap-2 shadow-sm">
                  <span className="w-6 h-6 rounded-full bg-white text-sky-600 text-xs flex items-center justify-center font-black">4</span>
                  <span>Device Details (If Applicable)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  
                  {/* Device Type */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Device Type</label>
                    <select
                      value={formData.deviceType}
                      onChange={(e) => setFormData({...formData, deviceType: e.target.value})}
                      className="w-full px-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 bg-white focus:border-blue-600 outline-none cursor-pointer font-medium"
                    >
                      <option>Select Device Type</option>
                      <option>Laptop</option>
                      <option>Desktop PC</option>
                      <option>MacBook / iMac</option>
                      <option>Printer</option>
                      <option>Mobile / Tablet</option>
                      <option>Network Router / Switch</option>
                    </select>
                  </div>

                  {/* Brand */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Brand</label>
                    <input
                      type="text"
                      value={formData.brand}
                      onChange={(e) => setFormData({...formData, brand: e.target.value})}
                      placeholder="Enter brand name (e.g. Dell, HP, Apple)"
                      className="w-full px-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 bg-white focus:border-blue-600 outline-none"
                    />
                  </div>

                  {/* Model */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Model</label>
                    <input
                      type="text"
                      value={formData.model}
                      onChange={(e) => setFormData({...formData, model: e.target.value})}
                      placeholder="Enter model number"
                      className="w-full px-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 bg-white focus:border-blue-600 outline-none"
                    />
                  </div>

                  {/* Operating System */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Operating System</label>
                    <select
                      value={formData.os}
                      onChange={(e) => setFormData({...formData, os: e.target.value})}
                      className="w-full px-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 bg-white focus:border-blue-600 outline-none cursor-pointer"
                    >
                      <option>Select OS</option>
                      <option>Windows 11</option>
                      <option>Windows 10</option>
                      <option>macOS</option>
                      <option>Linux / Ubuntu</option>
                      <option>Android / iOS</option>
                    </select>
                  </div>

                  {/* Serial Number */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">Serial Number (If any)</label>
                    <input
                      type="text"
                      value={formData.serial}
                      onChange={(e) => setFormData({...formData, serial: e.target.value})}
                      placeholder="Enter serial number (optional)"
                      className="w-full px-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 bg-white focus:border-blue-600 outline-none font-mono"
                    />
                  </div>

                </div>
              </div>


              {/* -------------------------------------------------------------------------- */}
              {/* SECTIONS 5, 6, 7: SUPPORT, FILE UPLOAD, DATE & TIME */}
              {/* -------------------------------------------------------------------------- */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* SECTION 5: PREFERRED SUPPORT */}
                <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3">
                  <div className="bg-orange-500 text-white px-3 py-1.5 rounded-xl font-extrabold text-xs sm:text-sm flex items-center gap-1.5 shadow-sm">
                    <span className="w-5 h-5 rounded-full bg-white text-orange-500 text-[10px] flex items-center justify-center font-black">5</span>
                    <span>Preferred Support</span>
                  </div>

                  <div className="space-y-2 pt-1">
                    {[
                      'Live Chat Support',
                      'Video Call Support',
                      'Remote Desktop Support',
                      'On-Site Visit (Home/Office)'
                    ].map((sup) => (
                      <label 
                        key={sup}
                        className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-bold cursor-pointer transition ${
                          formData.supportType === sup ? 'bg-orange-50 border-orange-500 text-orange-900 shadow-sm' : 'bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        <input
                          type="radio"
                          name="supportType"
                          value={sup}
                          checked={formData.supportType === sup}
                          onChange={(e) => setFormData({...formData, supportType: e.target.value})}
                          className="text-orange-500 focus:ring-orange-400"
                        />
                        <span>{sup}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* SECTION 6: UPLOAD FILES */}
                <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3 flex flex-col justify-between">
                  <div className="bg-teal-600 text-white px-3 py-1.5 rounded-xl font-extrabold text-xs sm:text-sm flex items-center gap-1.5 shadow-sm">
                    <span className="w-5 h-5 rounded-full bg-white text-teal-600 text-[10px] flex items-center justify-center font-black">6</span>
                    <span>Upload Files (If any)</span>
                  </div>

                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-teal-400 bg-teal-50/50 hover:bg-teal-50 rounded-2xl p-4 flex flex-col items-center justify-center text-center cursor-pointer transition py-6"
                  >
                    <input 
                      ref={fileInputRef} 
                      type="file" 
                      className="hidden" 
                      onChange={handleFileUpload}
                    />
                    <div className="w-10 h-10 rounded-full bg-teal-600 text-white flex items-center justify-center mb-2 shadow-md">
                      <UploadCloud className="w-5 h-5" />
                    </div>
                    <p className="text-xs font-extrabold text-slate-800">
                      {formData.uploadedFileName || 'Drag & Drop Files Here'}
                    </p>
                    <p className="text-[10px] text-teal-600 font-bold mt-0.5">or click to upload</p>
                    <p className="text-[9px] text-slate-400 mt-2">Supported: PDF, JPG, PNG, DOC (Max 10MB)</p>
                  </div>
                </div>

                {/* SECTION 7: PREFERRED DATE & TIME */}
                <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3">
                  <div className="bg-purple-600 text-white px-3 py-1.5 rounded-xl font-extrabold text-xs sm:text-sm flex items-center gap-1.5 shadow-sm">
                    <span className="w-5 h-5 rounded-full bg-white text-purple-600 text-[10px] flex items-center justify-center font-black">7</span>
                    <span>Preferred Date & Time</span>
                  </div>

                  <div className="space-y-3 pt-1">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">Preferred Date</label>
                      <input
                        type="date"
                        value={formData.date}
                        onChange={(e) => setFormData({...formData, date: e.target.value})}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:border-purple-600 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">Preferred Time</label>
                      <input
                        type="time"
                        value={formData.time}
                        onChange={(e) => setFormData({...formData, time: e.target.value})}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:border-purple-600 outline-none"
                      />
                    </div>
                    <div className="p-2 bg-purple-50 rounded-xl text-center text-[10px] font-bold text-purple-700 flex items-center justify-center gap-1">
                      <Check className="w-3.5 h-3.5" /> We will contact you soon!
                    </div>
                  </div>
                </div>

              </div>


              {/* -------------------------------------------------------------------------- */}
              {/* SECTION 8: PAYMENT METHOD */}
              {/* -------------------------------------------------------------------------- */}
              <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
                <div className="bg-blue-700 text-white px-4 py-2 rounded-xl font-extrabold text-sm sm:text-base flex items-center gap-2 shadow-sm">
                  <span className="w-6 h-6 rounded-full bg-white text-blue-700 text-xs flex items-center justify-center font-black">8</span>
                  <span>Payment Method (If Applicable)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
                  
                  {/* eSewa */}
                  <label className={`p-3 rounded-2xl border cursor-pointer transition flex flex-col justify-between space-y-2 ${formData.paymentMethod === 'eSewa' ? 'bg-emerald-50 border-emerald-500 ring-2 ring-emerald-500' : 'bg-slate-50 border-slate-200'}`}>
                    <div className="flex items-center gap-2">
                      <input 
                        type="radio" 
                        name="paymentMethod" 
                        value="eSewa" 
                        checked={formData.paymentMethod === 'eSewa'} 
                        onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})} 
                      />
                      <span className="font-extrabold text-xs text-emerald-700">eSewa</span>
                    </div>
                    <input
                      type="text"
                      placeholder="eSewa ID (9812345678)"
                      value={formData.paymentId}
                      onChange={(e) => setFormData({...formData, paymentId: e.target.value})}
                      className="w-full px-2 py-1 text-[11px] rounded-lg border border-emerald-300 bg-white outline-none"
                    />
                  </label>

                  {/* Khalti */}
                  <label className={`p-3 rounded-2xl border cursor-pointer transition flex flex-col justify-between space-y-2 ${formData.paymentMethod === 'Khalti' ? 'bg-purple-50 border-purple-500 ring-2 ring-purple-500' : 'bg-slate-50 border-slate-200'}`}>
                    <div className="flex items-center gap-2">
                      <input 
                        type="radio" 
                        name="paymentMethod" 
                        value="Khalti" 
                        checked={formData.paymentMethod === 'Khalti'} 
                        onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})} 
                      />
                      <span className="font-extrabold text-xs text-purple-700">Khalti</span>
                    </div>
                    <input
                      type="text"
                      placeholder="Khalti ID"
                      value={formData.paymentId}
                      onChange={(e) => setFormData({...formData, paymentId: e.target.value})}
                      className="w-full px-2 py-1 text-[11px] rounded-lg border border-purple-300 bg-white outline-none"
                    />
                  </label>

                  {/* Bank Transfer */}
                  <label className={`p-3 rounded-2xl border cursor-pointer transition flex items-center gap-2 ${formData.paymentMethod === 'Bank Transfer' ? 'bg-blue-50 border-blue-500 ring-2 ring-blue-500' : 'bg-slate-50 border-slate-200'}`}>
                    <input 
                      type="radio" 
                      name="paymentMethod" 
                      value="Bank Transfer" 
                      checked={formData.paymentMethod === 'Bank Transfer'} 
                      onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})} 
                    />
                    <span className="font-bold text-xs text-slate-800">Bank Transfer</span>
                  </label>

                  {/* Cash on Service */}
                  <label className={`p-3 rounded-2xl border cursor-pointer transition flex items-center gap-2 ${formData.paymentMethod === 'Cash on Service' ? 'bg-amber-50 border-amber-500 ring-2 ring-amber-500' : 'bg-slate-50 border-slate-200'}`}>
                    <input 
                      type="radio" 
                      name="paymentMethod" 
                      value="Cash on Service" 
                      checked={formData.paymentMethod === 'Cash on Service'} 
                      onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})} 
                    />
                    <span className="font-bold text-xs text-slate-800">Cash on Service</span>
                  </label>

                </div>
              </div>


              {/* -------------------------------------------------------------------------- */}
              {/* SECTION 9: TERMS & SUBMIT */}
              {/* -------------------------------------------------------------------------- */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4 text-center">
                
                <label className="inline-flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <input
                    type="checkbox"
                    required
                    checked={formData.agree}
                    onChange={(e) => setFormData({...formData, agree: e.target.checked})}
                    className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                  />
                  <span>I agree to the terms & conditions and authorize processing of my request.</span>
                </label>

                <div>
                  <button
                    type="submit"
                    className="w-full sm:w-auto px-12 py-4 bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-600 hover:from-blue-600 hover:to-indigo-500 text-white font-black text-base rounded-2xl shadow-xl transition transform active:scale-95 cursor-pointer inline-flex items-center justify-center gap-2 border border-white/30"
                  >
                    <Send className="w-5 h-5" /> Submit Request
                  </button>
                </div>

                <div className="flex items-center justify-center gap-1.5 text-xs text-emerald-600 font-bold">
                  <Shield className="w-4 h-4" />
                  <span>Your information is safe and 100% secure.</span>
                </div>

              </div>

            </div>

          </form>

        </div>
      )}

    </div>
  );
};
