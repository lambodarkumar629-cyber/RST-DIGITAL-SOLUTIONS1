export interface ServiceCategory {
  id: string;
  title: string;
  iconName: string;
  description: string;
  badge?: string;
  bgGradient: string;
  iconBg: string;
  externalUrl?: string;
  subCategories: SubCategory[];
}

export interface SubCategory {
  id: string;
  name: string;
  description: string;
  estimatedPrice: number;
  deliveryTime: string;
  externalUrl?: string;
  fields: CustomFormField[];
}

export interface CustomFormField {
  id: string;
  label: string;
  type: 'text' | 'textarea' | 'select' | 'radio' | 'file' | 'date' | 'number';
  placeholder?: string;
  options?: string[];
  required?: boolean;
  defaultValue?: string;
}

export interface ServiceOrder {
  id: string;
  categoryId: string;
  categoryName: string;
  subCategoryName: string;
  customerName: string;
  email: string;
  phone: string;
  address?: string;
  urgency: 'Standard' | 'Express (24h)' | 'Same Day Urgent';
  formData: Record<string, string>;
  additionalNotes?: string;
  estimatedPrice: number;
  status: 'Received' | 'In Progress' | 'Action Required' | 'Completed';
  createdAt: string;
}

export interface CartItem {
  id: string;
  type: 'service' | 'product';
  title: string;
  category: string;
  price: number;
  quantity: number;
  details?: Record<string, string>;
}

export interface AiTool {
  id: string;
  title: string;
  iconName: string;
  category: string;
  description: string;
  badge?: string;
  samplePrompt: string;
}

export interface TechProduct {
  id: string;
  name: string;
  category: string;
  price: number;
  rating: number;
  specs: string[];
  imageUrl: string;
  stock: number;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  joinedDate: string;
  totalOrders: number;
  totalSpent: number;
}

export interface Employee {
  id: string;
  name: string;
  role: string;
  email: string;
  phone: string;
  attendance: 'Present' | 'Absent' | 'On Leave';
  salary: number;
  performance: number; // 0 to 100
}

export interface SupportTicket {
  id: string;
  customerId: string;
  customerName: string;
  type: 'Video Call' | 'Remote Support' | 'Repair' | 'Software' | 'Complaint';
  subject: string;
  status: 'Open' | 'In Progress' | 'Resolved';
  priority: 'Low' | 'Medium' | 'High';
  createdAt: string;
}

export interface PaymentRecord {
  id: string;
  orderId: string;
  customerName: string;
  amount: number;
  method: 'Online' | 'Cash';
  status: 'Paid' | 'Pending' | 'Refunded';
  date: string;
}

export interface Booking {
  id: string;
  customerName: string;
  type: 'Home Service' | 'Office Visit' | 'Online Appointment';
  date: string;
  time: string;
  status: 'Confirmed' | 'Pending' | 'Cancelled';
}

export interface LoginDetails {
  dateTime: string;
  loginMethod: string;
  device: string;
  location: string;
  userEmail?: string;
}
