import React, { useState, useEffect } from 'react';
import { HomeScreen } from './components/HomeScreen';
import { OrdersScreen } from './components/OrdersScreen';
import { CartScreen } from './components/CartScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { CustomerRequestForm } from './components/CustomerRequestForm';
import { BottomNav } from './components/BottomNav';
import { ServiceFormModal } from './components/ServiceFormModal';
import { NoticeModal } from './components/NoticeModal';
import { AIChatSection } from './components/AIChatSection';
import { LoginModal } from './components/LoginModal';
import { AdminPanel } from './components/AdminPanel';
import { X, ShoppingBag } from 'lucide-react';
import { ServiceCategory, AiTool, TechProduct, CartItem, ServiceOrder, LoginDetails } from './types';
import { useAuth } from './contexts/AuthContext';
import { auth } from './lib/firebase';
import { isSignInWithEmailLink, signInWithEmailLink } from 'firebase/auth';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from './lib/firebase';

const App: React.FC = () => {
  const { user, loading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState('home');
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<ServiceCategory | null>(null);
  const [noticeForCategory, setNoticeForCategory] = useState<ServiceCategory | null>(null);
  const [requestPreSelectedData, setRequestPreSelectedData] = useState<any>(null);
  const [selectedAiTool, setSelectedAiTool] = useState<AiTool | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<TechProduct | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<ServiceOrder[]>([]);
  
  useEffect(() => {
    if (user && user.email === 'kaparrst@gmail.com' && activeTab !== 'admin') {
      setActiveTab('admin');
    }
  }, [user]);

  const [loginNotification, setLoginNotification] = useState<LoginDetails | null>(null);

  const triggerLoginNotification = (methodName?: string, explicitEmail?: string) => {
    const method = methodName || localStorage.getItem('last_login_method') || 'Google / Phone Account';
    const now = new Date();
    const formattedDateTime = now.toLocaleDateString('en-US', { 
      month: 'long', 
      day: 'numeric', 
      year: 'numeric' 
    }) + ' at ' + now.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit', 
      hour12: true 
    });

    const isMobile = typeof navigator !== 'undefined' && /Mobi|Android|iPhone/i.test(navigator.userAgent);
    const userDevice = isMobile ? 'Mobile Device (Web App)' : 'Desktop Web Browser';
    const userLoc = localStorage.getItem('user_location') || 'Kathmandu, Nepal (Approximate)';
    const userEmailStr = explicitEmail || auth.currentUser?.email || user?.email || localStorage.getItem('user_email');

    const details: LoginDetails = {
      dateTime: formattedDateTime,
      loginMethod: method,
      device: userDevice,
      location: userLoc,
      userEmail: userEmailStr || undefined
    };

    // Send email directly to customer via backend API (no UI modal shown to customer)
    if (userEmailStr) {
      console.log('Dispatching login notification to:', userEmailStr);
      fetch('/api/send-login-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(details)
      })
      .then(res => res.json())
      .then(data => console.log('Email dispatch response:', data))
      .catch(err => console.warn('Email dispatch warning:', err));
    } else {
       console.warn('Skipping email dispatch because userEmailStr is undefined.');
    }

    try {
      const existingNotifs = JSON.parse(localStorage.getItem('user_notifications_history') || '[]');
      const newNotif = {
        id: Date.now().toString(),
        title: 'Successful Account Login',
        message: `Security email sent to ${userEmailStr}. Login method: ${method}.`,
        time: formattedDateTime,
        read: false,
        details
      };
      localStorage.setItem('user_notifications_history', JSON.stringify([newNotif, ...existingNotifs]));
    } catch {
      // Ignore local storage error
    }
  };

  // Handle Email Link Sign-in
  useEffect(() => {
    if (isSignInWithEmailLink(auth, window.location.href)) {
      let email = window.localStorage.getItem('emailForSignIn');
      if (!email) {
        email = window.prompt('Please provide your email for confirmation');
      }
      if (email) {
        signInWithEmailLink(auth, email, window.location.href)
          .then(() => {
            window.localStorage.removeItem('emailForSignIn');
            triggerLoginNotification('Email Link', email);
          })
          .catch((error) => {
            console.error('Error signing in with email link', error);
          });
      }
    }
  }, []);

  // Load orders from localStorage
  useEffect(() => {
    const savedOrders = localStorage.getItem('service_orders');
    if (savedOrders) {
      setOrders(JSON.parse(savedOrders));
    }
  }, []);

  const handleAddToCart = (item: CartItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, item];
    });
    setActiveTab('cart');
  };

  const handlePlaceOrder = async (order: ServiceOrder) => {
    if (!user) {
      setIsLoginModalOpen(true);
      return;
    }

    try {
      // Save to Firestore
      await addDoc(collection(db, 'orders'), {
        userId: user.uid,
        type: 'service',
        data: order,
        status: 'Received',
        createdAt: serverTimestamp()
      }).catch(err => console.warn('Firestore offline save warning:', err));
    } catch (error) {
      console.warn('Firestore error, falling back to local storage:', error);
    }

    const updatedOrders = [order, ...orders];
    setOrders(updatedOrders);
    localStorage.setItem('service_orders', JSON.stringify(updatedOrders));
    setActiveTab('orders');
  };

  const handleProductOrder = async (product: TechProduct) => {
    if (!user) {
      setIsLoginModalOpen(true);
      return;
    }

    try {
      const orderData = {
        productId: product.id,
        productName: product.name,
        price: product.price,
        imageUrl: product.imageUrl,
        category: product.category,
        quantity: 1,
        customerName: user.displayName || user.email,
        email: user.email
      };

      await addDoc(collection(db, 'orders'), {
        userId: user.uid,
        type: 'product',
        data: orderData,
        status: 'Received',
        createdAt: serverTimestamp()
      }).catch(err => console.warn("Firestore offline:", err));

      // Also add to local orders for immediate feedback
      const localOrder: ServiceOrder = {
        id: Math.random().toString(36).substr(2, 9),
        categoryId: 'product',
        categoryName: 'Tech Product',
        subCategoryName: product.name,
        customerName: user.displayName || user.email || 'Anonymous',
        email: user.email || '',
        phone: '',
        address: '',
        urgency: 'Standard',
        formData: { 
          productId: product.id,
          category: product.category,
          price: product.price.toString()
        },
        estimatedPrice: product.price,
        status: 'Received',
        createdAt: new Date().toLocaleString()
      };

      setOrders([localOrder, ...orders]);
      setSelectedProduct(null);
      setActiveTab('orders');
    } catch (error) {
      console.error('Error ordering product:', error);
    }
  };

  const handlePreServiceSelection = (serviceData: any) => {
    setRequestPreSelectedData(serviceData);
    setSelectedCategory(null);
    setActiveTab('request');
  };

  const renderView = () => {
    switch (activeTab) {
      case 'home':

        return (
          <HomeScreen 
            onOpenCategoryForm={setNoticeForCategory}
            onOpenAiTool={setSelectedAiTool}
            onOpenProduct={setSelectedProduct}
            onNavigateTab={setActiveTab}
            cartCount={cart.length}
            ordersCount={orders.length}
          />
        );
      case 'orders':
        return <OrdersScreen orders={orders} onBackToHome={() => setActiveTab('home')} onDeleteOrder={(id) => setOrders(orders.filter(o => o.id !== id))} />;
      case 'request':

        return (
          <CustomerRequestForm 
            preSelectedData={requestPreSelectedData}
            onClearPreSelected={() => setRequestPreSelectedData(null)}
            onSubmitOrder={handlePlaceOrder} 
            onSubmitSuccess={() => setActiveTab('orders')} 
            onBack={() => setActiveTab('home')} 
          />
        );
      case 'cart':

        return (
          <CartScreen 
            cartItems={cart} 
            onRemoveItem={(id) => setCart(cart.filter(i => i.id !== id))} 
            onUpdateQuantity={(id, delta) => {
              setCart(prev => prev.map(i => i.id === id ? { ...i, quantity: Math.max(1, i.quantity + delta) } : i));
            }}
            onClearCart={() => setCart([])}
          />
        );
      case 'profile':
        return <ProfileScreen onOpenLogin={() => setIsLoginModalOpen(true)} />;
      default:
        return <HomeScreen 
          onOpenCategoryForm={setNoticeForCategory} 
          onOpenAiTool={setSelectedAiTool}
          onOpenProduct={setSelectedProduct}
          onNavigateTab={setActiveTab}
          cartCount={cart.length}
          ordersCount={orders.length}
        />;
    }
  };


  if (activeTab === 'admin') {
    return <AdminPanel onLogout={() => { auth.signOut(); setActiveTab('home'); }} />;
  }
  return (
    <div className="h-screen flex flex-col bg-[#F2F4F8] overflow-hidden">
      {/* Main Viewport */}
      <div className="flex-1 overflow-y-auto">
        {renderView()}
      </div>

      {/* Modals */}
      {isLoginModalOpen && (
        <LoginModal 
          onClose={() => setIsLoginModalOpen(false)} 
          onLoginSuccess={(method, email) => triggerLoginNotification(method, email)}
        />
      )}

      {/* Notice Modal */}
      {noticeForCategory && (
        <NoticeModal 
          onClose={() => setNoticeForCategory(null)}
          onConfirm={() => {
            setSelectedCategory(noticeForCategory);
            setNoticeForCategory(null);
          }}
        />
      )}

      {selectedCategory && (
        <ServiceFormModal 
          category={selectedCategory} 
          onClose={() => setSelectedCategory(null)}
          onSubmitOrder={handlePreServiceSelection}
        />
      )}

      {selectedAiTool && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-3xl p-6 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-black text-slate-900">{selectedAiTool.title}</h3>
              <button onClick={() => setSelectedAiTool(null)} className="p-2 hover:bg-slate-100 rounded-xl transition">
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>
            <AIChatSection />
          </div>
        </div>
      )}

      {selectedProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-[40px] p-8 shadow-2xl animate-in slide-in-from-bottom-10 duration-300">
            <div className="flex justify-center -mt-16 mb-4">
              <div className="w-48 h-48 bg-slate-100 rounded-3xl overflow-hidden border-4 border-white shadow-xl">
                <img src={selectedProduct.imageUrl} alt={selectedProduct.name} className="w-full h-full object-cover" />
              </div>
            </div>
            <div className="text-center space-y-2">
              <span className="px-3 py-1 bg-blue-100 text-blue-600 rounded-full text-[10px] font-black uppercase tracking-widest">{selectedProduct.category}</span>
              <h3 className="text-xl font-black text-slate-900 tracking-tight">{selectedProduct.name}</h3>
              <div className="flex items-center justify-center gap-1 text-amber-500 font-bold text-xs">
                ★ {selectedProduct.rating} <span className="text-slate-400 font-medium">(2.4k reviews)</span>
              </div>
              <p className="text-2xl font-black text-blue-600 mt-2">&#x20B9;{selectedProduct.price.toLocaleString()}</p>
            </div>
            
            <div className="mt-6 space-y-2">
              {(Array.isArray(selectedProduct.specs) 
                ? selectedProduct.specs 
                : typeof selectedProduct.specs === 'string' 
                  ? (selectedProduct.specs as string).split(',').map((s: string) => s.trim()) 
                  : ['High Quality Product']
              ).map((spec, i) => (
                <div key={i} className="flex items-center gap-2 text-xs font-bold text-slate-600 bg-slate-50 p-2.5 rounded-xl">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                  {spec}
                </div>
              ))}
            </div>

            <div className="mt-8 flex gap-3">
              <button 
                onClick={() => setSelectedProduct(null)}
                className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition"
              >
                Close
              </button>
              <button 
                onClick={() => handleProductOrder(selectedProduct)}
                className="flex-[2] py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-700 transition shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2"
              >
                <ShoppingBag className="w-4 h-4" />
                Order Now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Nav */}
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} cartCount={cart.length} />
    </div>
  );
};

export default App;
