import { ServiceCategory, AiTool, TechProduct } from '../types';

export const categories: ServiceCategory[] = [
  {
    id: 'google_mobile_video_service',
    title: 'AI Video Creator',
    iconName: 'Video',
    description: 'Third-party service / Opens external website',
    bgGradient: 'from-blue-500/10 to-indigo-500/10',
    iconBg: 'bg-blue-100 text-blue-600',
    externalUrl: 'https://docs.google.com/videos/u/1/mobilecreate?pli=1',
    subCategories: [
      {
        id: 'google_mobile_video_direct',
        name: 'AI Video Creator',
        description: 'Third-party service / Opens external website',
        estimatedPrice: 0,
        deliveryTime: 'Instant Direct Visit',
        externalUrl: 'https://docs.google.com/videos/u/1/mobilecreate?pli=1',
        fields: []
      }
    ]
  },
  {
    id: 'ai_services',
    title: 'AI Services',
    iconName: 'Bot',
    description: 'AI Chat, Writing, Generation & Translation.',
    bgGradient: 'from-purple-500/10 to-pink-500/10',
    iconBg: 'bg-purple-100 text-purple-600',
    subCategories: [
      { id: 'google_mobile_video_ai', name: 'AI Video Creator', description: 'Third-party service / Opens external website', estimatedPrice: 0, deliveryTime: 'Instant', externalUrl: 'https://docs.google.com/videos/u/1/mobilecreate?pli=1', fields: [] },
      { id: 'ai_chat', name: 'AI Chat Assistant', description: 'Smart chat assistant.', estimatedPrice: 10, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_resume', name: 'AI Resume Builder', description: 'Build professional resumes.', estimatedPrice: 15, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_cv', name: 'AI CV Maker', description: 'Create curriculum vitae.', estimatedPrice: 15, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_cover_letter', name: 'AI Cover Letter Generator', description: 'Generate cover letters.', estimatedPrice: 10, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_content', name: 'AI Content Writing', description: 'Write various content.', estimatedPrice: 20, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_blog', name: 'AI Blog Writing', description: 'Write blog posts.', estimatedPrice: 25, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_article', name: 'AI Article Writing', description: 'Write detailed articles.', estimatedPrice: 30, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_email', name: 'AI Email Writing', description: 'Draft professional emails.', estimatedPrice: 5, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_letter', name: 'AI Letter Writing', description: 'Write formal letters.', estimatedPrice: 10, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_translation', name: 'AI Translation', description: 'Translate text accurately.', estimatedPrice: 10, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_grammar', name: 'AI Grammar Checker', description: 'Check and fix grammar.', estimatedPrice: 5, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_image', name: 'AI Image Generator', description: 'Generate custom images.', estimatedPrice: 15, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_logo', name: 'AI Logo Design', description: 'Design logos with AI.', estimatedPrice: 20, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_banner', name: 'AI Banner Design', description: 'Create banners with AI.', estimatedPrice: 15, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_poster', name: 'AI Poster Design', description: 'Design posters with AI.', estimatedPrice: 15, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_thumbnail', name: 'AI Thumbnail Design', description: 'Create YouTube thumbnails.', estimatedPrice: 10, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_video', name: 'AI Video Generator', description: 'Generate videos.', estimatedPrice: 50, deliveryTime: '1-2 Days', fields: [] },
      { id: 'ai_voice', name: 'AI Voice Generator', description: 'Generate voiceovers.', estimatedPrice: 20, deliveryTime: 'Instant', fields: [] },
      { id: 'ai_coding', name: 'AI Coding Assistant', description: 'Help with coding tasks.', estimatedPrice: 30, deliveryTime: 'Instant', fields: [] }
    ]
  },
  {
    id: 'computer_laptop',
    title: 'Computer & Laptop Services',
    iconName: 'Wrench',
    description: 'Repair, Installation & Optimization.',
    bgGradient: 'from-blue-500/10 to-cyan-500/10',
    iconBg: 'bg-blue-100 text-blue-600',
    subCategories: [
      { id: 'remote_pc', name: 'Remote Computer Repair', description: 'Fix PC issues remotely.', estimatedPrice: 30, deliveryTime: '1-2 Hours', fields: [] },
      { id: 'remote_laptop', name: 'Remote Laptop Repair', description: 'Fix laptop issues remotely.', estimatedPrice: 30, deliveryTime: '1-2 Hours', fields: [] },
      { id: 'win_install', name: 'Windows Installation', description: 'Install Windows OS.', estimatedPrice: 25, deliveryTime: '2-3 Hours', fields: [] },
      { id: 'win_activate', name: 'Windows Activation', description: 'Activate Windows.', estimatedPrice: 15, deliveryTime: 'Instant', fields: [] },
      { id: 'driver_install', name: 'Driver Installation', description: 'Install device drivers.', estimatedPrice: 15, deliveryTime: '1 Hour', fields: [] },
      { id: 'software_install', name: 'Software Installation', description: 'Install required software.', estimatedPrice: 15, deliveryTime: '1 Hour', fields: [] },
      { id: 'office_install', name: 'Microsoft Office Installation', description: 'Install MS Office.', estimatedPrice: 20, deliveryTime: '1 Hour', fields: [] },
      { id: 'antivirus_install', name: 'Antivirus Installation', description: 'Install antivirus software.', estimatedPrice: 15, deliveryTime: '1 Hour', fields: [] },
      { id: 'virus_remove', name: 'Virus Removal', description: 'Remove malware and viruses.', estimatedPrice: 40, deliveryTime: '2-4 Hours', fields: [] },
      { id: 'sys_optimize', name: 'System Optimization', description: 'Speed up your computer.', estimatedPrice: 25, deliveryTime: '1-2 Hours', fields: [] },
      { id: 'data_recovery', name: 'Data Recovery', description: 'Recover lost files.', estimatedPrice: 60, deliveryTime: '1-3 Days', fields: [] },
      { id: 'data_backup', name: 'Data Backup', description: 'Backup important data.', estimatedPrice: 30, deliveryTime: '2-4 Hours', fields: [] },
      { id: 'hdd_upgrade', name: 'Hard Disk Upgrade', description: 'Upgrade HDD storage.', estimatedPrice: 50, deliveryTime: '1 Day', fields: [] },
      { id: 'ssd_install', name: 'SSD Installation Support', description: 'Install fast SSD.', estimatedPrice: 50, deliveryTime: '1 Day', fields: [] },
      { id: 'printer_setup', name: 'Printer Setup', description: 'Setup and configure printers.', estimatedPrice: 20, deliveryTime: '1 Hour', fields: [] },
      { id: 'wifi_setup', name: 'Wi-Fi & Network Setup', description: 'Setup home/office network.', estimatedPrice: 25, deliveryTime: '1-2 Hours', fields: [] },
      { id: 'email_setup', name: 'Email Setup', description: 'Configure email clients.', estimatedPrice: 15, deliveryTime: '1 Hour', fields: [] },
      { id: 'remote_tech_support', name: 'Remote Technical Support', description: 'General tech support.', estimatedPrice: 30, deliveryTime: '1-2 Hours', fields: [] },
      { id: 'screen_share_support', name: 'Screen Sharing Support', description: 'Support via screen sharing.', estimatedPrice: 25, deliveryTime: '1-2 Hours', fields: [] },
      { id: 'video_call_support_comp', name: 'Video Call Support', description: 'Support via video call.', estimatedPrice: 30, deliveryTime: '1-2 Hours', fields: [] }
    ]
  },
  {
    id: 'mobile_services',
    title: 'Mobile Services',
    iconName: 'Smartphone',
    description: 'Setup, Transfer & Optimization.',
    bgGradient: 'from-emerald-500/10 to-green-500/10',
    iconBg: 'bg-emerald-100 text-emerald-600',
    subCategories: [
      { id: 'android_setup', name: 'Android Setup', description: 'Setup new Android device.', estimatedPrice: 20, deliveryTime: '1 Hour', fields: [] },
      { id: 'mobile_soft_support', name: 'Mobile Software Support', description: 'Fix mobile software issues.', estimatedPrice: 25, deliveryTime: '1-2 Hours', fields: [] },
      { id: 'app_install', name: 'App Installation', description: 'Install mobile apps.', estimatedPrice: 10, deliveryTime: '30 Mins', fields: [] },
      { id: 'google_account_setup', name: 'Google Account Setup', description: 'Setup Google account.', estimatedPrice: 10, deliveryTime: '30 Mins', fields: [] },
      { id: 'iphone_setup', name: 'iPhone Setup', description: 'Setup new iPhone.', estimatedPrice: 25, deliveryTime: '1 Hour', fields: [] },
      { id: 'data_transfer', name: 'Data Transfer', description: 'Transfer data between phones.', estimatedPrice: 35, deliveryTime: '1-2 Hours', fields: [] },
      { id: 'mobile_backup', name: 'Mobile Backup', description: 'Backup mobile data.', estimatedPrice: 25, deliveryTime: '1-2 Hours', fields: [] },
      { id: 'mobile_optimize', name: 'Mobile Performance Optimization', description: 'Speed up mobile device.', estimatedPrice: 20, deliveryTime: '1 Hour', fields: [] }
    ]
  },
  {
    id: 'office_business',
    title: 'Office & Business Services',
    iconName: 'Briefcase',
    description: 'MS Office, Emails, Workspace.',
    bgGradient: 'from-amber-500/10 to-yellow-500/10',
    iconBg: 'bg-amber-100 text-amber-600',
    subCategories: [
      { id: 'ms_office_pkg', name: 'Microsoft Office Packages', description: 'MS Office suites.', estimatedPrice: 40, deliveryTime: 'Instant', fields: [] },
      { id: 'office_365', name: 'Office 365 Setup', description: 'Setup Office 365.', estimatedPrice: 50, deliveryTime: '1-2 Hours', fields: [] },
      { id: 'biz_email', name: 'Business Email Setup', description: 'Setup custom business email.', estimatedPrice: 45, deliveryTime: '1-2 Hours', fields: [] },
      { id: 'cloud_storage', name: 'Cloud Storage Setup', description: 'Setup Google Drive, OneDrive, etc.', estimatedPrice: 25, deliveryTime: '1 Hour', fields: [] },
      { id: 'g_workspace', name: 'Google Workspace Setup', description: 'Setup Google Workspace.', estimatedPrice: 60, deliveryTime: '2-3 Hours', fields: [] },
      { id: 'doc_format', name: 'Document Formatting', description: 'Format Word documents.', estimatedPrice: 15, deliveryTime: '1 Day', fields: [] },
      { id: 'excel_auto', name: 'Excel Automation', description: 'Automate Excel tasks.', estimatedPrice: 50, deliveryTime: '1-2 Days', fields: [] },
      { id: 'ppt_presentation', name: 'PowerPoint Presentation', description: 'Create PPT slides.', estimatedPrice: 40, deliveryTime: '1-2 Days', fields: [] },
      { id: 'pdf_edit', name: 'PDF Editing', description: 'Edit PDF documents.', estimatedPrice: 15, deliveryTime: '1 Day', fields: [] },
      { id: 'pdf_convert', name: 'PDF Conversion', description: 'Convert PDF to Word/Excel.', estimatedPrice: 10, deliveryTime: '1 Day', fields: [] }
    ]
  },
  {
    id: 'graphic_design',
    title: 'Graphic Design Services',
    iconName: 'PenTool',
    description: 'Logos, Flyers, Banners.',
    bgGradient: 'from-pink-500/10 to-rose-500/10',
    iconBg: 'bg-pink-100 text-pink-600',
    subCategories: [
      { id: 'gd_logo', name: 'Logo Design', description: 'Custom logo design.', estimatedPrice: 50, deliveryTime: '2-3 Days', fields: [] },
      { id: 'gd_bizcard', name: 'Business Card Design', description: 'Design business cards.', estimatedPrice: 30, deliveryTime: '1-2 Days', fields: [] },
      { id: 'gd_flyer', name: 'Flyer Design', description: 'Design promotional flyers.', estimatedPrice: 40, deliveryTime: '1-2 Days', fields: [] },
      { id: 'gd_poster', name: 'Poster Design', description: 'Design event posters.', estimatedPrice: 45, deliveryTime: '1-2 Days', fields: [] },
      { id: 'gd_banner', name: 'Banner Design', description: 'Design web/print banners.', estimatedPrice: 35, deliveryTime: '1-2 Days', fields: [] },
      { id: 'gd_brochure', name: 'Brochure Design', description: 'Design trifold brochures.', estimatedPrice: 80, deliveryTime: '3-4 Days', fields: [] },
      { id: 'gd_social', name: 'Social Media Post Design', description: 'Design SM graphics.', estimatedPrice: 20, deliveryTime: '1-2 Days', fields: [] },
      { id: 'gd_thumbnail', name: 'YouTube Thumbnail Design', description: 'Catchy YT thumbnails.', estimatedPrice: 15, deliveryTime: '1 Day', fields: [] },
      { id: 'gd_idcard', name: 'ID Card Design', description: 'Design staff/student IDs.', estimatedPrice: 25, deliveryTime: '1-2 Days', fields: [] },
      { id: 'gd_cert', name: 'Certificate Design', description: 'Design custom certificates.', estimatedPrice: 30, deliveryTime: '1-2 Days', fields: [] }
    ]
  },
  {
    id: 'website_services',
    title: 'Website Services',
    iconName: 'Globe',
    description: 'Design, Dev & Maintenance.',
    bgGradient: 'from-teal-500/10 to-emerald-500/10',
    iconBg: 'bg-teal-100 text-teal-600',
    subCategories: [
      { id: 'web_design', name: 'Website Design', description: 'Design website UI/UX.', estimatedPrice: 150, deliveryTime: '5-7 Days', fields: [] },
      { id: 'web_dev', name: 'Website Development', description: 'Develop full websites.', estimatedPrice: 250, deliveryTime: '7-14 Days', fields: [] },
      { id: 'landing_page', name: 'Landing Page Design', description: 'High-converting landing pages.', estimatedPrice: 100, deliveryTime: '3-5 Days', fields: [] },
      { id: 'portfolio_web', name: 'Portfolio Website', description: 'Personal portfolio sites.', estimatedPrice: 120, deliveryTime: '4-6 Days', fields: [] },
      { id: 'biz_web', name: 'Business Website', description: 'Corporate websites.', estimatedPrice: 200, deliveryTime: '7-10 Days', fields: [] },
      { id: 'ecom_web', name: 'E-commerce Website', description: 'Online stores.', estimatedPrice: 400, deliveryTime: '14-21 Days', fields: [] },
      { id: 'web_maint', name: 'Website Maintenance', description: 'Monthly website upkeep.', estimatedPrice: 50, deliveryTime: 'Monthly', fields: [] },
      { id: 'domain_hosting', name: 'Domain & Hosting Setup', description: 'Setup domains and hosting servers.', estimatedPrice: 40, deliveryTime: '1 Day', fields: [] },
      { id: 'ssl_install', name: 'SSL Installation', description: 'Secure website with SSL.', estimatedPrice: 25, deliveryTime: '1 Day', fields: [] },
      { id: 'web_speed', name: 'Website Speed Optimization', description: 'Improve site loading time.', estimatedPrice: 80, deliveryTime: '2-3 Days', fields: [] }
    ]
  },
  {
    id: 'digital_marketing',
    title: 'Digital Marketing',
    iconName: 'Megaphone',
    description: 'SEO, Ads & Social Media.',
    bgGradient: 'from-orange-500/10 to-red-500/10',
    iconBg: 'bg-orange-100 text-orange-600',
    subCategories: [
      { id: 'fb_marketing', name: 'Facebook Marketing', description: 'Market on Facebook.', estimatedPrice: 100, deliveryTime: 'Monthly', fields: [] },
      { id: 'insta_marketing', name: 'Instagram Marketing', description: 'Market on Instagram.', estimatedPrice: 100, deliveryTime: 'Monthly', fields: [] },
      { id: 'yt_marketing', name: 'YouTube Marketing', description: 'Grow YouTube channel.', estimatedPrice: 150, deliveryTime: 'Monthly', fields: [] },
      { id: 'google_ads', name: 'Google Ads', description: 'Manage Google Ads.', estimatedPrice: 200, deliveryTime: 'Monthly', fields: [] },
      { id: 'fb_ads', name: 'Facebook Ads', description: 'Manage FB Ad campaigns.', estimatedPrice: 150, deliveryTime: 'Monthly', fields: [] },
      { id: 'seo_services', name: 'SEO Services', description: 'Improve search rankings.', estimatedPrice: 250, deliveryTime: 'Monthly', fields: [] },
      { id: 'social_mgt', name: 'Social Media Management', description: 'Manage SM profiles.', estimatedPrice: 200, deliveryTime: 'Monthly', fields: [] },
      { id: 'content_marketing', name: 'Content Marketing', description: 'Content strategy and creation.', estimatedPrice: 150, deliveryTime: 'Monthly', fields: [] }
    ]
  },
  {
    id: 'buy_sell',
    title: 'Buy & Sell',
    iconName: 'ShoppingBag',
    description: 'Computers, Mobiles & Accessories.',
    bgGradient: 'from-indigo-500/10 to-violet-500/10',
    iconBg: 'bg-indigo-100 text-indigo-600',
    subCategories: [
      { id: 'comp_sales', name: 'Computer Sales', description: 'Buy new desktop PCs.', estimatedPrice: 0, deliveryTime: '2-5 Days', fields: [] },
      { id: 'laptop_sales', name: 'Laptop Sales', description: 'Buy new laptops.', estimatedPrice: 0, deliveryTime: '2-5 Days', fields: [] },
      { id: 'mobile_sales', name: 'Mobile Sales', description: 'Buy smartphones.', estimatedPrice: 0, deliveryTime: '2-5 Days', fields: [] },
      { id: 'printer_sales', name: 'Printer Sales', description: 'Buy printers and scanners.', estimatedPrice: 0, deliveryTime: '2-5 Days', fields: [] },
      { id: 'acc_sales', name: 'Accessories Sales', description: 'Buy tech accessories.', estimatedPrice: 0, deliveryTime: '2-5 Days', fields: [] },
      { id: 'refurb_devices', name: 'Refurbished Devices', description: 'Buy certified refurbished tech.', estimatedPrice: 0, deliveryTime: '2-5 Days', fields: [] },
      { id: 'used_laptop_bs', name: 'Used Laptop Buy & Sell', description: 'Trade used laptops.', estimatedPrice: 0, deliveryTime: 'N/A', fields: [] },
      { id: 'used_mobile_bs', name: 'Used Mobile Buy & Sell', description: 'Trade used mobiles.', estimatedPrice: 0, deliveryTime: 'N/A', fields: [] }
    ]
  },
  {
    id: 'online_docs',
    title: 'Online Documentation',
    iconName: 'FileText',
    description: 'Forms, Resumes, Visa Apps.',
    bgGradient: 'from-cyan-500/10 to-blue-500/10',
    iconBg: 'bg-cyan-100 text-cyan-600',
    subCategories: [
      { id: 'doc_resume', name: 'Resume Creation', description: 'Create professional resumes.', estimatedPrice: 20, deliveryTime: '1-2 Days', fields: [] },
      { id: 'doc_cv', name: 'CV Creation', description: 'Create detailed CVs.', estimatedPrice: 25, deliveryTime: '1-2 Days', fields: [] },
      { id: 'doc_cover', name: 'Cover Letter', description: 'Write cover letters.', estimatedPrice: 15, deliveryTime: '1 Day', fields: [] },
      { id: 'doc_biodata', name: 'Bio Data', description: 'Create matrimonial/job bio data.', estimatedPrice: 15, deliveryTime: '1 Day', fields: [] },
      { id: 'doc_passport', name: 'Passport Form Assistance', description: 'Help with passport applications.', estimatedPrice: 30, deliveryTime: '1-2 Days', fields: [] },
      { id: 'doc_visa', name: 'Visa Form Assistance', description: 'Help with visa applications.', estimatedPrice: 40, deliveryTime: '1-3 Days', fields: [] },
      { id: 'doc_online_app', name: 'Online Application', description: 'Fill various online apps.', estimatedPrice: 15, deliveryTime: '1 Day', fields: [] },
      { id: 'doc_govt_form', name: 'Government Form Filling', description: 'Fill Govt portals/forms.', estimatedPrice: 20, deliveryTime: '1 Day', fields: [] },
      { id: 'doc_pan', name: 'PAN Registration Support', description: 'Apply for PAN card.', estimatedPrice: 15, deliveryTime: '1-2 Days', fields: [] },
      { id: 'doc_biz_reg', name: 'Business Registration Support', description: 'Register new business.', estimatedPrice: 100, deliveryTime: '3-7 Days', fields: [] }
    ]
  },
  {
    id: 'edu_services',
    title: 'Education Services',
    iconName: 'GraduationCap',
    description: 'Training & Career Guidance.',
    bgGradient: 'from-lime-500/10 to-green-500/10',
    iconBg: 'bg-lime-100 text-lime-600',
    subCategories: [
      { id: 'edu_comp_train', name: 'Online Computer Training', description: 'Learn basic computer skills.', estimatedPrice: 50, deliveryTime: 'Weekly/Monthly', fields: [] },
      { id: 'edu_ai_train', name: 'AI Training', description: 'Learn AI tools and prompts.', estimatedPrice: 80, deliveryTime: 'Weekly', fields: [] },
      { id: 'edu_ms_train', name: 'Microsoft Office Training', description: 'Learn Word, Excel, PPT.', estimatedPrice: 60, deliveryTime: 'Weekly', fields: [] },
      { id: 'edu_gd_train', name: 'Graphic Design Training', description: 'Learn design software.', estimatedPrice: 100, deliveryTime: 'Monthly', fields: [] },
      { id: 'edu_prog_basics', name: 'Programming Basics', description: 'Learn coding fundamentals.', estimatedPrice: 120, deliveryTime: 'Monthly', fields: [] },
      { id: 'edu_web_train', name: 'Website Development Training', description: 'Learn web dev.', estimatedPrice: 150, deliveryTime: 'Monthly', fields: [] },
      { id: 'edu_interview', name: 'Interview Preparation', description: 'Mock interviews and tips.', estimatedPrice: 40, deliveryTime: '1-2 Days', fields: [] },
      { id: 'edu_career', name: 'Career Guidance', description: 'Career path consultation.', estimatedPrice: 50, deliveryTime: '1-2 Days', fields: [] }
    ]
  },
  {
    id: 'customer_support',
    title: 'Customer Support',
    iconName: 'Headphones',
    description: '24/7 Tech & Chat Support.',
    bgGradient: 'from-sky-500/10 to-blue-500/10',
    iconBg: 'bg-sky-100 text-sky-600',
    subCategories: [
      { id: 'cs_live_chat', name: 'Live Chat Support', description: 'Instant live chat help.', estimatedPrice: 10, deliveryTime: 'Instant', fields: [] },
      { id: 'cs_whatsapp', name: 'WhatsApp Support', description: 'Support via WhatsApp.', estimatedPrice: 10, deliveryTime: 'Instant', fields: [] },
      { id: 'cs_video', name: 'Video Call Support', description: 'Face-to-face video support.', estimatedPrice: 25, deliveryTime: 'Scheduled', fields: [] },
      { id: 'cs_remote', name: 'Remote Desktop Support', description: 'Remote PC troubleshooting.', estimatedPrice: 30, deliveryTime: 'Instant/Scheduled', fields: [] },
      { id: 'cs_24_7', name: '24/7 Technical Support', description: 'Round the clock assistance.', estimatedPrice: 50, deliveryTime: 'Monthly Plan', fields: [] }
    ]
  },
  {
    id: 'payment_services',
    title: 'Payment Services',
    iconName: 'CreditCard',
    description: 'Invoices, Subscriptions & Checkout.',
    bgGradient: 'from-violet-500/10 to-purple-500/10',
    iconBg: 'bg-violet-100 text-violet-600',
    subCategories: [
      { id: 'pay_online', name: 'Online Payment', description: 'Process online payments.', estimatedPrice: 0, deliveryTime: 'Instant', fields: [] },
      { id: 'pay_invoice', name: 'Invoice Generation', description: 'Generate custom invoices.', estimatedPrice: 15, deliveryTime: '1 Day', fields: [] },
      { id: 'pay_subs', name: 'Subscription Plans', description: 'Setup recurring billing.', estimatedPrice: 40, deliveryTime: '1-2 Days', fields: [] },
      { id: 'pay_secure', name: 'Secure Checkout', description: 'Secure payment gateways.', estimatedPrice: 30, deliveryTime: '1-2 Days', fields: [] }
    ]
  },
  {
    id: 'additional_services',
    title: 'Additional Services',
    iconName: 'Grid',
    description: 'Cloud, Scanning & Recovery.',
    bgGradient: 'from-slate-500/10 to-gray-500/10',
    iconBg: 'bg-slate-100 text-slate-600',
    subCategories: [
      { id: 'add_cloud', name: 'Cloud Backup', description: 'Setup cloud data backup.', estimatedPrice: 25, deliveryTime: '1 Day', fields: [] },
      { id: 'add_file_conv', name: 'File Conversion', description: 'Convert file formats.', estimatedPrice: 10, deliveryTime: '1 Hour', fields: [] },
      { id: 'add_scan', name: 'Document Scanning', description: 'Scan physical docs.', estimatedPrice: 15, deliveryTime: '1 Day', fields: [] },
      { id: 'add_print', name: 'Document Printing Support', description: 'Help with printing.', estimatedPrice: 10, deliveryTime: '1 Hour', fields: [] },
      { id: 'add_qrcode', name: 'QR Code Generator', description: 'Generate custom QR codes.', estimatedPrice: 5, deliveryTime: 'Instant', fields: [] },
      { id: 'add_barcode', name: 'Barcode Generator', description: 'Generate barcodes.', estimatedPrice: 5, deliveryTime: 'Instant', fields: [] },
      { id: 'add_pass_recv', name: 'Password Recovery Assistance', description: 'Help recovering passwords.', estimatedPrice: 30, deliveryTime: '1 Day', fields: [] },
      { id: 'add_email_recv', name: 'Email Recovery Assistance', description: 'Help recovering email access.', estimatedPrice: 30, deliveryTime: '1 Day', fields: [] },
      { id: 'add_acct_setup', name: 'Account Setup & Configuration', description: 'Setup various accounts.', estimatedPrice: 20, deliveryTime: '1-2 Hours', fields: [] },
      { id: 'add_custom_soft', name: 'Custom Software Consultation', description: 'Consulting for custom apps.', estimatedPrice: 50, deliveryTime: 'Scheduled', fields: [] }
    ]
  }
];

export const popularAiTools: AiTool[] = [
  {
    id: 'ai_chat',
    title: 'AI Chat Assistant',
    iconName: 'MessageSquare',
    category: 'Conversational AI',
    description: 'Smart assistant for answering queries, brainstorming, and writing scripts.',
    badge: 'Hot',
    samplePrompt: 'Help me draft a polite response to a customer inquiring about laptop repair status.'
  },
  {
    id: 'ai_image',
    title: 'AI Image Generator',
    iconName: 'Image',
    category: 'Creative Design',
    description: 'Generate photorealistic product images, banners, and logos instantly.',
    samplePrompt: 'A sleek futuristic gaming laptop sitting on a neon backlit desk, 4k ultra detailed.'
  },
  {
    id: 'ai_writer',
    title: 'AI Content Writer',
    iconName: 'PenTool',
    category: 'Copywriting',
    description: 'Create high-converting blog posts, marketing copies, and social posts.',
    samplePrompt: 'Write 3 catchy headlines for an online tech repair and sales shop.'
  },
  {
    id: 'ai_voice',
    title: 'AI Voice Generator',
    iconName: 'Mic',
    category: 'Audio Synth',
    description: 'Convert plain text into studio-quality natural human voiceovers.',
    samplePrompt: 'Welcome to TechEverywhere! Your one-stop shop for smart online services.'
  },
  {
    id: 'ai_code',
    title: 'AI Code Helper',
    iconName: 'Code',
    category: 'Development',
    description: 'Write, debug, and refactor React, Node.js, and Python code snippets.',
    samplePrompt: 'Create a responsive React form component with validation in TypeScript.'
  },
  {
    id: 'ai_video',
    title: 'AI Video Creator',
    iconName: 'Video',
    category: 'Media Production',
    description: 'Generate animated promo reels and short explanatory tech videos.',
    samplePrompt: '30-second promo video script demonstrating on-site laptop doorstep repair.'
  }
];

export const techProducts: TechProduct[] = [
  {
    id: 'prod_1',
    name: 'TechExtreme RTX 4080 Gaming PC',
    category: 'desktop',
    price: 1899,
    rating: 4.9,
    specs: ['Intel i9 14th Gen', '32GB DDR5 RAM', '1TB NVMe SSD', 'RTX 4080 Super 16GB'],
    imageUrl: 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?w=600&auto=format&fit=crop&q=80',
    stock: 5
  },
  {
    id: 'prod_2',
    name: 'Ultralight Pro 15 Laptop',
    category: 'laptop',
    price: 949,
    rating: 4.8,
    specs: ['Intel Core Ultra 7', '16GB RAM', '512GB SSD', '15.6" OLED Display'],
    imageUrl: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600&auto=format&fit=crop&q=80',
    stock: 12
  },
  {
    id: 'prod_3',
    name: 'SmartPhone Pro Max 5G',
    category: 'mobile',
    price: 799,
    rating: 4.7,
    specs: ['6.7" 120Hz Display', '256GB Storage', '200MP Triple Camera', '5000mAh Battery'],
    imageUrl: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600&auto=format&fit=crop&q=80',
    stock: 25
  }
];
